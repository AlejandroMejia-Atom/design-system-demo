# Changelog — `@atomchat-io/ui-tokens`

All notable changes to the **npm package** (SCSS + `atom-tokens.json`) are documented here.

The **VS Code extension** (`design-system-extension`) lives in **`libs/design-system-extension/extension/`** and is versioned separately — see [`../design-system-extension/CHANGELOG.md`](../design-system-extension/CHANGELOG.md).

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.8] - 2026-06-16

### Changed (0.2.8)

- **Semantic color descriptions** — all **157** light and **157** dark entries in `semantic-light.tokens.json` / `semantic-dark.tokens.json` now match the **Usage** column in the Figma Semantics tables ([light](https://www.figma.com/design/YkhUvpl8Yfm7lK5yv6WOp8/Semantics?node-id=1014-5731), [dark](https://www.figma.com/design/YkhUvpl8Yfm7lK5yv6WOp8/Semantics?node-id=1265-9678)). Figma is the source of truth for copy; generated CSS custom properties and `atom-tokens.json` descriptions are unchanged in **value** — only metadata text updated.
- **Strong status backgrounds** — descriptions for `bg/status/*-strong` now document full-width banner and high-visibility use cases (replacing generic “high-intensity” wording).
- **`bg/overlay/primary`** — description aligned with Figma: interruptive backdrop that blocks page interaction (modals, dialogs).
- **`bg/brand/*`** — primary and secondary brand surface descriptions synced from Figma usage notes.

### Fixed (0.2.8)

- **`semantic-dark`** — corrected stale descriptions for `bg/inverse/tertiary` and `border/interactive/secondary/hovered` (superseded by full Figma sync).

| Commit     | Detail                                                                                  |
| ---------- | --------------------------------------------------------------------------------------- |
| `b3470237` | Synced semantic light/dark color token descriptions from Figma Usage column.            |
| `000fb687` | Corrected two stale descriptions in `semantic-dark.tokens.json` before full-table sync. |

## [0.2.7] - 2026-06-15

### Added (0.2.7)

- **`bg/brand/secondary`** — `Orange/100` (light) / `Orange/900` (dark). Secondary brand background for containers and surfaces; completes the `bg/brand/*` pair alongside `bg/brand/primary` (`Orange/50` / `Orange/950`, added in `0.2.4`).

## [0.2.6] - 2026-06-15

### Added (0.2.6)

- **`bg/status/*-strong`** — seven high-intensity status background tokens: `info-strong`, `success-strong`, `warning-strong`, `error-strong`, `neutral-strong`, `brand-strong`, `ai-strong`. Figma `informative-strong` maps to `info-strong` for consistency with the existing base token `bg/status/info`.
- **High-intensity primitive mapping** — light: `*.200` (neutral `300`); dark: `*.800` (neutral `600`). CSS custom properties: `--bg-status-info-strong` through `--bg-status-ai-strong`.

## [0.2.5] - 2026-06-08

### Changed (0.2.5)

- **`stroke.2xs` → `stroke.xxs`** — renamed the 0.03125rem stroke primitive to align with the `xxs` naming convention already used by `spacing/primitives.tokens.json`. Single nomenclature across tiers (`xxs`, `xs`, `s`, …) removes the `stroke-2xs` vs `spacing-xxs` ambiguity. Generated CSS variable `--stroke-xxs` replaces `--stroke-2xs`; downstream consumers (e.g. `atom-pagination`) updated.

## [0.2.4] - 2026-05-28

### Added (0.2.4)

- **`bg/interactive/solid/brand/hovered`** and **`pressed`** — light: `Orange/50` / `Orange/100`; dark: `Orange/950` / `Orange/900`. Hover and press feedback for brand-styled interactive surfaces.
- **`bg/brand/primary`** — `Orange/50` (light) / `Orange/950` (dark). Base surface for persistent active states (e.g. selected list items).
- **`bg/overlay/primary`** — `Alpha/200` (light) / `Alpha/800` (dark). Backdrop for modals and dialogs, distinct from `bg/soft` ghost overlays.
- **`fg/brand/secondary`** — `Orange/700` (light) / `Orange/300` (dark). Medium-emphasis brand text and icons.
- **`border/brand/secondary`** — `Orange/700` (light) / `Orange/300` (dark). High-contrast brand stroke for dividers.
- **`elevation/border-right`** and **`elevation/border-left`** — directional shadows (`6px 0px 20px` / `-6px 0px 20px` with `Zinc/950` at 4% opacity) for sticky columns, sidebars, and drawers without hard borders.

### Changed (0.2.4)

- **`fg/brand`** and **`border/brand`** — flat leaf tokens refactored into **`primary`** / **`secondary`** groups. CSS custom properties rename accordingly (e.g. `--fg-brand` → `--fg-brand-primary`, `--border-brand` → `--border-brand-primary`). **Breaking** for consumers referencing the previous flat names.
- **`tooltip-rich-grace-duration`** — raised from `100ms` to `150ms`; description clarifies the grace window applies only during pointer transit between Rich tooltip trigger and panel.

| Commit    | Detail                                                                                                  |
| --------- | ------------------------------------------------------------------------------------------------------- |
| `8a83592` | Added directional elevation shadows `border-right` and `border-left`.                                   |
| `0b7c70b` | Added brand/overlay semantic backgrounds; grouped `fg/brand` and `border/brand` into primary/secondary. |
| `1dc50ad` | Increased `tooltip-rich-grace-duration` to 150ms and updated motion token description.                  |

## [0.2.3] - 2026-05-27

### Added (0.2.3)

- **`bg/status/brand`** — `Orange/50` (light) / `Orange/950` (dark). Background for brand-status surfaces.
- **`bg/status/ai`** — `Purple/50` (light) / `Purple/950` (dark). Background for AI-status surfaces.
- **`bg/accent/notifications/tertiary`** — `Red/900` (light) / `Red/100` (dark). High-contrast background for focused/selected badge states.
- **`bg/accent/info/primary`**, **`secondary`**, **`tertiary`** — informational accent backgrounds (`Blue/500` primary; soft and high-contrast variants per theme).
- **`fg/accent/inbox/message/read`** — `Blue/500` (light) / `Blue/400` (dark). Color for "Read" double-check indicators.
- **`fg/accent/inbox/message/sent`** — `Zinc/500` (light) / `Zinc/400` (dark). Color for "Sent" single-check indicators and pre-read timestamps.
- **Motion primitives** — `tooltip-show-duration`, `tooltip-hide-duration`, `tooltip-rich-grace-duration`, `tooltip-show-easing`, `tooltip-hide-easing` in `src/lib/tokens/motion/primitives.tokens.json`, with SCSS output `styles/tokens/motion/_primitives.tokens.scss`.

### Changed (0.2.3)

- **`bg/accent/indicators/offline`** — updated from `Red/100` to `Red/500` in both light and dark themes; descriptions corrected for online/offline presence dots.
- **Effects blur surface tokens** — descriptions for `surface-subtle`, `surface-medium`, and `surface-strong` now document the Figma→CSS **0.5×** conversion (`16/24/48px` reference values; consumers apply `calc(var(--effects-blur-surface-*) * 0.5)` at `backdrop-filter`).

| Commit    | Detail                                                                                                        |
| --------- | ------------------------------------------------------------------------------------------------------------- |
| `b5f74fc` | Documented blur surface Figma-to-CSS conversion; bumped package to `0.2.3`.                                   |
| `94c4e9a` | Added motion primitive tokens and Style Dictionary `motion/_primitives.tokens.scss` output.                   |
| `b10b747` | Added status brand/ai backgrounds, notification/info accent tiers, inbox message read/sent foreground tokens. |
| `3608e58` | Aligned semantic accent token values with badge design review feedback.                                       |

## [0.2.2] - 2026-05-14

### Fixed (0.2.2)

- **`bg/soft/primary`** — dark theme value corrected from `Alpha/950` to `Alpha/50`. The token previously resolved to the same dark value in both themes, so it never flipped. Light stays `Alpha/950`; the pair now yields a dark veil in light mode and a light veil in dark mode, matching the `fg/inverse/primary` it is paired against (e.g. the Plain tooltip surface).

## [0.2.1] - 2026-04-22

### Changed (0.2.1)

- **Effects focus-rings map keys renamed** — in `styles/tokens/effects/_semantic.tokens.scss`, focus ring keys are now `base` and `error` (previously `focus-ring` and `focus-error`) to align naming with downstream design-system usage.
- **Typography line-heights updated** — `line-height` tokens were normalized to role-based keys (`displayXL`, `h1`, `body`, etc.) with direct values; legacy scale keys (`5xxl`, `4xxl`, ..., `3xxs`) were removed from source primitives.

| Commit    | Detail                                                                             |
| --------- | ---------------------------------------------------------------------------------- |
| `8a73fc9` | Renamed effects focus ring keys from `focus-ring`/`focus-error` to `base`/`error`. |
| `57541f4` | Updated typography line-height values and removed legacy scale token references.   |

## [0.2.0] - 2026-04-13

### Added in 0.2.0

- **`bg/status/neutral`** — new token: `Zinc/200` (light) and `Zinc/800` (dark) for neutral status backgrounds.
- **`fg/status/on-*` variants** — new `on-info`, `on-success`, `on-warning`, `on-error`, `on-neutral`, `on-brand`, `on-ai` tokens for text/icons placed on status backgrounds.
- **`fg/status/neutral`, `fg/status/brand`, `fg/status/ai`** — new base variants for neutral, brand, and AI status contexts.
- **`border/status/on-*` variants** — new `on-info`, `on-success`, `on-warning`, `on-error`, `on-neutral`, `on-brand`, `on-ai` border tokens for components on status backgrounds.
- **`border/status/neutral`, `border/status/brand`, `border/status/ai`** — new base border variants for neutral, brand, and AI status contexts.
- **Effects semantic tokens** — new `src/lib/tokens/effects/` domain with four source files: `shadows.tokens.json` (theme-agnostic elevation shadows referencing `{color.zinc.950}`), `focus-rings.tokens.json` (theme-agnostic focus ring box-shadows referencing `{color.alpha.400}` and `{color.red.300}`), `blur-light.tokens.json` and `blur-dark.tokens.json` (surface blur backdrop amounts + themed background overlay).
- **SCSS output** `styles/tokens/effects/_semantic.tokens.scss` with four maps: `$effects-shadows`, `$effects-focus-rings`, `$effects-blur-light`, `$effects-blur-dark`.
- **Custom format** `scss/effects-semantic-maps` in `effects-semantic.format.ts`.
- **Filter** `isEffectSemantic` in `filters/index.ts`; updated `isSemantic` to exclude the `effects/` domain.

### Changed (0.2.0)

- **`fg/status/*` base values** updated to match Figma: `info` → Blue/600 (light) / Blue/400 (dark), `success` → Emerald/600/400, `warning` → Yellow/600/400, `error` → Red/600/400.
- **`border/status/*` base values** aligned with `fg/status/*` per dual-use semantic: `info` → Blue/600 (light) / Blue/400 (dark), `success` → Emerald/600/400, `warning` → Yellow/600/400, `error` → Red/600/400.

| Commit    | Detail                                                                                    |
| --------- | ----------------------------------------------------------------------------------------- |
| `e167119` | Added `bg/status/neutral` (Zinc/200 light, Zinc/800 dark).                                |
| `8a286ca` | Added `fg/status/on-*` and base `neutral/brand/ai` variants; updated base primitives.     |
| `ca43217` | Added `border/status/on-*` and base `neutral/brand/ai` variants; updated base primitives. |
| `6e606c1` | Added effects token domain (`blur-light/dark`, `shadows`, `focus-rings`).                 |
| `b3e120e` | Added `scss/effects-semantic-maps` format and `isEffectSemantic` filter.                  |
| `1f3a382` | Extended Style Dictionary config with `effects/_semantic.tokens.scss` output.             |

## [0.1.2] - 2026-03-28

### Added in 0.1.2

- **`atom-tokens.json`** via custom Style Dictionary format `json/atom-tokens-nested`: nested primitives; **semantic** colors under a single `semantic` tree with `value: { light, dark }`, `alias: { light, dark }`, plus `type` and `description` for tooling.
  No changes in `libs/ui-tokens` since `ui-tokens@0.1.2`.
- Added JSON output improvements for tooling and semantic token aliases.

| Commit    | Detail                                            |
| --------- | ------------------------------------------------- |
| `0adcb9a` | Added `atom-tokens.json` custom format output.    |
| `7f6f749` | Improved semantic token JSON and alias structure. |

### Fixed (0.1.2)

- No `ui-tokens` package fixes in this release.

### Changed (0.1.2)

- Updated release packaging and configuration for token generation.

| Commit    | Detail                                                  |
| --------- | ------------------------------------------------------- |
| `b1faab6` | Bumped package to `0.1.2`.                              |
| `3d4db26` | Moved tooling artifacts to a dedicated package.         |
| `f35e1bb` | Added JSON platform configuration for token generation. |

## [0.1.1] - 2026-03-27

### Changed (0.1.1)

- Released `0.1.1` with package version update.

| Commit    | Detail                         |
| --------- | ------------------------------ |
| `5bae59a` | Bumped `ui-tokens` to `0.1.1`. |

## [0.1.0] - 2026-03-27

### Added (0.1.0)

- Semantic tokens for light and dark modes (SCSS output).
- Style Dictionary pipeline consolidation and theming improvements.
- Alpha color references using the updated naming convention.
- Expanded typography tokens (display, headings, caption, label/labelSmall).

### Fixed (0.1.0)

- Line-height and label/labelSmall separation.
- Header generation and pipeline filter behavior.

### Changed (0.1.0)

- Initial published baseline: semantic light/dark SCSS maps, Style Dictionary pipeline, README/CHANGELOG for the package.
- **Breaking:** JSON output no longer exposes top-level `semantic-light` / `semantic-dark` duplicate trees; consumers of `atom-tokens.json` must use the unified `semantic` object.

## Release notes

After `nx build ui-tokens`, the publishable library manifest is under `dist/libs/ui-tokens/`. Align versions with consumers such as `@atomchat-io/ui-design-system`. Use `nx release version` per team policy.

- Renamed semantic token files (light/dark) and SCSS destination paths.
- Color descriptions and semantic token formats.
- Description copy fixes (including typification wording).
- Token iteration utilities (`Object.entries`, `createVariablesFormat`).
