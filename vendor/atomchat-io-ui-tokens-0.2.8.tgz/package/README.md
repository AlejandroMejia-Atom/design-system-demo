# @atomchat-io/ui-tokens

Design tokens for Atom products, published as **SCSS** sources generated with [Style Dictionary](https://amzn.github.io/style-dictionary/). Use them to keep colors, type, spacing, and related values consistent across apps and libraries.

## What you get

- **Colors (primitives)** — scales such as `neutral`, `orange`, `zinc`, etc., as SCSS maps (see `colors/_primitives.tokens.scss`).
- **Colors (semantic)** — **intent-based** colors (background, foreground, borders, brand accents) for **light** and **dark** themes, shipped as two SCSS maps in one file (see [Semantic color tokens](#semantic-color-tokens) below).
- **Effects (semantic)** — shadows, focus rings, and blur maps for elevation and interactive states (see [Effects tokens](#effects-tokens)).
- **Typography** — font stacks, sizes, weights, and line heights as SCSS maps and variables.
- **Spacing, radius, stroke** — scales for layout and borders.
- **Breakpoints** — shared layout breakpoints.
- **JSON** — `styles/tokens/atom-tokens.json` (nested primitives; under **`semantic`**, each role is a single leaf with `value: { light, dark }`, `alias: { light, dark }` (references to primitives per theme), `type`, and `description` for tooling and the VS Code extension).

Outputs live under the `styles/tokens/` tree (`colors`, `effects`, `typography`, `spacing`, `radius`, `stroke`, `breakpoints`). See `CHANGELOG.md` in this package for notable changes.

## Semantic color tokens

Semantic tokens describe **what a color is for** (e.g. surface, text, border, brand), not the raw palette step. In the JSON sources they resolve to **references** to primitive color tokens (e.g. `{color.orange.500}`), so changing a primitive updates every semantic role that points at it.

### Generated file

Style Dictionary emits a single SCSS partial:

| Output                                       | Contents                                                                                                               |
| -------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `styles/tokens/colors/_semantic.tokens.scss` | Two maps: **`$semantic-light`** and **`$semantic-dark`**, same keys in both maps, different resolved values per theme. |

Sources in this repo are `semantic-light.tokens.json` and `semantic-dark.tokens.json` under `src/lib/tokens/colors/`; token names are prefixed for the pipeline (`semantic-light-*`, `semantic-dark-*`) and **flattened to map keys** without that prefix (for example `primary`, `bg-primary`, `fg-secondary`, `border-brand`, `secondary-orange`).

### Using semantic maps in SCSS

Import the partial and read from the map you need (for example with `map.get`):

```scss
@use 'sass:map';
@use '@atomchat-io/ui-tokens/styles/tokens/colors/semantic.tokens' as semantic;

.custom {
  color: map.get(semantic.$semantic-light, fg-primary);
}
```

Use **`$semantic-dark`** the same way when you author theme-specific rules in SCSS.

## Effects tokens

Effects tokens cover elevation shadows, focus-ring box-shadows, and theme-aware blur overlays.

### Build output

Style Dictionary emits a single SCSS partial:

- `styles/tokens/effects/_semantic.tokens.scss`: four maps, **`$effects-shadows`**, **`$effects-focus-rings`**, **`$effects-blur-light`**, **`$effects-blur-dark`**.

Focus ring keys in **`$effects-focus-rings`** are currently **`base`** and **`error`**.

### Using effects maps in SCSS

```scss
@use 'sass:map';
@use '@atomchat-io/ui-tokens/styles/tokens/effects/semantic.tokens' as effects;

.card {
  box-shadow: map.get(effects.$effects-shadows, elevation-card);
}

.control:focus-visible {
  box-shadow: map.get(effects.$effects-focus-rings, base);
}
```

## Typography tokens

Typography outputs include role-based line-height keys (`displayXL`, `h1`, `body`, `caption`, etc.). Prefer consuming role keys directly instead of relying on legacy size-scale aliases.

### CSS custom properties (`var(--…)`)

This package **does not** emit global `var(--…)` by itself. To expose semantic colors as **CSS variables** on `:root` / **`.atom-dark-mode`**, use **`@atomchat-io/ui-design-system`** (its theme SCSS consumes `semantic.tokens` and generates `--primary`, `--bg-primary`, etc.). For a full list of variable names and utilities, see that package’s styles documentation.

If you only need SCSS maps and no Angular layer, **`@atomchat-io/ui-tokens`** alone is enough.

## Installation

Packages are published under the `@atomchat-io` scope (private registry access is required). Configure your project `.npmrc` (do not commit secrets):

```ini
@atomchat-io:registry=${ATOMCHAT_NPM_REGISTRY}
//registry.npmjs.org/:_authToken=${ATOMCHAT_NPM_AUTH_TOKEN}
```

Then:

```bash
npm install @atomchat-io/ui-tokens
```

## Usage in SCSS

The package exposes Sass files via `exports` (see `package.json`). Import the token partials you need from `@atomchat-io/ui-tokens/styles/...` according to your bundler’s resolution rules (typically `sass` / `style` fields).

Example (paths match the `styles/tokens/**` tree in the package you install):

```scss
@use '@atomchat-io/ui-tokens/styles/tokens/spacing/primitives.tokens' as spacing;
```

Use the partial names and folders present in that version’s tarball. If you also use **`@atomchat-io/ui-design-system`**, follow that package’s documentation for global CSS custom properties and theme entry points; it builds on these tokens.

## Design System Tokens VS Code extension

IntelliSense and hovers for `var(--…)` and HTML utility classes are provided by the **Design System Tokens** VS Code extension. **Source and build** live in **`libs/design-system-extension/`** (`nx build design-system-extension`). The extension id is **`design-system-extension`**; it has its **own semver**, separate from this package’s version. Npm bundle: **`@atomchat-io/design-system-extension`**. Docs: [`../design-system-extension/extension/README.md`](../design-system-extension/extension/README.md); changelog: [`../design-system-extension/CHANGELOG.md`](../design-system-extension/CHANGELOG.md).

## Peer tooling

This package ships **SCSS** (and JSON for tooling) for consumption in build pipelines; it does not include runtime JavaScript for apps. Your app should include a compatible Sass compiler.

## Changelog

See `CHANGELOG.md` in the published tarball for version history.
