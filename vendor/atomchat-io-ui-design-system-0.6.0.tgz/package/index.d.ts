import * as _angular_core from '@angular/core';
import { AfterViewInit, EnvironmentProviders, InjectionToken, Signal, OnDestroy, TemplateRef, ElementRef, OutputRef, AfterContentInit, OnInit, TrackByFunction, OnChanges, SimpleChanges, PipeTransform } from '@angular/core';
import * as _atomchat_io_ui_design_system from '@atomchat-io/ui-design-system';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { MatCheckboxChange, MatCheckbox } from '@angular/material/checkbox';
import { ControlValueAccessor } from '@angular/forms';
import { MatRadioChange, MatRadioButton } from '@angular/material/radio';
import { MatSlideToggleChange, MatSlideToggle } from '@angular/material/slide-toggle';
import { DialogConfig, DialogRef } from '@angular/cdk/dialog';
import { ComponentType } from '@angular/cdk/portal';
import * as _fortawesome_fontawesome_common_types from '@fortawesome/fontawesome-common-types';
import * as i1 from '@angular/material/badge';
import { MatBadgePosition } from '@angular/material/badge';
import * as _angular_material_button_toggle from '@angular/material/button-toggle';
import { MatButtonToggle } from '@angular/material/button-toggle';
import { Platform } from '@angular/cdk/platform';
import { Observable, Subject, ReplaySubject } from 'rxjs';
import { CdkTable, CdkTableDataSourceInput, CdkCell, CdkFooterRow, CdkHeaderRow, CdkRow, CdkColumnDef, CdkHeaderCellDef, CdkCellDef, CdkHeaderCell, CdkHeaderRowDef, CdkRowDef, CdkNoDataRow } from '@angular/cdk/table';
import { MatSortable, SortDirection, MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';

type AtomButtonIconPosition = 'start' | 'end';
/**
 * Directive to mark projected content as the start or end icon slot of `atom-button`, `atom-link-button`, or `atom-icon-button`.
 * Use with any icon component (e.g. fa-icon, mat-icon) for agnostic icon injection.
 *
 * `atomButtonIcon` without a value is treated as **start** (same as `atomButtonIcon="start"`).
 *
 * @example
 * ```html
 * <button atom-button>
 *   <fa-icon atomButtonIcon="start" [icon]="['fas', 'plus']"></fa-icon>
 *   Label
 *   <fa-icon atomButtonIcon="end" [icon]="['fas', 'chevron-down']"></fa-icon>
 * </button>
 *
 * <button atom-icon-button>
 *   <fa-icon atomButtonIcon [icon]="['fas', 'plus']"></fa-icon>
 * </button>
 * ```
 */
declare class AtomButtonIconDirective {
    /** Position of the icon in dual-slot layouts; omitted / empty means **start**. */
    readonly position: _angular_core.InputSignalWithTransform<AtomButtonIconPosition, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomButtonIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomButtonIconDirective, "[atomButtonIcon]", never, { "position": { "alias": "atomButtonIcon"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Spinner position when `loading` is true (solid `atom-button` only). */
type AtomInteractiveLoadingPosition = 'start' | 'end';
/** Solid / icon button type: primary, secondary, tertiary. */
type AtomButtonType = 'primary' | 'secondary' | 'tertiary';
/** Solid / icon button semantic palette: default (base) or critical (destructive). */
type AtomButtonColor = 'base' | 'destructive';
/** Solid / icon button size (host + typography / icon scale). */
type AtomButtonSize = 'xs' | 's' | 'm' | 'l' | 'xl';

/** BEM block string for `AtomSolidButtonDirective` (`atom-button` vs `atom-icon-button` vs `atom-link-button`). */
type AtomButtonHostPrefix = 'atom-button' | 'atom-icon-button' | 'atom-link-button';

/**
 * Cross-component host directive that exposes a `label` input and a trimmed
 * version of it. Composed via `hostDirectives` by components that render a
 * fallback text label (e.g. `atom-button`, `atom-link-button`, `atom-chip`).
 */
declare class AtomLabelHostDirective {
    readonly label: _angular_core.InputSignal<string>;
    readonly trimmedLabel: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomLabelHostDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomLabelHostDirective, never, never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * @deprecated Use {@link AtomLabelHostDirective} from `@atomchat-io/ui-design-system`.
 * Kept as a transition alias so existing button/link-button consumers keep
 * compiling. Resolves to the same class identity, so DI lookups via either
 * name return the same instance.
 */
declare const AtomButtonLabelHostDirective: typeof AtomLabelHostDirective;
type AtomButtonLabelHostDirective = AtomLabelHostDirective;

/**
 * Disabled state and host attributes for native `<button>` / `<a>` interactive hosts.
 */
declare class AtomDisabledHostDirective {
    private readonly hostEl;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaDisabledAttr: _angular_core.Signal<"true" | null>;
    readonly nativeDisabledAttr: _angular_core.Signal<true | null>;
    readonly anchorTabindexAttr: _angular_core.Signal<-1 | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDisabledHostDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDisabledHostDirective, never, never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** FontAwesome icon accepted anywhere in the design system: full definition or `[prefix, iconName]` tuple. */
type AtomIconSpec = IconDefinition | [string, string];

/**
 * Start/end icon slots + optional `[icon]` input for `atom-button` / `atom-link-button`.
 */
declare class AtomDualIconSlotHostDirective {
    readonly icon: _angular_core.InputSignal<AtomIconSpec | undefined>;
    readonly iconPosition: _angular_core.InputSignal<AtomButtonIconPosition>;
    private readonly projectedIcons;
    readonly hasProjectedStartIcon: _angular_core.Signal<boolean>;
    readonly hasProjectedEndIcon: _angular_core.Signal<boolean>;
    readonly showInputIconStart: _angular_core.Signal<boolean>;
    readonly showInputIconEnd: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDualIconSlotHostDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDualIconSlotHostDirective, never, never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconPosition": { "alias": "iconPosition"; "required": false; "isSignal": true; }; }, {}, ["projectedIcons"], never, true, never>;
}

/**
 * Loading state and `aria-busy` for interactive button hosts.
 */
declare class AtomLoadingHostDirective {
    protected readonly hostPrefix: AtomButtonHostPrefix;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    readonly loadingPosition: _angular_core.InputSignal<AtomInteractiveLoadingPosition>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomLoadingHostDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomLoadingHostDirective, never, never, { "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingPosition": { "alias": "loadingPosition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Optional accessible name when visible text is insufficient.
 */
declare class AtomOptionalAriaLabelHostDirective {
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomOptionalAriaLabelHostDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomOptionalAriaLabelHostDirective, never, never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Required accessible name (e.g. icon-only controls).
 */
declare class AtomRequiredAriaLabelHostDirective {
    readonly ariaLabel: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomRequiredAriaLabelHostDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomRequiredAriaLabelHostDirective, never, never, { "ariaLabel": { "alias": "ariaLabel"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Single icon slot host for `atom-icon-button`. Composed via `hostDirectives`
 * so the icon-button can detect a projected `[atomButtonIcon]` marker and
 * fall back to an `[icon]` input when nothing is projected.
 */
declare class AtomSingleIconSlotHostDirective {
    readonly icon: _angular_core.InputSignal<AtomIconSpec | undefined>;
    private readonly projectedIcon;
    readonly hasProjectedIcon: _angular_core.Signal<boolean>;
    readonly showInputIcon: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSingleIconSlotHostDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSingleIconSlotHostDirective, never, never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, ["projectedIcon"], never, true, never>;
}

/**
 * Solid / icon-button variant + color + size: BEM classes on the host.
 * The BEM block comes from {@link ATOM_BUTTON_HOST_PREFIX} (provided by the host component).
 *
 * When `size` is not explicitly bound, the directive inherits the size from
 * a parent `atom-toolbar` via `ATOM_COMPONENT_SIZE` (if present).
 */
declare class AtomSolidButtonDirective {
    private readonly hostPrefix;
    private readonly toolbarSize;
    readonly variant: _angular_core.InputSignal<"" | AtomButtonType>;
    readonly color: _angular_core.InputSignal<AtomButtonColor>;
    readonly size: _angular_core.InputSignal<AtomButtonSize | undefined>;
    readonly effectiveSize: _angular_core.Signal<AtomButtonSize>;
    readonly solidHostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSolidButtonDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSolidButtonDirective, never, never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtomButtonComponent {
    protected readonly blockPrefix: "atom-button";
    protected readonly loadingHost: AtomLoadingHostDirective;
    protected readonly labelHost: _atomchat_io_ui_design_system.AtomLabelHostDirective;
    protected readonly dualIcon: AtomDualIconSlotHostDirective;
    protected readonly showLoadingSpinner = true;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomButtonComponent, "button[atom-button], a[atom-button]", never, {}, {}, never, ["[atomButtonIcon='start'], .material-icons:not([iconPositionEnd]):not([atomButtonIcon='end']), mat-icon:not([iconPositionEnd]):not([atomButtonIcon='end']), [matButtonIcon]:not([iconPositionEnd]):not([atomButtonIcon='end'])", "*", "[atomButtonIcon='end'], .material-icons:not([iconPositionStart]):not([atomButtonIcon='start']), mat-icon:not([iconPositionStart]):not([atomButtonIcon='start']), [matButtonIcon]:not([iconPositionStart]):not([atomButtonIcon='start'])"], true, [{ directive: typeof AtomDisabledHostDirective; inputs: { "disabled": "disabled"; }; outputs: {}; }, { directive: typeof AtomLoadingHostDirective; inputs: { "loading": "loading"; "loadingPosition": "loadingPosition"; }; outputs: {}; }, { directive: typeof AtomOptionalAriaLabelHostDirective; inputs: { "ariaLabel": "ariaLabel"; }; outputs: {}; }, { directive: typeof AtomLabelHostDirective; inputs: { "label": "label"; }; outputs: {}; }, { directive: typeof AtomSolidButtonDirective; inputs: { "variant": "atom-button"; "color": "color"; "size": "size"; }; outputs: {}; }, { directive: typeof AtomDualIconSlotHostDirective; inputs: { "icon": "icon"; "iconPosition": "iconPosition"; }; outputs: {}; }]>;
}

/**
 * Icon-only button using the same `--buttons-*` variants and sizes (xs–xl) as `atom-button`.
 * `ariaLabel` is required (accessible name).
 */
declare class AtomIconButtonComponent {
    protected readonly blockPrefix: "atom-icon-button";
    protected readonly loadingHost: AtomLoadingHostDirective;
    protected readonly singleIcon: AtomSingleIconSlotHostDirective;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomIconButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomIconButtonComponent, "button[atom-icon-button], a[atom-icon-button]", never, {}, {}, never, ["[atomButtonIcon], [atombuttonicon], mat-icon, .material-icons"], true, [{ directive: typeof AtomDisabledHostDirective; inputs: { "disabled": "disabled"; }; outputs: {}; }, { directive: typeof AtomLoadingHostDirective; inputs: { "loading": "loading"; }; outputs: {}; }, { directive: typeof AtomRequiredAriaLabelHostDirective; inputs: { "ariaLabel": "ariaLabel"; }; outputs: {}; }, { directive: typeof AtomSingleIconSlotHostDirective; inputs: { "icon": "icon"; }; outputs: {}; }, { directive: typeof AtomSolidButtonDirective; inputs: { "variant": "atom-icon-button"; "color": "color"; "size": "size"; }; outputs: {}; }]>;
}

/** Link button size: s (label), l (caption). */
type AtomLinkButtonSize = 's' | 'l';
declare class AtomLinkButtonComponent {
    protected readonly loadingHost: AtomLoadingHostDirective;
    protected readonly labelHost: _atomchat_io_ui_design_system.AtomLabelHostDirective;
    protected readonly dualIcon: AtomDualIconSlotHostDirective;
    readonly size: _angular_core.InputSignal<AtomLinkButtonSize>;
    protected readonly blockPrefix: "atom-link-button";
    protected readonly showLoadingSpinner = false;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomLinkButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomLinkButtonComponent, "button[atom-link-button], a[atom-link-button]", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["[atomButtonIcon='start'], .material-icons:not([iconPositionEnd]):not([atomButtonIcon='end']), mat-icon:not([iconPositionEnd]):not([atomButtonIcon='end']), [matButtonIcon]:not([iconPositionEnd]):not([atomButtonIcon='end'])", "*", "[atomButtonIcon='end'], .material-icons:not([iconPositionStart]):not([atomButtonIcon='start']), mat-icon:not([iconPositionStart]):not([atomButtonIcon='start']), [matButtonIcon]:not([iconPositionStart]):not([atomButtonIcon='start'])"], true, [{ directive: typeof AtomDisabledHostDirective; inputs: { "disabled": "disabled"; }; outputs: {}; }, { directive: typeof AtomLoadingHostDirective; inputs: { "loading": "loading"; }; outputs: {}; }, { directive: typeof AtomOptionalAriaLabelHostDirective; inputs: { "ariaLabel": "ariaLabel"; }; outputs: {}; }, { directive: typeof AtomLabelHostDirective; inputs: { "label": "label"; }; outputs: {}; }, { directive: typeof AtomDualIconSlotHostDirective; inputs: { "icon": "icon"; "iconPosition": "iconPosition"; }; outputs: {}; }]>;
}

type AtomSelectionControlSize = 'small' | 'medium';
declare abstract class SelectionControlBaseDirective<TChange extends {
    checked: boolean;
}> implements ControlValueAccessor, AfterViewInit {
    readonly size: _angular_core.InputSignal<AtomSelectionControlSize>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tabIndex: _angular_core.InputSignalWithTransform<number, string | number>;
    /** Standalone mode (no FormControl / ngModel on this host): initial and one-way value from the parent. */
    readonly checked: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly description: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /** Optional message shown in the error row when the control is in an error state. */
    readonly errorText: _angular_core.InputSignal<string | undefined>;
    readonly change: _angular_core.OutputEmitterRef<TChange>;
    readonly checkedChange: _angular_core.OutputEmitterRef<boolean>;
    /**
     * `undefined` until `ngAfterViewInit` resolves the host `NgControl` without creating an injector
     * cycle with `NG_VALUE_ACCESSOR` (see NG0200).
     */
    private readonly ngControlRef;
    private readonly injector;
    /** Single source of truth for the checked value regardless of binding mode. */
    private readonly _value;
    private readonly disabledFromCva;
    protected onChange: (value: boolean) => void;
    protected onTouched: () => void;
    constructor();
    readonly isErrorState: _angular_core.Signal<boolean>;
    readonly displayChecked: _angular_core.Signal<boolean>;
    readonly displayErrorText: _angular_core.Signal<string>;
    readonly showErrorRow: _angular_core.Signal<boolean>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    ngAfterViewInit(): void;
    writeValue(value: boolean | null): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onControlChange(event: TChange): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectionControlBaseDirective<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SelectionControlBaseDirective<any>, never, never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "tabIndex": { "alias": "tabIndex"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "errorText": { "alias": "errorText"; "required": false; "isSignal": true; }; }, { "change": "change"; "checkedChange": "checkedChange"; }, never, never, true, never>;
}

/**
 * Structural marker for components that represent a selectable control
 * (atom-checkbox, atom-radio-button, atom-toggle). It exists exclusively to
 * enable defensive dev-mode diagnostics in container components such as
 * atom-list-item — specifically, to detect when a selection control is
 * projected but selection mode is not active.
 *
 * IMPORTANT — distinction from the rejected AtomSelectionControlMarkerDirective:
 *
 * The previously rejected marker was intended to ACTIVATE selection
 * semantics on the list-item (auto-detection-as-activation). This directive
 * does NOT activate anything. It is read only by a dev-mode console warning
 * inside atom-list-item. In production builds, the directive's presence has
 * no observable effect:
 *
 *   - It does not influence selectionMode() resolution.
 *   - It does not modify ARIA, role, or any other host attribute.
 *   - It does not introduce runtime behavior in production.
 *
 * It is applied via hostDirectives on the three control components because
 * hostDirectives composes cleanly with the existing
 * SelectionControlBaseDirective inheritance (checkbox / toggle) and with
 * atom-radio-button's lack of that base, without requiring any refactor of
 * either path.
 */
declare class AtomSelectableControlDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectableControlDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSelectableControlDirective, never, never, {}, {}, never, never, true, never>;
}

/**
 * @deprecated Use `AtomSelectionControlSize` instead and bind it to the `size`
 * input of `AtomCheckboxComponent`. The `AtomCheckboxSize` type alias will be
 * removed in a future major version.
 */
type AtomCheckboxSize = AtomSelectionControlSize;
type AtomCheckboxChange = MatCheckboxChange;
declare class CheckboxComponent extends SelectionControlBaseDirective<MatCheckboxChange> {
    readonly indeterminate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly matCheckbox: _angular_core.Signal<MatCheckbox | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CheckboxComponent, "atom-checkbox", never, { "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; }, {}, never, ["[atomLabel]", "[atomDescription]"], true, [{ directive: typeof AtomSelectableControlDirective; inputs: {}; outputs: {}; }]>;
}

/**
 * Marker directive for the label slot in atom-selection-control-label.
 * Use on projected content: <span atomLabel>My label</span>
 * Alternatively use the component's [label] input.
 */
declare class AtomLabelDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomLabelDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomLabelDirective, "[atomLabel]", never, {}, {}, never, never, true, never>;
}

/**
 * Marker directive for the description slot in atom-selection-control-label.
 * Use on projected content: <span atomDescription>Helper text</span>
 * Alternatively use the component's [description] input.
 */
declare class AtomDescriptionDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDescriptionDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDescriptionDirective, "[atomDescription]", never, {}, {}, never, never, true, never>;
}

/**
 * Shared label/description layout for checkable controls (Radio, Checkbox, Toggle).
 * Inputs and content projection are mutually exclusive: projection takes priority.
 * When content with atomLabel / atomDescription is projected, inputs are ignored.
 * Reusable across atom-radio-button, atom-checkbox, atom-toggle.
 */
declare class AtomSelectionControlLabelComponent {
    /** Primary label (used only when no content is projected with atomLabel). Always trimmed. */
    readonly label: _angular_core.InputSignalWithTransform<string | undefined, string | undefined>;
    /** Secondary description (used only when no content is projected with atomDescription). Always trimmed. */
    readonly description: _angular_core.InputSignalWithTransform<string | undefined, string | undefined>;
    /** Projected label detected via directive — projection takes priority over input */
    readonly labelRef: _angular_core.Signal<AtomLabelDirective | undefined>;
    /** Projected description detected via directive — projection takes priority over input */
    readonly descriptionRef: _angular_core.Signal<AtomDescriptionDirective | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectionControlLabelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSelectionControlLabelComponent, "atom-selection-control-label", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, ["labelRef", "descriptionRef"], ["[atomLabel]", "[atomDescription]"], true, never>;
}

/**
 * Provider to initialize the icon set.
 * It is used as an app initializer to ensure that the icon set is initialized before the app starts.
 */
declare function provideDesignSystemIcons(): EnvironmentProviders;

declare const ATOM_ICONS_SUBSET: ReadonlyArray<IconDefinition>;

interface AtomRadioGroupApi {
    value: () => unknown;
    setValue: (v: unknown, event?: AtomRadioChange) => void;
    disabled: () => boolean;
    touch: () => void;
    /** Name for native radio inputs (same name = same group for a11y/keyboard). */
    name: () => string;
}
type AtomRadioGroupOrientation = 'vertical' | 'horizontal';
declare class AtomRadioGroupComponent implements ControlValueAccessor, AtomRadioGroupApi {
    private readonly buttons;
    /** Disabled state for the whole group (can be overridden by form) */
    readonly disabledInput: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    /** Name for native radio inputs; same name groups radios for a11y/keyboard. */
    readonly nameInput: _angular_core.InputSignal<string>;
    /** Layout orientation for child radios. */
    readonly orientation: _angular_core.InputSignal<AtomRadioGroupOrientation>;
    /** Emits when the selected value changes due to user interaction */
    readonly change: _angular_core.OutputEmitterRef<AtomRadioChange>;
    readonly value: _angular_core.WritableSignal<unknown>;
    readonly groupDisabled: _angular_core.WritableSignal<boolean>;
    private readonly instanceId;
    /** Name to pass to mat-radio-button (bypass: we don't use mat-radio-group, but native name still groups). */
    name: () => string;
    private onChange;
    private onTouched;
    /** Called by atom-radio-button when selected (reactive forms binding) */
    setValue(v: unknown, event?: AtomRadioChange): void;
    touch: () => void;
    writeValue(value: unknown): void;
    registerOnChange(fn: (value: unknown) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /** Expose disabled for children: form disabled wins over input */
    disabled: () => boolean;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomRadioGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomRadioGroupComponent, "atom-radio-group", never, { "disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; "nameInput": { "alias": "nameInput"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; }, { "change": "change"; }, ["buttons"], ["*"], true, never>;
}

type AtomRadioButtonSize = 'small' | 'medium';
type AtomRadioChange = MatRadioChange;
declare class AtomRadioButtonComponent {
    private static nextId;
    private readonly uniqueName;
    private readonly groupFromInject;
    private readonly groupFromParent;
    /** Resolved group: set by parent via setGroup (projected content) or from DI. */
    private readonly group;
    /** Called by atom-radio-group so projected buttons get the correct group (DI doesn't see the group). */
    setGroup(api: AtomRadioGroupApi | null): void;
    /** Value for the radio (used in groups and for reactive forms) */
    readonly value: _angular_core.InputSignal<unknown>;
    /** Checked state when used standalone (ignored when inside atom-radio-group) */
    readonly checked: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Whether the radio is disabled (or use group disabled when inside atom-radio-group) */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Whether the radio is in an error state */
    readonly error: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Size: "small" (16px) or "medium" (24px) */
    readonly size: _angular_core.InputSignal<AtomRadioButtonSize>;
    /** Primary label */
    readonly label: _angular_core.InputSignal<string | undefined>;
    /** Optional description below the label */
    readonly description: _angular_core.InputSignal<string | undefined>;
    /** Emitted when selection changes (emits value) */
    readonly change: _angular_core.OutputEmitterRef<AtomRadioChange>;
    readonly hasLabelOrDescription: _angular_core.Signal<boolean>;
    /** Checked: from group value when inside atom-radio-group, else from [checked] input */
    readonly isChecked: _angular_core.Signal<boolean>;
    /** Disabled: own input or group disabled when inside atom-radio-group */
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    /** Name for native radio: group name when inside atom-radio-group, otherwise a unique auto-generated name. */
    readonly effectiveName: _angular_core.Signal<string>;
    readonly matRadioButton: _angular_core.Signal<MatRadioButton | undefined>;
    onChange(event: MatRadioChange): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomRadioButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomRadioButtonComponent, "atom-radio-button", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, { "change": "change"; }, never, ["[atomLabel]", "[atomDescription]"], true, [{ directive: typeof AtomSelectableControlDirective; inputs: {}; outputs: {}; }]>;
}

/** Token to inject the parent atom-radio-group from an atom-radio-button (optional). */
declare const ATOM_RADIO_GROUP: InjectionToken<AtomRadioGroupApi>;

type AtomToggleChange = MatSlideToggleChange;
declare class AtomToggleComponent extends SelectionControlBaseDirective<MatSlideToggleChange> {
    readonly matSlideToggle: _angular_core.Signal<MatSlideToggle | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomToggleComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomToggleComponent, "atom-toggle", never, {}, {}, never, ["[atomLabel]", "*", "[atomDescription]"], true, [{ directive: typeof AtomSelectableControlDirective; inputs: {}; outputs: {}; }]>;
}

type AtomCardPadding = 'none' | 's' | 'm' | 'l';
declare class AtomCardComponent {
    /** Variant of the card. Only 'default' in v1. */
    readonly variant: _angular_core.InputSignal<"default">;
    /** Enables interactive (clickable) state on the full card. */
    readonly interactive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Internal base spacing when content is projected directly (no sub-components).
     * Sub-components (atom-card-header, atom-card-body, etc.) use their own internal padding.
     */
    readonly padding: _angular_core.InputSignal<AtomCardPadding>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomCardComponent, "atom-card", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "interactive": { "alias": "interactive"; "required": false; "isSignal": true; }; "padding": { "alias": "padding"; "required": false; "isSignal": true; }; }, {}, never, ["atom-card-header", "atom-card-media", "atom-card-body", "atom-card-footer", "*"], true, never>;
}

/**
 * Shared directive that encapsulates the headline + supportingText input pair.
 *
 * Composed via `hostDirectives` in components that render a label/description block.
 * Each host can alias `supportingText` to a domain-appropriate name:
 *   - `atom-card-header` → exposes as `supportingText`
 *   - `atom-card-body`   → exposes as `subhead`
 */
declare class AtomCardTextDirective {
    /** Primary label / headline text. */
    readonly headline: _angular_core.InputSignal<string | undefined>;
    /** Secondary text rendered below the headline. */
    readonly supportingText: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardTextDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCardTextDirective, "[atomCardText]", never, { "headline": { "alias": "headline"; "required": false; "isSignal": true; }; "supportingText": { "alias": "supportingText"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Marker directive for the `start/leading` slot in `atom-card-header`.
 * Apply as attribute: `<div atomCardHeaderStart>...</div>`
 */
declare class AtomCardHeaderStartDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardHeaderStartDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCardHeaderStartDirective, "[atomCardHeaderStart]", never, {}, {}, never, never, true, never>;
}
/**
 * Marker directive for the full `text` slot in `atom-card-header`.
 * When projected, overrides the `headline` and `supportingText` inputs.
 * Apply as attribute: `<div atomCardHeaderText>...</div>`
 */
declare class AtomCardHeaderTextDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardHeaderTextDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCardHeaderTextDirective, "[atomCardHeaderText]", never, {}, {}, never, never, true, never>;
}
/**
 * Marker directive for the `end/trailing` slot in `atom-card-header`.
 * Apply as attribute: `<div atomCardHeaderEnd>...</div>`
 */
declare class AtomCardHeaderEndDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardHeaderEndDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCardHeaderEndDirective, "[atomCardHeaderEnd]", never, {}, {}, never, never, true, never>;
}
declare class AtomCardHeaderComponent {
    protected readonly text: AtomCardTextDirective;
    /**
     * Detected when content is projected via `[atomCardHeaderText]`.
     * When truthy, `headline` and `supportingText` inputs are ignored.
     */
    protected readonly hasCustomText: _angular_core.Signal<AtomCardHeaderTextDirective | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomCardHeaderComponent, "atom-card-header", never, {}, {}, ["hasCustomText"], ["[atomCardHeaderStart]", "[atomCardHeaderText]", "[atomCardHeaderEnd]"], true, [{ directive: typeof AtomCardTextDirective; inputs: { "headline": "headline"; "supportingText": "supportingText"; }; outputs: {}; }]>;
}

/**
 * Marker directive for the headline slot in `atom-card-body`.
 * When projected, overrides the `headline` input.
 * Apply as attribute: `<div atomCardBodyHeadline>...</div>`
 */
declare class AtomCardBodyHeadlineDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardBodyHeadlineDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCardBodyHeadlineDirective, "[atomCardBodyHeadline]", never, {}, {}, never, never, true, never>;
}
/**
 * Marker directive for the subhead slot in `atom-card-body`.
 * When projected, overrides the `subhead` input.
 * Apply as attribute: `<div atomCardBodySubhead>...</div>`
 */
declare class AtomCardBodySubheadDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardBodySubheadDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCardBodySubheadDirective, "[atomCardBodySubhead]", never, {}, {}, never, never, true, never>;
}
/**
 * Marker directive for the body text slot in `atom-card-body`.
 * When projected, overrides the `text` input.
 * Apply as attribute: `<div atomCardBodyText>...</div>`
 */
declare class AtomCardBodyTextDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardBodyTextDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCardBodyTextDirective, "[atomCardBodyText]", never, {}, {}, never, never, true, never>;
}
declare class AtomCardBodyComponent {
    protected readonly atomText: AtomCardTextDirective;
    /** Body text — regular, label size, card-fg-secondary. Overridden by `atomCardBodyText` slot. */
    readonly text: _angular_core.InputSignal<string | undefined>;
    protected readonly hasCustomHeadline: _angular_core.Signal<AtomCardBodyHeadlineDirective | undefined>;
    protected readonly hasCustomSubhead: _angular_core.Signal<AtomCardBodySubheadDirective | undefined>;
    protected readonly hasCustomText: _angular_core.Signal<AtomCardBodyTextDirective | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardBodyComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomCardBodyComponent, "atom-card-body", never, { "text": { "alias": "text"; "required": false; "isSignal": true; }; }, {}, ["hasCustomHeadline", "hasCustomSubhead", "hasCustomText"], ["[atomCardBodyHeadline]", "[atomCardBodySubhead]", "[atomCardBodyText]", "*"], true, [{ directive: typeof AtomCardTextDirective; inputs: { "headline": "headline"; "supportingText": "subhead"; }; outputs: {}; }]>;
}

type AtomCardFooterVariant = 'dynamic-content' | 'ctas';
/**
 * Marker directive for the `dynamic-content` variant slot in `atom-card-footer`.
 * Apply as attribute: `<div atomCardFooterDynamic>...</div>`
 */
declare class AtomCardFooterDynamicDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardFooterDynamicDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCardFooterDynamicDirective, "[atomCardFooterDynamic]", never, {}, {}, never, never, true, never>;
}
declare class AtomCardFooterComponent {
    /** Footer variant: 'ctas' (default) renders action buttons; 'dynamic-content' renders freeform content. */
    readonly variant: _angular_core.InputSignal<AtomCardFooterVariant>;
    /** When true, CTA buttons stretch to fill the available width equally. */
    readonly buttonsFill: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Size applied to all CTA buttons. */
    readonly buttonSize: _angular_core.InputSignal<AtomButtonSize>;
    /** Primary CTA label. Ignored when `button[atom-button]` elements are projected. */
    readonly primaryActionText: _angular_core.InputSignal<string | undefined>;
    /** Primary CTA color palette: 'base' (default) or 'destructive'. For other variants, use projection. */
    readonly primaryActionColor: _angular_core.InputSignal<AtomButtonColor>;
    /** Disables the primary CTA button. */
    readonly primaryActionDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Secondary CTA label (optional). Ignored when `button[atom-button]` elements are projected. */
    readonly secondaryActionText: _angular_core.InputSignal<string | undefined>;
    /** Secondary CTA color palette: 'base' (default) or 'destructive'. For other variants, use projection. */
    readonly secondaryActionColor: _angular_core.InputSignal<AtomButtonColor>;
    /** Disables the secondary CTA button. */
    readonly secondaryActionDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Detected when `button[atom-button]` elements are projected — overrides CTA inputs. */
    private readonly projectedButtons;
    protected readonly hasCustomActions: _angular_core.Signal<boolean>;
    /** Detected when `[atomCardFooterDynamic]` is projected — takes over dynamic-content area. */
    protected readonly hasCustomDynamic: _angular_core.Signal<AtomCardFooterDynamicDirective | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardFooterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomCardFooterComponent, "atom-card-footer", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "buttonsFill": { "alias": "buttonsFill"; "required": false; "isSignal": true; }; "buttonSize": { "alias": "buttonSize"; "required": false; "isSignal": true; }; "primaryActionText": { "alias": "primaryActionText"; "required": false; "isSignal": true; }; "primaryActionColor": { "alias": "primaryActionColor"; "required": false; "isSignal": true; }; "primaryActionDisabled": { "alias": "primaryActionDisabled"; "required": false; "isSignal": true; }; "secondaryActionText": { "alias": "secondaryActionText"; "required": false; "isSignal": true; }; "secondaryActionColor": { "alias": "secondaryActionColor"; "required": false; "isSignal": true; }; "secondaryActionDisabled": { "alias": "secondaryActionDisabled"; "required": false; "isSignal": true; }; }, {}, ["projectedButtons", "hasCustomDynamic"], ["[atomCardFooterDynamic]", "*", "button[atom-button]"], true, never>;
}

type AtomCardMediaRatio = '1:1' | '4:3' | '16:9';
/**
 * Marker directive for the media content slot override in `atom-card-media`.
 * When projected, the `src` and `alt` inputs are ignored.
 * Apply as attribute: `<div atomCardMediaContent>...</div>`
 */
declare class AtomCardMediaContentDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardMediaContentDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCardMediaContentDirective, "[atomCardMediaContent]", never, {}, {}, never, never, true, never>;
}
declare class AtomCardMediaComponent {
    /** Image source URL. Ignored when `[atomCardMediaContent]` is projected. */
    readonly src: _angular_core.InputSignal<string | undefined>;
    /** Image alt text for accessibility. */
    readonly alt: _angular_core.InputSignal<string>;
    /** Aspect ratio of the media area. */
    readonly ratio: _angular_core.InputSignal<AtomCardMediaRatio>;
    /** Detected when custom content is projected — overrides src/alt inputs. */
    protected readonly hasCustomContent: _angular_core.Signal<AtomCardMediaContentDirective | undefined>;
    /** CSS-safe ratio class suffix: '16:9' → '16-9'. */
    protected readonly ratioClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCardMediaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomCardMediaComponent, "atom-card-media", never, { "src": { "alias": "src"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "ratio": { "alias": "ratio"; "required": false; "isSignal": true; }; }, {}, ["hasCustomContent"], ["[atomCardMediaContent]"], true, never>;
}

/** Orientation of the divider: horizontal (default) or vertical. */
type AtomDividerOrientation = 'horizontal' | 'vertical';
declare class AtomDividerComponent {
    /**
     * Orientation of the divider.
     * Use `atom-divider="vertical"` for vertical or omit for horizontal (default).
     */
    readonly orientation: _angular_core.InputSignal<"" | AtomDividerOrientation>;
    protected readonly resolvedOrientation: _angular_core.Signal<AtomDividerOrientation>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDividerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomDividerComponent, "hr[atom-divider]", never, { "orientation": { "alias": "atom-divider"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Reasons for which an atom-dialog can be closed. */
type AtomDialogCloseReason = 'primary-action' | 'secondary-action' | 'close-button' | 'backdrop' | 'escape' | 'programmatic';
/** Typed payload emitted via `dialogRef.afterClosed()`. */
interface AtomDialogCloseEvent<T = unknown> {
    reason: AtomDialogCloseReason;
    value?: T;
}
/** Injection token to pass data into the opened dialog component. */
declare const ATOM_DIALOG_DATA: InjectionToken<any>;

/**
 * Aria label for the default close (X) button in `atom-dialog-header`.
 *
 * Provided in root with a sensible default. Override at any injector level:
 *
 * ```ts
 * providers: [
 *   { provide: ATOM_DIALOG_CLOSE_ARIA_LABEL, useValue: 'Close dialog' }
 * ]
 * ```
 */
declare const ATOM_DIALOG_CLOSE_ARIA_LABEL: InjectionToken<string>;
/**
 * Aria label for the default CTA (back/navigation) button in `atom-dialog-header`.
 *
 * Provided in root with a sensible default. Override at any injector level:
 *
 * ```ts
 * providers: [
 *   { provide: ATOM_DIALOG_CTA_ARIA_LABEL, useValue: 'Go back' }
 * ]
 * ```
 */
declare const ATOM_DIALOG_CTA_ARIA_LABEL: InjectionToken<string>;

/**
 * Service config typed against the same `DialogRef<R, T>` that `open()` returns,
 * so the CDK's `container.providers` callback is variance-compatible on spread.
 *
 * `disableClose` is re-declared here as our semantic gate (backdrop / Escape).
 * The CDK-level `disableClose` is always forced to `true` internally.
 */
type AtomDialogConfig<D = unknown, R = unknown, T = unknown> = Omit<DialogConfig<D, DialogRef<R, T>>, 'providers' | 'disableClose'> & {
    /**
     * When `true`, backdrop clicks and Escape key do NOT close the dialog.
     * Defaults to `false`.
     */
    disableClose?: boolean;
};
/**
 * Service for opening atom-dialog panels via `@angular/cdk/dialog`.
 *
 * Centralizes normative defaults (`hasBackdrop`, `restoreFocus`, CSS classes) and maps
 * backdrop/escape closes to typed `AtomDialogCloseEvent` payloads on `afterClosed()`.
 */
declare class AtomDialogService {
    private readonly dialog;
    /**
     * Opens a dialog containing the given component.
     *
     * @returns A `DialogRef` whose `afterClosed()` stream emits `AtomDialogCloseEvent<R>`.
     */
    open<T, D = unknown, R = AtomDialogCloseEvent>(component: ComponentType<T>, config?: AtomDialogConfig<D, R, T>): DialogRef<R, T>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AtomDialogService>;
}

/**
 * Declarative close directive for atom-dialog panels.
 *
 * Place on any interactive element inside a dialog to close it with a typed reason and value:
 *
 * ```html
 * <button atom-button="primary" [atomDialogClose]="formValue" reason="primary-action">
 *   Guardar
 * </button>
 * ```
 *
 * The close event is emitted on `dialogRef.afterClosed()` as `AtomDialogCloseEvent<T>`.
 *
 * Uses `inject(DialogRef, { optional: true })` so that components using this directive
 * can be rendered outside a dialog context (e.g. Storybook) without throwing.
 */
declare class AtomDialogCloseDirective {
    /** Value forwarded as `event.value` in `AtomDialogCloseEvent`. Defaults to `undefined`. */
    readonly atomDialogClose: _angular_core.InputSignal<unknown>;
    /** Semantic reason for closing. Defaults to `'close-button'`. */
    readonly reason: _angular_core.InputSignal<AtomDialogCloseReason>;
    private readonly dialogRef;
    protected close(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogCloseDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDialogCloseDirective, "[atomDialogClose]", never, { "atomDialogClose": { "alias": "atomDialogClose"; "required": false; "isSignal": true; }; "reason": { "alias": "reason"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Overrides the CTA (back/navigation) button on the left side of the header. */
declare class AtomDialogHeaderCtaDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogHeaderCtaDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDialogHeaderCtaDirective, "[atomDialogHeaderCta]", never, {}, {}, never, never, true, never>;
}
/** Overrides the icon block (center alignment only). */
declare class AtomDialogHeaderIconDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogHeaderIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDialogHeaderIconDirective, "[atomDialogHeaderIcon]", never, {}, {}, never, never, true, never>;
}
/** Overrides the title text node. */
declare class AtomDialogHeaderTitleDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogHeaderTitleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDialogHeaderTitleDirective, "[atomDialogHeaderTitle]", never, {}, {}, never, never, true, never>;
}
/** Overrides the subtitle text node (center alignment only). */
declare class AtomDialogHeaderSubtitleDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogHeaderSubtitleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDialogHeaderSubtitleDirective, "[atomDialogHeaderSubtitleDirective]", never, {}, {}, never, never, true, never>;
}
/** Overrides the entire icon + title row (center alignment only). */
declare class AtomDialogHeaderTitleRowDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogHeaderTitleRowDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDialogHeaderTitleRowDirective, "[atomDialogHeaderTitleRow]", never, {}, {}, never, never, true, never>;
}
type AtomDialogHeaderAlign = 'left' | 'center';
/**
 * Header sub-component for `atom-dialog-shell`.
 *
 * **Left alignment (default):** `[cta?] [title] [close?]` in a single row.
 * **Center alignment:** icon (opt) → title → subtitle (opt), with close and
 * back buttons positioned absolutely.
 *
 * Slot precedence: projected slots override input-driven defaults (API dual).
 * The close (X) button is NOT customizable via slot — use `hideCloseButton` to hide it.
 */
declare class AtomDialogHeaderComponent {
    /** Title text. Overridden by `[atomDialogHeaderTitle]` slot. */
    readonly title: _angular_core.InputSignal<string | undefined>;
    /** Subtitle text (center alignment). Overridden by `[atomDialogHeaderSubtitleDirective]` slot. */
    readonly subtitle: _angular_core.InputSignal<string | undefined>;
    /** FA icon for the title block (center alignment). Overridden by `[atomDialogHeaderIcon]` / `[atomDialogHeaderTitleRow]` slot. */
    readonly icon: _angular_core.InputSignal<AtomIconSpec | undefined>;
    /** When `true`, shows the default CTA (back/navigation) button. Hidden by default. */
    readonly showCtaButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** FA icon for the CTA button. Defaults to `faChevronLeft` (`<`). Only used when `showCtaButton` is true. */
    readonly ctaIcon: _angular_core.InputSignal<AtomIconSpec>;
    /** When `true`, the default close (X) button is hidden. */
    readonly hideCloseButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Layout alignment: `'left'` (default) or `'center'`. */
    readonly align: _angular_core.InputSignal<AtomDialogHeaderAlign>;
    /** Emitted when the default CTA button is clicked (e.g. back navigation). */
    readonly ctaClick: _angular_core.OutputEmitterRef<void>;
    protected readonly closeAriaLabel: string;
    protected readonly ctaAriaLabel: string;
    protected readonly hasCta: _angular_core.Signal<AtomDialogHeaderCtaDirective | undefined>;
    protected readonly hasIcon: _angular_core.Signal<AtomDialogHeaderIconDirective | undefined>;
    protected readonly hasTitle: _angular_core.Signal<AtomDialogHeaderTitleDirective | undefined>;
    protected readonly hasSubtitle: _angular_core.Signal<AtomDialogHeaderSubtitleDirective | undefined>;
    protected readonly hasTitleRow: _angular_core.Signal<AtomDialogHeaderTitleRowDirective | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomDialogHeaderComponent, "atom-dialog-header", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "showCtaButton": { "alias": "showCtaButton"; "required": false; "isSignal": true; }; "ctaIcon": { "alias": "ctaIcon"; "required": false; "isSignal": true; }; "hideCloseButton": { "alias": "hideCloseButton"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; }, { "ctaClick": "ctaClick"; }, ["hasCta", "hasIcon", "hasTitle", "hasSubtitle", "hasTitleRow"], ["[atomDialogHeaderCta]", "[atomDialogHeaderTitle]", "[atomDialogHeaderCta]", "[atomDialogHeaderTitleRow]", "[atomDialogHeaderIcon]", "[atomDialogHeaderTitle]", "[atomDialogHeaderSubtitleDirective]"], true, never>;
}

/**
 * Body sub-component for `atom-dialog-shell`.
 *
 * Scrollable content region. Grows to fill available vertical space (AC2).
 * Add `padding: var(--spacing-l)` on your content when needed.
 *
 * Accepts free content projection:
 * ```html
 * <atom-dialog-body>
 *   <p>¿Estás seguro de continuar?</p>
 * </atom-dialog-body>
 * ```
 */
declare class AtomDialogBodyComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogBodyComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomDialogBodyComponent, "atom-dialog-body", never, {}, {}, never, ["*"], true, never>;
}

/**
 * Marks the optional start/left content in the footer (e.g. selection counter).
 * Visible only in `hug` mode. Projected via `[atomDialogFooterStart]`.
 */
declare class AtomDialogFooterStartDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogFooterStartDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDialogFooterStartDirective, "[atomDialogFooterStart]", never, {}, {}, never, never, true, never>;
}
/**
 * Footer layout mode:
 * - `'hug'` (default): buttons are right-aligned, content-sized.
 * - `'fill'`: buttons stretch equally to fill the available width.
 */
type AtomDialogFooterMode = 'hug' | 'fill';
/**
 * Footer sub-component for `atom-dialog-shell`.
 *
 * Provides a consistent action area with primary and secondary CTAs that
 * automatically wire `[atomDialogClose]` with the correct semantic reasons.
 *
 * **Simple usage (inputs):**
 * ```html
 * <atom-dialog-footer
 *   primaryActionText="Confirmar"
 *   secondaryActionText="Cancelar"
 * />
 * ```
 *
 * **Override CTAs via projection** (same pattern as `atom-card-footer`):
 * Project `button[atom-button]` elements directly — they are detected via
 * `contentChildren(AtomButtonComponent)` and override the input-driven defaults.
 *
 * ```html
 * <atom-dialog-footer>
 *   <button atom-button="secondary" [atomDialogClose] [reason]="'secondary-action'">Volver</button>
 *   <button atom-button="primary" [atomDialogClose]="result" [reason]="'primary-action'">Guardar</button>
 * </atom-dialog-footer>
 * ```
 */
declare class AtomDialogFooterComponent {
    /** Button layout mode: `'hug'` (default, right-aligned) or `'fill'` (equal-width). */
    readonly mode: _angular_core.InputSignal<AtomDialogFooterMode>;
    /** Primary CTA label. Ignored when `button[atom-button]` elements are projected. */
    readonly primaryActionText: _angular_core.InputSignal<string | undefined>;
    /** Primary CTA color. Defaults to `'base'`. */
    readonly primaryActionColor: _angular_core.InputSignal<AtomButtonColor>;
    /** Disables the primary CTA. */
    readonly primaryActionDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Secondary CTA label. When absent, the secondary button is not rendered. */
    readonly secondaryActionText: _angular_core.InputSignal<string | undefined>;
    /** Secondary CTA color. Defaults to `'base'`. */
    readonly secondaryActionColor: _angular_core.InputSignal<AtomButtonColor>;
    /** Disables the secondary CTA. */
    readonly secondaryActionDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Size applied to both default CTA buttons. */
    readonly buttonSize: _angular_core.InputSignal<AtomButtonSize>;
    /** Detected when `button[atom-button]` elements are projected — overrides CTA inputs. */
    private readonly projectedButtons;
    protected readonly hasCustomActions: _angular_core.Signal<boolean>;
    protected readonly hasFooterStart: _angular_core.Signal<AtomDialogFooterStartDirective | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogFooterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomDialogFooterComponent, "atom-dialog-footer", never, { "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "primaryActionText": { "alias": "primaryActionText"; "required": false; "isSignal": true; }; "primaryActionColor": { "alias": "primaryActionColor"; "required": false; "isSignal": true; }; "primaryActionDisabled": { "alias": "primaryActionDisabled"; "required": false; "isSignal": true; }; "secondaryActionText": { "alias": "secondaryActionText"; "required": false; "isSignal": true; }; "secondaryActionColor": { "alias": "secondaryActionColor"; "required": false; "isSignal": true; }; "secondaryActionDisabled": { "alias": "secondaryActionDisabled"; "required": false; "isSignal": true; }; "buttonSize": { "alias": "buttonSize"; "required": false; "isSignal": true; }; }, {}, ["projectedButtons", "hasFooterStart"], ["[atomDialogFooterStart]", "button[atom-button]"], true, never>;
}

/**
 * Shell container for atom-dialog panels.
 *
 * Provides the outer surface (background, border, border-radius) and
 * orchestrates the stacking of header / body / footer sub-components.
 *
 * The component opened via `AtomDialogService.open()` should contain this shell:
 *
 * ```html
 * <atom-dialog-shell>
 *   <atom-dialog-header title="Confirmar acción" />
 *   <atom-dialog-body>...</atom-dialog-body>
 *   <atom-dialog-footer primaryActionText="Confirmar" secondaryActionText="Cancelar" />
 * </atom-dialog-shell>
 * ```
 */
declare class AtomDialogShellComponent {
    readonly headerDialog: _angular_core.Signal<AtomDialogHeaderComponent | undefined>;
    readonly bodyDialog: _angular_core.Signal<AtomDialogBodyComponent | undefined>;
    readonly footerDialog: _angular_core.Signal<AtomDialogFooterComponent | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDialogShellComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomDialogShellComponent, "atom-dialog-shell", never, {}, {}, ["headerDialog", "bodyDialog", "footerDialog"], ["atom-dialog-header", "atom-dialog-body", "atom-dialog-footer"], true, never>;
}

/** Data shape passed to `AtomConfirmDialogComponent` via `ATOM_DIALOG_DATA`. */
interface AtomConfirmDialogData {
    /** Dialog title. */
    title: string;
    /** Main body text. */
    description: string;
    /** Confirm button label. Defaults to `'Confirmar'`. */
    confirmText?: string;
    /** Cancel button label. Defaults to `'Cancelar'`. */
    cancelText?: string;
    /**
     * Visual mode. `'destructive'` turns the confirm button red and changes
     * the alert icon to an exclamation mark. Defaults to `'default'`.
     */
    mode?: 'default' | 'destructive';
    /** When `true`, the close (X) button in the header is hidden. Defaults to `false`. */
    hideCloseButton?: boolean;
    /** Optional alert message shown below the description. */
    alertText?: string;
    /**
     * Custom icon for the alert block. Defaults to `faCircleInfo` (default mode)
     * or `faCircleExclamation` (destructive mode).
     */
    alertIcon?: AtomIconSpec;
}
/** Result emitted when the confirm dialog closes. */
type AtomConfirmDialogResult = 'confirmed' | 'cancelled';
/**
 * Pre-built confirmation dialog component (HU-008).
 *
 * Open via `AtomDialogService`:
 * ```ts
 * dialogService.open<AtomConfirmDialogResult>(AtomConfirmDialogComponent, {
 *   data: {
 *     title: 'Confirmar acción',
 *     description: '¿Estás seguro de que querés continuar?',
 *   },
 * });
 * ```
 *
 * The result stream yields `'confirmed'` or `'cancelled'`.
 */
declare class AtomConfirmDialogComponent {
    protected readonly data: AtomConfirmDialogData;
    private readonly dialogRef;
    protected readonly confirmText: string;
    protected readonly cancelText: string;
    protected readonly mode: 'default' | 'destructive';
    protected readonly hideCloseButton: boolean;
    protected readonly buttonColor: AtomButtonColor;
    protected readonly alertIcon: AtomIconSpec;
    confirm(): void;
    cancel(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomConfirmDialogComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomConfirmDialogComponent, "atom-confirm-dialog", never, {}, {}, never, never, true, never>;
}

type AtomSpinnerSize = 'xs' | 's' | 'm' | 'l' | 'xl';

declare class AtomSpinnerComponent {
    readonly size: _angular_core.InputSignal<AtomSpinnerSize>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    protected readonly hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSpinnerComponent, "atom-spinner", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type AtomEmptyStateSize = 'small' | 'medium';
/** Slot marker for projecting a custom visual (icon or illustration). Overrides the `icon` input. */
declare class AtomEmptyStateVisualDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomEmptyStateVisualDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomEmptyStateVisualDirective, "[atomEmptyStateVisual]", never, {}, {}, never, never, true, never>;
}
/** Slot marker for projecting a custom heading. Overrides the `heading` input. */
declare class AtomEmptyStateHeadingDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomEmptyStateHeadingDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomEmptyStateHeadingDirective, "[atomEmptyStateHeading]", never, {}, {}, never, never, true, never>;
}
/** Slot marker for projecting custom supporting text. Overrides the `supportingText` input. */
declare class AtomEmptyStateSupportingTextDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomEmptyStateSupportingTextDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomEmptyStateSupportingTextDirective, "[atomEmptyStateSupportingText]", never, {}, {}, never, never, true, never>;
}
/**
 * Slot marker for projecting a custom result text. Overrides the `resultText` input.
 * Only renders in `size="small"`.
 */
declare class AtomEmptyStateResultTextDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomEmptyStateResultTextDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomEmptyStateResultTextDirective, "[atomEmptyStateResultText]", never, {}, {}, never, never, true, never>;
}
/**
 * Slot marker for replacing the entire supporting+result block as a whole.
 * When present, overrides both `[atomEmptyStateSupportingText]` and
 * `[atomEmptyStateResultText]` (and their input fallbacks).
 */
declare class AtomEmptyStateSubGroupDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomEmptyStateSubGroupDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomEmptyStateSubGroupDirective, "[atomEmptyStateSubGroup]", never, {}, {}, never, never, true, never>;
}
/**
 * Slot marker for projecting an action element. Only renders in `size="medium"`.
 *
 * MUST be applied to `button[atom-button]`, `a[atom-button]`, `button[atom-icon-button]`,
 * or `a[atom-icon-button]`. Other hosts trigger a single dev-mode warning per instance.
 *
 * The consumer is responsible for binding `(click)` (or any other event) on its own host —
 * this directive is a pure slot marker. Overrides the `actionLabel` input.
 */
declare class AtomEmptyStateActionDirective {
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomEmptyStateActionDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomEmptyStateActionDirective, "button[atomEmptyStateAction], a[atomEmptyStateAction]", never, {}, {}, never, never, true, never>;
}
/**
 * Empty State component for representing absence of content
 * (filters with no matches, empty tables, first-run states, etc.).
 *
 * Anatomy depends on size:
 * - `small`  → visual → heading → supporting text + result text (no action)
 * - `medium` → visual → heading → supporting text → action (no result text)
 *
 * Precedence per slot: projected content > input fallback. If both are
 * provided to the same slot, only the projected content renders.
 *
 * The component renders a transparent background and `width: 100%` —
 * the container is responsible for setting the final width (Figma references
 * 297 px for `small` and 400 px for `medium`).
 */
declare class AtomEmptyStateComponent {
    /** Size variant. Affects icon size, typography scale, layout gap, and which slots render. */
    readonly size: _angular_core.InputSignal<AtomEmptyStateSize>;
    /** FontAwesome icon shown in the visual container when no content is projected via `atomEmptyStateVisual`. */
    readonly icon: _angular_core.InputSignal<AtomIconSpec | null>;
    /** Heading text fallback. Overridden by `[atomEmptyStateHeading]` projection. */
    readonly heading: _angular_core.InputSignal<string>;
    /** Supporting text fallback. Overridden by `[atomEmptyStateSupportingText]` projection. */
    readonly supportingText: _angular_core.InputSignal<string>;
    /**
     * Result text fallback (e.g. the search keyword being highlighted).
     * Renders only in `size="small"`. Overridden by `[atomEmptyStateResultText]` projection.
     */
    readonly resultText: _angular_core.InputSignal<string>;
    /**
     * Renders a secondary action button with this label when no `[atomEmptyStateAction]`
     * is projected. Renders only in `size="medium"`.
     */
    readonly actionLabel: _angular_core.InputSignal<string>;
    /** Disables the fallback action button. Has no effect on a projected action. */
    readonly actionDisabled: _angular_core.InputSignal<boolean>;
    /** Emitted when the fallback action button is clicked. Projected actions handle their own events. */
    readonly actionClick: _angular_core.OutputEmitterRef<void>;
    protected readonly hasCustomVisual: _angular_core.Signal<AtomEmptyStateVisualDirective | undefined>;
    protected readonly hasCustomHeading: _angular_core.Signal<AtomEmptyStateHeadingDirective | undefined>;
    protected readonly hasCustomSupportingText: _angular_core.Signal<AtomEmptyStateSupportingTextDirective | undefined>;
    protected readonly hasCustomResultText: _angular_core.Signal<AtomEmptyStateResultTextDirective | undefined>;
    protected readonly hasCustomSubGroup: _angular_core.Signal<AtomEmptyStateSubGroupDirective | undefined>;
    protected readonly hasCustomAction: _angular_core.Signal<AtomEmptyStateActionDirective | undefined>;
    protected readonly isSmall: _angular_core.Signal<boolean>;
    protected readonly isMedium: _angular_core.Signal<boolean>;
    protected readonly hostClass: _angular_core.Signal<string>;
    constructor();
    protected onActionClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomEmptyStateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomEmptyStateComponent, "atom-empty-state", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "supportingText": { "alias": "supportingText"; "required": false; "isSignal": true; }; "resultText": { "alias": "resultText"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; "actionDisabled": { "alias": "actionDisabled"; "required": false; "isSignal": true; }; }, { "actionClick": "actionClick"; }, ["hasCustomVisual", "hasCustomHeading", "hasCustomSupportingText", "hasCustomResultText", "hasCustomSubGroup", "hasCustomAction"], ["[atomEmptyStateVisual]", "[atomEmptyStateHeading]", "[atomEmptyStateSubGroup]", "[atomEmptyStateSupportingText]", "[atomEmptyStateResultText]", "[atomEmptyStateAction]"], true, never>;
}

/**
 * Marker directive for the image slot in `atom-avatar` (type = "image" /
 * "image-border"). Apply to projected `<img>` / `<picture>` / NgOptimizedImage
 * elements to receive the `atom-avatar__image` BEM class (object-fit + sizing).
 * When present, it takes priority over the `src` input on the host component.
 *
 * Example:
 *   <atom-avatar type="image" ariaLabel="John Doe">
 *     <img atomAvatarImage [ngSrc]="avatarUrl" alt="" />
 *   </atom-avatar>
 *
 * Consumers own the `alt` text on the projected element. If the host avatar
 * already carries an `ariaLabel`, the projected image is decorative and `alt=""`
 * is appropriate; otherwise provide a descriptive alt.
 */
declare class AtomAvatarImageDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomAvatarImageDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomAvatarImageDirective, "[atomAvatarImage]", never, {}, {}, never, never, true, never>;
}

/**
 * Marker directive for the outname slot in `atom-avatar` (type = "outname").
 * Apply to projected content to receive the `atom-avatar__outname` BEM class
 * (typography + color tokens). When present, it takes priority over the
 * `outname` input on the host component.
 *
 * Example:
 *   <atom-avatar type="outname">
 *     <span atomAvatarOutname>AM</span>
 *   </atom-avatar>
 */
declare class AtomAvatarOutnameDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomAvatarOutnameDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomAvatarOutnameDirective, "[atomAvatarOutname]", never, {}, {}, never, never, true, never>;
}

type AtomAvatarSize = 'xs' | 's' | 'm' | 'l';
type AtomAvatarShape = 'circle' | 'square';
type AtomAvatarType = 'image-border' | 'image' | 'outname' | 'icon';
type AtomAvatarStatus = 'online' | 'offline' | 'image' | 'none';
declare class AtomAvatarComponent {
    /**
     * Optional ancestor label-group. When the avatar is projected into an
     * `<atom-avatar-label-group>` and no `size` input is set, the avatar inherits
     * the label-group's size so the canonical 1:1 pairing happens automatically.
     */
    private readonly labelGroup;
    /**
     * Avatar dimensions. Inside an `<atom-avatar-label-group>` the parent's
     * `size` always wins, so the wrapper stays the single source of truth for
     * the canonical 1:1 pairing. The input only takes effect for standalone
     * avatars; if unset, standalone usage falls back to `'m'`.
     */
    readonly size: _angular_core.InputSignal<AtomAvatarSize | undefined>;
    readonly shape: _angular_core.InputSignal<AtomAvatarShape>;
    readonly type: _angular_core.InputSignal<AtomAvatarType>;
    readonly src: _angular_core.InputSignal<string | undefined>;
    /**
     * Alt text for the inner `<img>` (used when no `[atomAvatarImage]` is projected).
     * If the host already carries `ariaLabel`, the inner image is decorative — leave
     * `imageAlt` empty and the component will hide it from screen readers via
     * `aria-hidden`. Otherwise provide a descriptive alt to keep the avatar
     * accessible standalone.
     */
    readonly imageAlt: _angular_core.InputSignal<string>;
    /** Pre-formatted initials, max 2 chars rendered uppercase. Consumers must derive initials from the source name. */
    readonly outname: _angular_core.InputSignal<string>;
    readonly status: _angular_core.InputSignal<AtomAvatarStatus>;
    /** When true, the status dot renders a stroke ring. Maps to the `atom-avatar--stroked` host modifier. */
    readonly stroked: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Accessible label for the host. When set, the host gets `role="img"` and `aria-label`. */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /** Projected image (via [atomAvatarImage]). Takes priority over the `src` input. */
    readonly imageRef: _angular_core.Signal<AtomAvatarImageDirective | undefined>;
    /** Projected outname (via [atomAvatarOutname]). Takes priority over the `outname` input. */
    readonly outnameRef: _angular_core.Signal<AtomAvatarOutnameDirective | undefined>;
    readonly displayedOutname: _angular_core.Signal<string>;
    /** Inner `<img>` is decorative when the host already exposes a label. */
    readonly imageDecorative: _angular_core.Signal<boolean>;
    /**
     * Resolved size used by host class binding and SCSS cascades.
     * Precedence: parent label-group `size` → explicit `size` input → `'m'` fallback.
     * Inside a label-group the wrapper always wins so consumers can't desync the
     * avatar size from the label-group typography.
     */
    readonly effectiveSize: _angular_core.Signal<AtomAvatarSize>;
    readonly hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomAvatarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomAvatarComponent, "atom-avatar", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "src": { "alias": "src"; "required": false; "isSignal": true; }; "imageAlt": { "alias": "imageAlt"; "required": false; "isSignal": true; }; "outname": { "alias": "outname"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "stroked": { "alias": "stroked"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, ["imageRef", "outnameRef"], ["[atomAvatarImage]", "[atomAvatarOutname]", "[atomAvatarIcon]", "[atomAvatarStatus]"], true, never>;
}

/**
 * Marker directive for the icon slot in `atom-avatar` (type = "icon").
 * Apply to projected content to opt-in into the icon slot and receive the
 * `atom-avatar__icon` BEM class for layout/color tokens.
 *
 * Example:
 *   <atom-avatar type="icon">
 *     <mat-icon atomAvatarIcon>person</mat-icon>
 *   </atom-avatar>
 */
declare class AtomAvatarIconDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomAvatarIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomAvatarIconDirective, "[atomAvatarIcon]", never, {}, {}, never, never, true, never>;
}

/**
 * Marker directive for the `image` status slot in `atom-avatar`
 * (status = "image"). Apply to projected `<img>` / `<picture>` /
 * NgOptimizedImage elements to receive the `atom-avatar__status-image`
 * BEM class (object-fit + sizing inside the dot container).
 *
 * Use only when `[status]="'image'"` is set on the host. The dot
 * itself keeps the size and stroke ring defined per avatar size.
 *
 * Example:
 *   <atom-avatar status="image">
 *     <img atomAvatarStatus src="brand.svg" alt="" />
 *   </atom-avatar>
 */
declare class AtomAvatarStatusDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomAvatarStatusDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomAvatarStatusDirective, "[atomAvatarStatus]", never, {}, {}, never, never, true, never>;
}

type AtomAvatarLabelGroupSize = 's' | 'm' | 'l';
/**
 * Composes a projected `atom-avatar` with `atom-selection-control-label` to
 * render the Figma `Atom / Avatar Label Groups` pattern (node 3494:38860).
 *
 * The wrapper does not own the avatar API: project an `<atom-avatar>` element
 * directly so consumers retain full access to its inputs and slot directives
 * (`[atomAvatarIcon]`, `[atomAvatarImage]`, `[atomAvatarOutname]`,
 * `[atomAvatarStatus]`).
 *
 * The `size` input is the single source of truth for the pattern: it drives
 * the label/description typography via the
 * `--selection-control-label-*-font-size|line-height|gap` CSS custom properties
 * exposed by `atom-selection-control-label`, and is also applied to the
 * projected `<atom-avatar>` automatically (the avatar injects this component
 * optionally and uses the parent's `size` whenever a label-group is present —
 * any `[size]` set on the projected avatar is ignored inside the wrapper to
 * keep the canonical 1:1 pairing).
 *
 * Label and description follow the projection-or-input contract of
 * `atom-selection-control-label`: project `[atomLabel]` / `[atomDescription]`
 * for full control or pass the `label` / `description` inputs as fallbacks.
 *
 * @example
 * ```html
 * <atom-avatar-label-group size="m" label="Alejandro" description="alejandro@atomchat.io">
 *   <atom-avatar type="image" src="..." status="online" ariaLabel="Alejandro" />
 * </atom-avatar-label-group>
 * ```
 */
declare class AtomAvatarLabelGroupComponent {
    readonly size: _angular_core.InputSignal<AtomAvatarLabelGroupSize>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly description: _angular_core.InputSignal<string | undefined>;
    readonly hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomAvatarLabelGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomAvatarLabelGroupComponent, "atom-avatar-label-group", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, ["atom-avatar"], true, never>;
}

type AtomListItemRole = 'button' | 'menuitem' | 'option' | 'radio';
/**
 * Overrides the host `role` of every descendant `atom-list-item`. Provided by
 * a container that composes list-items into a higher-level ARIA widget
 * (`atom-dropdown-menu` → `'menuitem'`, `atom-select-panel` → `'option'`,
 * etc.) using `{ provide: ATOM_LIST_ITEM_ROLE, useValue: 'menuitem' }`.
 *
 * Resolution order on the list-item:
 *   1. Injected `ATOM_LIST_ITEM_ROLE` token (this) — container takes priority.
 *   2. Self-derived role from selection semantics (`button` / `option` / `radio`).
 *
 * Rationale: the list-item is a *building block*; the ARIA role of an item
 * is a property of the enclosing widget, not of the item in isolation. The
 * container is the only place that knows whether the item lives inside a
 * `menu`, a `listbox`, a `tablist`, etc. Letting the list-item self-decide
 * forces every new container to override it imperatively (and lose to
 * Angular host bindings on the next change-detection cycle). Inversion of
 * control via this token keeps the host binding reactive and authoritative.
 */
declare const ATOM_LIST_ITEM_ROLE: InjectionToken<AtomListItemRole>;

/**
 * Structural three-zone (leading / content / trailing) Design System row.
 *
 * The Content Zone reuses `atom-selection-control-label` for label + description;
 * the Leading and Trailing zones are content-projection slots. The whole row is a
 * single interactive target (`role="button"`, keyboard-activatable). Selection
 * mode is resolved by inversion of control via an explicit `selectable` input or
 * a container-provided `ATOM_LIST_ITEM_SELECTABLE` token; `selectionType`
 * governs the `selectedChange` payload (`'checkbox'` toggles, `'radio'` sets).
 * When `disclosure` is true, the row self-renders a chevron at the end of the
 * Trailing zone, after any consumer-projected trailing content.
 */
declare class AtomListItemComponent {
    #private;
    /** Primary label rendered in the Content Zone via `atom-selection-control-label`. */
    readonly label: _angular_core.InputSignal<string | undefined>;
    /** Secondary description rendered in the Content Zone via `atom-selection-control-label`. */
    readonly description: _angular_core.InputSignal<string | undefined>;
    /**
     * Optional eyebrow rendered above the label in the Content Zone (Figma
     * "Category"). Owned by `atom-list-item` — `atom-selection-control-label` is
     * not modified.
     */
    readonly category: _angular_core.InputSignal<string | undefined>;
    /**
     * Explicit opt-in to selection mode. Tier 1 of the resolution: takes
     * precedence over an injected `ATOM_LIST_ITEM_SELECTABLE` token. Default is
     * `undefined` so the resolver can distinguish "not set" from `false`.
     */
    readonly selectable: _angular_core.InputSignal<boolean | undefined>;
    /**
     * Governs the `selectedChange` payload when selection mode is active:
     * `'checkbox'` emits the toggled value (`!selected`); `'radio'` emits `true`.
     * `'none'` matches `'checkbox'` behavior (ARIA `role="option"` + `aria-selected`)
     * but the consumer is expected to project no per-row selection glyph — the
     * "selectable row with no glyph" configuration used by single-select dropdowns.
     * Never derived from projected content (FR-017).
     */
    readonly selectionType: _angular_core.InputSignal<"radio" | "none" | "checkbox">;
    /** When true, applies the selected visual state and `aria-selected` — independent of selection mode. */
    readonly selected: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** When true, applies the brand-selected visual (orange background, brand foreground, check icon). */
    readonly selectedBrand: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** When true, suppresses activation and removes the row from the tab order. */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** When true, the row self-renders a chevron at the end of the Trailing zone. */
    readonly disclosure: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Emits when the row is activated by pointer click or by `Enter` / `Space`. */
    readonly itemClick: _angular_core.OutputEmitterRef<void>;
    /**
     * Emits the intended new `selected` value when activation occurs in selection
     * mode. Per `selectionType`: `'checkbox'` toggles, `'radio'` always emits `true`.
     */
    readonly selectedChange: _angular_core.OutputEmitterRef<boolean>;
    private readonly injectedSelectable;
    private readonly injectedRole;
    private readonly injectedDisclosure;
    /** Disclosure after applying any container-provided override. */
    readonly resolvedDisclosure: _angular_core.Signal<boolean>;
    /**
     * Resolved selection mode. Resolution order: explicit `selectable` input →
     * injected `ATOM_LIST_ITEM_SELECTABLE` token → `false`.
     */
    readonly selectionMode: _angular_core.Signal<boolean>;
    private readonly _programmaticSelectionType;
    private readonly _programmaticSelected;
    private readonly _programmaticSelectedBrand;
    /** Selection type after applying any programmatic override. */
    readonly resolvedSelectionType: _angular_core.Signal<"radio" | "none" | "checkbox">;
    /** Selected state after applying any programmatic override. */
    readonly resolvedSelected: _angular_core.Signal<boolean>;
    /** Brand-selected state — applies the brand background, brand foreground, and auto-rendered check icon. */
    readonly resolvedSelectedBrand: _angular_core.Signal<boolean>;
    /** Parent-coordinated override for selected. `undefined` clears. */
    setProgrammaticSelected(value: boolean | undefined): void;
    /** Parent-coordinated brand-selected override. Applies brand styling and auto-renders a check icon. */
    setProgrammaticSelectedBrand(value: boolean): void;
    readonly hostRole: _angular_core.Signal<AtomListItemRole>;
    readonly hostAriaSelected: _angular_core.Signal<boolean | null>;
    /** Parent-coordinated override for selectionType. `undefined` clears. */
    setProgrammaticSelectionType(value: 'checkbox' | 'radio' | 'none' | undefined): void;
    readonly hostAriaChecked: _angular_core.Signal<boolean | null>;
    protected readonly chevronIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    protected readonly checkIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    private readonly projectedSelectableControl;
    /**
     * Whether the list-item should render its own selection glyph in the
     * leading zone. Triggered for selectable rows with a checkbox/radio
     * selection type that did NOT receive an explicitly-projected control.
     * Rows with `selectionType="none"` (single-select panels) never auto-render,
     * matching the "selectable row with no glyph" contract.
     */
    protected readonly shouldAutoRenderControl: _angular_core.Signal<boolean>;
    constructor();
    protected onActivate(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomListItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomListItemComponent, "atom-list-item", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "category": { "alias": "category"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "selectionType": { "alias": "selectionType"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "selectedBrand": { "alias": "selectedBrand"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "disclosure": { "alias": "disclosure"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; "selectedChange": "selectedChange"; }, ["projectedSelectableControl"], ["[leading]", "[atomLabel]", "[atomDescription]", "[trailing]"], true, never>;
}

/** Container override that forces the trailing chevron on every descendant atom-list-item. */
declare const ATOM_LIST_ITEM_DISCLOSURE: InjectionToken<boolean>;

/**
 * Activates selection mode on a descendant `atom-list-item`. Provided by a
 * container component that sits as an *ancestor* of the list-item in the DI
 * tree — e.g. `atom-radio-group` — using `{ provide: ATOM_LIST_ITEM_SELECTABLE,
 * useValue: true }`. The list-item injects it with `{ optional: true }` and
 * uses it as the second tier of selection-mode resolution.
 *
 * Resolution order on the list-item:
 *   1. Explicit `[selectable]` input on the list-item.
 *   2. Injected `ATOM_LIST_ITEM_SELECTABLE` token (this).
 *   3. `false` (default).
 *
 * Providing `false` has the same observable effect as not providing the token
 * at all — both fall through to the list-item's `selectable` input. Useful
 * containers may use a factory to compute the value at runtime, hence the
 * `boolean` type rather than the narrower `true`. Do NOT narrow this to
 * `InjectionToken<true>`; it would foreclose `useFactory` providers where the
 * value may be dynamic.
 *
 * Note on DI direction: providers flow ancestor → descendant. Controls
 * projected INTO the list-item's slot (`atom-checkbox`, `atom-radio-button`,
 * `atom-toggle`) are descendants and CANNOT provide this token — only
 * containers wrapping the list-item can.
 */
declare const ATOM_LIST_ITEM_SELECTABLE: InjectionToken<boolean>;

/**
 * Marks projected content as the leading icon of `atom-chip`.
 * Detected by `AtomLeadingIconSlotHostDirective` via a direct
 * `contentChildren(AtomChipIconDirective)` query.
 *
 * Accepts the legacy `[atomChipIcon]` and the neutral `[atomIcon]` selectors.
 */
declare class AtomChipIconDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomChipIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomChipIconDirective, "[atomChipIcon], [atomIcon]", never, {}, {}, never, never, true, never>;
}

/**
 * Single leading-icon slot host directive for `atom-chip`. Composed via
 * `hostDirectives` to detect a projected `[atomChipIcon] / [atomIcon]` and
 * fall back to an `[icon]` input when no marker is projected.
 */
declare class AtomLeadingIconSlotHostDirective {
    readonly icon: _angular_core.InputSignal<AtomIconSpec | undefined>;
    private readonly projectedIcon;
    readonly hasProjectedIcon: _angular_core.Signal<boolean>;
    readonly showInputIcon: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomLeadingIconSlotHostDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomLeadingIconSlotHostDirective, never, never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, ["projectedIcon"], never, true, never>;
}

type AtomChipSize = 'xxs' | 'xs' | 's' | 'm' | 'l' | 'xl';
type AtomChipType = 'outlined' | 'filled';

declare class AtomChipComponent {
    protected readonly labelHost: AtomLabelHostDirective;
    protected readonly iconSlot: AtomLeadingIconSlotHostDirective;
    protected readonly closeIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    readonly size: _angular_core.InputSignal<AtomChipSize>;
    readonly type: _angular_core.InputSignal<AtomChipType>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    readonly error: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    readonly removable: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    readonly removeAriaLabel: _angular_core.InputSignal<string>;
    readonly removed: _angular_core.OutputEmitterRef<void>;
    protected readonly hostClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'atom-chip': boolean;
        'atom-chip--error': boolean;
        'atom-chip--disabled': boolean;
        'atom-chip--removable': boolean;
    }>;
    protected onRemoved(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomChipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomChipComponent, "atom-chip", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "removeAriaLabel": { "alias": "removeAriaLabel"; "required": false; "isSignal": true; }; }, { "removed": "removed"; }, never, ["[atomChipIcon], [atomIcon]", "*"], true, [{ directive: typeof AtomLabelHostDirective; inputs: { "label": "label"; }; outputs: {}; }, { directive: typeof AtomLeadingIconSlotHostDirective; inputs: { "icon": "icon"; }; outputs: {}; }]>;
}

/**
 * Default class name applied to `document.body` (or a root element) for dark semantic tokens.
 * Matches the compiled CSS when using library defaults in `styles/scss/_config.scss`
 * (`$atom-prefix: 'atom-'`, `$atom-dark-mode-class: null`).
 *
 * If you override `$atom-prefix` or `$atom-dark-mode-class` in SCSS, use the **same**
 * string when toggling the class in TypeScript.
 */
declare const ATOM_DARK_MODE_CLASS_DEFAULT = "atom-dark-mode";

type AtomBadgeType = 'neutral' | 'inbox';
type AtomBadgeState = 'enabled' | 'focused' | 'subtle';
type AtomBadgePosition = MatBadgePosition;

declare class AtomBadgeDirective {
    private readonly matBadge;
    readonly value: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly badgeType: _angular_core.InputSignal<AtomBadgeType>;
    readonly badgeState: _angular_core.InputSignal<AtomBadgeState>;
    readonly badgeMax: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly badgeHidden: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected readonly hostClasses: _angular_core.Signal<string>;
    private readonly formattedContent;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomBadgeDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomBadgeDirective, "[atomBadge]", never, { "value": { "alias": "atomBadge"; "required": false; "isSignal": true; }; "badgeType": { "alias": "atomBadgeType"; "required": false; "isSignal": true; }; "badgeState": { "alias": "atomBadgeState"; "required": false; "isSignal": true; }; "badgeMax": { "alias": "atomBadgeMax"; "required": false; "isSignal": true; }; "badgeHidden": { "alias": "atomBadgeHidden"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.MatBadge; inputs: { "matBadgeDescription": "atomBadgeDescription"; "matBadgeOverlap": "atomBadgeOverlap"; "matBadgePosition": "atomBadgePosition"; }; outputs: {}; }]>;
}

type AtomTagVariant = 'ghost' | 'filled' | 'outlined';
type AtomTagSize = 'xs' | 's' | 'm';
type AtomTagIntent = 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'brand' | 'ai' | 'disabled';
type AtomTagLeading = 'none' | 'dot' | 'icon';

declare class AtomTagComponent {
    readonly variant: _angular_core.InputSignal<AtomTagVariant>;
    readonly size: _angular_core.InputSignal<AtomTagSize>;
    readonly intent: _angular_core.InputSignal<AtomTagIntent>;
    readonly leading: _angular_core.InputSignal<AtomTagLeading>;
    /**
     * Optional FontAwesome icon for the leading slot.
     * Rendered only when `leading="icon"` and no `[atomTagLeading]` content
     * is projected. Projected content always wins over this input.
     */
    readonly icon: _angular_core.InputSignal<AtomIconSpec | undefined>;
    /**
     * Optional label. When set (non-empty after trim), takes precedence over
     * the projected `<ng-content/>` fallback.
     */
    readonly label: _angular_core.InputSignal<string | null>;
    protected readonly _hostClasses: _angular_core.Signal<string>;
    protected readonly _ariaDisabled: _angular_core.Signal<"true" | null>;
    protected readonly _showDot: _angular_core.Signal<boolean>;
    protected readonly _showIcon: _angular_core.Signal<boolean>;
    protected readonly _trimmedLabel: _angular_core.Signal<string>;
    protected readonly _hasLabelInput: _angular_core.Signal<boolean>;
    private readonly _projectedLeading;
    protected readonly _showInputIcon: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTagComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomTagComponent, "span[atomTag]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "intent": { "alias": "intent"; "required": false; "isSignal": true; }; "leading": { "alias": "leading"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, ["_projectedLeading"], ["[atomTagLeading]", "*"], true, never>;
}

/**
 * Marker directive for the leading slot of `AtomTagComponent`.
 * Added to the icon element when `leading="icon"` so the tag can detect
 * projected content via `contentChild()` and validate the slot/leading
 * combination in dev-mode.
 */
declare class AtomTagLeadingDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTagLeadingDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomTagLeadingDirective, "[atomTagLeading]", never, {}, {}, never, never, true, never>;
}

/**
 * A single segment inside `atom-segment-control`. Renders either a label
 * (optional leading/trailing icons projected with `[atomButtonIcon]`) or an
 * icon-only variant, driven by the parent control's `mode`.
 *
 * - `toggleRef` exposes the rendered `MatButtonToggle` so the parent can
 *   bridge it into `MatButtonToggleGroup._buttonToggles`.
 * - `selected` is derived from the group's `value` (mirrored through
 *   `valueChange`) rather than from `MatButtonToggle.checked`: the parent's
 *   bridge populates `_buttonToggles` AFTER this segment is constructed, so
 *   reading `checked` at construction returns `false` even for the matching
 *   toggle. `valueChange` fires when the bridge re-sets the value, so each
 *   descendant picks up the correct state on first render.
 */
declare class AtomSegmentComponent {
    protected readonly ctx: _atomchat_io_ui_design_system.AtomSegmentContext;
    protected readonly group: _angular_material_button_toggle.MatButtonToggleGroup | null;
    protected readonly dualIcon: AtomDualIconSlotHostDirective;
    protected readonly ariaLabelHost: AtomOptionalAriaLabelHostDirective;
    private readonly isBrowser;
    /** Value bound to the underlying `mat-button-toggle`. Required. */
    readonly value: _angular_core.InputSignal<string>;
    /** Disables this individual segment regardless of the group's disabled state. */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    /** Effective disabled — true when either this item or its parent group is disabled. */
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    /** Internal `MatButtonToggle` instance, consumed by the parent control's bridge. */
    readonly toggleRef: _angular_core.Signal<MatButtonToggle | undefined>;
    private readonly groupValueSignal;
    /** Whether this segment is the currently-selected one in its parent group. */
    readonly selected: _angular_core.Signal<boolean>;
    protected readonly hostClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'atom-segment': boolean;
        'atom-segment--selected': boolean;
        'atom-segment--disabled': boolean;
    }>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSegmentComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSegmentComponent, "atom-segment", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["[atomButtonIcon]:not([atomButtonIcon='end'])", "*", "[atomButtonIcon='end']"], true, [{ directive: typeof AtomDualIconSlotHostDirective; inputs: { "icon": "icon"; "iconPosition": "iconPosition"; }; outputs: {}; }, { directive: typeof AtomOptionalAriaLabelHostDirective; inputs: { "ariaLabel": "ariaLabel"; }; outputs: {}; }]>;
}

type AtomSegmentSize = 'xs' | 's' | 'm' | 'l' | 'xl';
type AtomSegmentMode = 'label' | 'icon';

/**
 * Shape exposed by `atom-segment-control` to descendant `atom-segment` items.
 * Each value is a signal so that mode/size/disabled changes propagate reactively.
 *
 * `disabled` reflects the GROUP-level disabled state. Items combine it with
 * their own `disabled` input to derive their effective disabled visual state.
 */
interface AtomSegmentContext {
    readonly mode: Signal<AtomSegmentMode>;
    readonly size: Signal<AtomSegmentSize>;
    readonly disabled: Signal<boolean>;
}
/**
 * DI token used by `atom-segment` items to read the parent control's reactive
 * `mode` and `size`. Provided by `AtomSegmentControlComponent` via `useExisting`.
 */
declare const ATOM_SEGMENT_CONTEXT: InjectionToken<AtomSegmentContext>;

/**
 * Segment control group. Wraps Material's `MatButtonToggleGroup` via
 * `hostDirectives`, inheriting selection, keyboard navigation, roving
 * tabindex, `ControlValueAccessor` and ARIA roles.
 *
 * `MatButtonToggleGroup` populates `_buttonToggles` with
 * `@ContentChildren(MatButtonToggle)`, which does not penetrate the view of
 * child components — `atom-segment` renders `mat-button-toggle` inside its
 * own view, so the query never matches. We bridge it by collecting each
 * segment's `viewChild(MatButtonToggle)` into a userland `QueryList` and
 * installing a property descriptor on the group so `_buttonToggles` always
 * reads from that bridge (a plain assignment would lose the race against
 * Angular's per-CD content-query writes).
 */
declare class AtomSegmentControlComponent implements AtomSegmentContext {
    private readonly group;
    private readonly isBrowser;
    readonly size: _angular_core.InputSignal<AtomSegmentSize>;
    readonly mode: _angular_core.InputSignal<AtomSegmentMode>;
    /** Currently selected segment value. See hostDirectives comment for the timing rationale. */
    readonly value: _angular_core.InputSignal<string | null>;
    /** Disables every item in the group; cascades through `ATOM_SEGMENT_CONTEXT`. */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    protected readonly items: _angular_core.Signal<readonly AtomSegmentComponent[]>;
    protected readonly hostClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'atom-segment-control': boolean;
    }>;
    private readonly buttonToggles;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSegmentControlComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSegmentControlComponent, "atom-segment-control", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, ["items"], ["*"], true, [{ directive: typeof _angular_material_button_toggle.MatButtonToggleGroup; inputs: { "name": "name"; }; outputs: { "change": "change"; "valueChange": "valueChange"; }; }]>;
}

/**
 * Public, logical placement axis for the tooltip.
 *
 * `start` and `end` are resolved against the document's `dir` at overlay-open
 * time (visually left/right in LTR, right/left in RTL). Corner placements
 * (e.g. `top-start`, `bottom-end`) are intentionally out of scope for v1.
 */
type TooltipPlacement = 'top' | 'end' | 'bottom' | 'start';
/**
 * Internal physical-axis enum produced after resolving {@link TooltipPlacement}
 * against `@angular/cdk/bidi`'s `Directionality`. Consumers do not see this
 * type; it is used to seed CDK `ConnectedPosition` tables and to drive
 * panel-side animation origin / placement attributes.
 */
type ResolvedTooltipPlacement = 'top' | 'right' | 'bottom' | 'left';

/**
 * Variant-specific configuration that a parent directive (Plain or Rich)
 * supplies via {@link AtomTooltipTriggerDirective.setPanelStrategy}.
 */
interface AtomTooltipPanelStrategy<Data = unknown> {
    /** Panel component to portal into the CDK overlay. */
    readonly component: new (...args: never[]) => unknown;
    /** Variant discriminator — drives ARIA model and Rich-grace behavior. */
    readonly variant: 'plain' | 'rich';
    /**
     * Produce the data payload for the next open. Returning `null` aborts the
     * open (Plain uses this to short-circuit on whitespace-only labels).
     */
    buildData(placement: ResolvedTooltipPlacement): Data | null;
    /** InjectionToken that the panel component reads its data from. */
    readonly dataToken: _angular_core.InjectionToken<Data>;
}
/**
 * Shared host-directive composed by `AtomTooltipDirective` (Plain) and
 * `AtomRichTooltipDirective` (Rich). Owns the host-event listeners, the
 * open/close state machine, CDK overlay creation, Directionality resolution,
 * single-active enforcement, Escape-to-close, `aria-describedby` toggling,
 * lifecycle outputs, and Rich-grace pointer-tracking. The panel component and
 * its data are configured by the parent directive via
 * {@link AtomTooltipTriggerDirective.setPanelStrategy}.
 */
declare class AtomTooltipTriggerDirective implements OnDestroy {
    readonly tooltipPosition: _angular_core.InputSignal<TooltipPlacement>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    private readonly host;
    private readonly overlay;
    private readonly direction;
    private readonly registry;
    private readonly motionOverrides;
    private readonly renderer;
    private readonly injector;
    private readonly _state;
    readonly isOpen: Signal<boolean>;
    private strategy;
    private overlayRef;
    private panelRef;
    private describedById;
    private prePendingShowTimer;
    private prePendingHideTimer;
    private overlayPointerListeners;
    private pointerInPanel;
    private readonly destroyRef;
    constructor();
    /**
     * Parent directives (Plain / Rich) call this exactly once during their own
     * initialization to install the variant strategy.
     */
    setPanelStrategy(strategy: AtomTooltipPanelStrategy): void;
    ngOnDestroy(): void;
    show(): void;
    hide(immediate?: boolean): void;
    handleMouseEnter(): void;
    handleMouseLeave(): void;
    handleFocusIn(): void;
    handleFocusOut(event: FocusEvent): void;
    private openNow;
    private closeNow;
    private detachOverlay;
    /**
     * Rich-only: if a grace close is pending and the overlay is still alive,
     * cancel it and restore the open state. Returns `true` when it handled the
     * event so the caller skips `show()` (which would recreate the overlay).
     * Shared by both partner-enter paths — trigger `mouseenter` and panel
     * `pointerenter` — so the trigger and panel behave as one contiguous hover
     * area while the cursor crosses the visual gap between them (Rich flicker
     * fix). The grace timer is armed only between a leave and the next enter; it
     * never runs while the cursor rests on either element.
     */
    private cancelScheduledClose;
    private startRichGraceHide;
    private cancelPendingShow;
    private cancelPendingHide;
    private attachAriaDescribedBy;
    private removeAriaDescribedBy;
    private attachEscape;
    private attachPanelPointerTracking;
    private removePanelPointerTracking;
    private delays;
    private connectedPositionsFor;
    private applyPlacement;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTooltipTriggerDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomTooltipTriggerDirective, "[atomTooltipTrigger]", never, { "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; }, { "opened": "opened"; "closed": "closed"; }, never, never, true, never>;
}

/**
 * Public attribute directive for the **Plain** tooltip variant.
 *
 * Usage:
 *
 *     <button [atomTooltip]="'Archive conversation'">…</button>
 *     <button [atomTooltip]="'Pin'" tooltipPosition="end">…</button>
 *
 * @see AtomTooltipTriggerDirective for the shared state machine + overlay logic.
 * @see AtomPlainTooltipComponent  for the floating surface this directive renders.
 */
declare class AtomTooltipDirective {
    /**
     * Label displayed in the Plain tooltip surface. Whitespace-only values
     * short-circuit the overlay open path entirely.
     */
    readonly atomTooltip: _angular_core.InputSignal<string>;
    private readonly trigger;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTooltipDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomTooltipDirective, "[atomTooltip]", never, { "atomTooltip": { "alias": "atomTooltip"; "required": true; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof AtomTooltipTriggerDirective; inputs: { "tooltipPosition": "tooltipPosition"; }; outputs: { "opened": "opened"; "closed": "closed"; }; }]>;
}

/**
 * Public attribute directive for the **Rich** tooltip variant.
 *
 * Usage (Full configuration):
 *
 *     <button
 *       atomRichTooltip
 *       [subhead]="'Channel privacy'"
 *       [supportingText]="'Private channels are visible only to invited members.'"
 *       [actionText]="'Learn more'"
 *       [showAction]="true"
 *       (actionClick)="openHelp()"
 *     >…</button>
 *
 * Usage (Without Action):
 *
 *     <button atomRichTooltip [subhead]="'…'" [supportingText]="'…'">…</button>
 *
 * Usage (Just Supporting):
 *
 *     <button atomRichTooltip [supportingText]="'…'">…</button>
 *
 * Usage (Content slot):
 *
 *     <ng-template #metricsTpl>
 *       <atom-metrics-summary [data]="…" />
 *     </ng-template>
 *     <button atomRichTooltip [extraContent]="metricsTpl">…</button>
 *
 * @see AtomTooltipTriggerDirective for the shared state machine + overlay logic.
 * @see AtomRichTooltipComponent  for the floating surface this directive renders.
 */
declare class AtomRichTooltipDirective {
    /** Optional title. Whitespace-only is treated as absent. */
    readonly subhead: _angular_core.InputSignal<string | undefined>;
    /** Optional body text. Whitespace-only is treated as absent. */
    readonly supportingText: _angular_core.InputSignal<string | undefined>;
    /**
     * Optional action-button label. Renders ONLY when also:
     *   - the consumer opts in via `showAction`, AND
     *   - `hideAction` is false.
     */
    readonly actionText: _angular_core.InputSignal<string | undefined>;
    /**
     * Opt-in flag controlling whether the in-panel action button renders.
     * Pair it with a non-empty `actionText` and an `(actionClick)` handler.
     * Defaults to false.
     */
    readonly showAction: _angular_core.InputSignal<boolean>;
    /**
     * Explicit override forcing the action button to be hidden even when
     * `showAction` is true. Defaults to false.
     */
    readonly hideAction: _angular_core.InputSignal<boolean>;
    /**
     * Content-projection slot. When provided, the template is rendered inside
     * the panel's content area below the supporting text. No layout
     * restrictions; consumes the panel's standard 8px outer inset.
     */
    readonly extraContent: _angular_core.InputSignal<TemplateRef<unknown> | undefined>;
    /**
     * Fired when the user activates the in-panel action button. Emission happens
     * BEFORE the directive closes the overlay, so a subscribed consumer can run
     * synchronous work in its handler before the tooltip detaches. Closing is
     * intrinsic to the action contract — it occurs whether or not the consumer
     * subscribes.
     */
    readonly actionClick: _angular_core.OutputEmitterRef<void>;
    private readonly trigger;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomRichTooltipDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomRichTooltipDirective, "[atomRichTooltip]", never, { "subhead": { "alias": "subhead"; "required": false; "isSignal": true; }; "supportingText": { "alias": "supportingText"; "required": false; "isSignal": true; }; "actionText": { "alias": "actionText"; "required": false; "isSignal": true; }; "showAction": { "alias": "showAction"; "required": false; "isSignal": true; }; "hideAction": { "alias": "hideAction"; "required": false; "isSignal": true; }; "extraContent": { "alias": "extraContent"; "required": false; "isSignal": true; }; }, { "actionClick": "actionClick"; }, never, never, true, [{ directive: typeof AtomTooltipTriggerDirective; inputs: { "tooltipPosition": "tooltipPosition"; }; outputs: { "opened": "opened"; "closed": "closed"; }; }]>;
}

/**
 * Per-open payload passed into the Plain tooltip panel via the CDK overlay
 * portal injector. Read by `AtomPlainTooltipComponent` through
 * {@link ATOM_PLAIN_TOOLTIP_DATA}.
 */
interface AtomPlainTooltipData {
    /** Non-empty trimmed label. */
    readonly label: string;
    /** Already-resolved physical placement; drives animation origin. */
    readonly placement: ResolvedTooltipPlacement;
}
declare const ATOM_PLAIN_TOOLTIP_DATA: InjectionToken<AtomPlainTooltipData>;
/**
 * Per-open payload passed into the Rich tooltip panel.
 */
interface AtomRichTooltipData {
    readonly subhead: string | undefined;
    readonly supportingText: string | undefined;
    readonly actionText: string | undefined;
    readonly hideAction: boolean;
    readonly extraContent: TemplateRef<unknown> | undefined;
    readonly placement: ResolvedTooltipPlacement;
    /** Reactive flag — mirrors the directive's `showAction` opt-in. */
    readonly hasActionListener: Signal<boolean>;
    /** Forwarded by the panel when the user activates the action button. */
    readonly onActionClick: () => void;
}
declare const ATOM_RICH_TOOLTIP_DATA: InjectionToken<AtomRichTooltipData>;
/**
 * Test-only override for motion delays. Defaults to `null` (= use the real
 * design tokens). Tests inject `{ show: 0, hide: 0, richGrace: 0 }` to run
 * the trigger directive synchronously and assert state transitions without
 * timing races.
 */
interface AtomTooltipMotionOverrides {
    readonly show: number;
    readonly hide: number;
    readonly richGrace: number;
}
declare const ATOM_TOOLTIP_MOTION_OVERRIDES: InjectionToken<AtomTooltipMotionOverrides | null>;

/**
 * Plain tooltip surface — rendered into the CDK overlay by
 * `AtomTooltipDirective` via `ComponentPortal`. Purely presentational: the
 * host carries `role="tooltip"` and `tabindex="-1"`, and mirrors the resolved
 * physical placement on `data-placement`. Contains no interactive descendants
 * — that is the Rich variant's domain.
 *
 * Visual contract verified against the Figma design source `variant=plain`
 * (node 3666:26718).
 */
declare class AtomPlainTooltipComponent {
    readonly data: AtomPlainTooltipData;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomPlainTooltipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomPlainTooltipComponent, "atom-plain-tooltip", never, {}, {}, never, never, true, never>;
}

/**
 * Rich tooltip surface — rendered into the CDK overlay by
 * `AtomRichTooltipDirective` through `ComponentPortal`. Presentational and
 * signal-driven: the host carries `role="dialog"`, `aria-modal="false"`, and
 * `tabindex="-1"`; `aria-labelledby` / `aria-describedby` attach only when the
 * matching slot renders. Content projection is supplied exclusively through
 * the `extraContent: TemplateRef<unknown>` field on the injected data — there
 * is no `<ng-content>` outlet because the panel is portalled outside any
 * parent template. The action button re-uses `AtomButtonComponent` in tertiary
 * variant and does not close the overlay on activation.
 *
 * Visual contract verified against the Figma source `variant=rich`
 * (node `3658:26373`) on 2026-05-13.
 */
declare class AtomRichTooltipComponent {
    readonly data: AtomRichTooltipData;
    private readonly idSeed;
    readonly titleId: string;
    readonly descriptionId: string;
    readonly renderTitle: _angular_core.Signal<boolean>;
    readonly renderSupporting: _angular_core.Signal<boolean>;
    readonly renderAction: _angular_core.Signal<boolean>;
    readonly renderExtraContent: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomRichTooltipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomRichTooltipComponent, "atom-rich-tooltip", never, {}, {}, never, never, true, never>;
}

type AtomFormFieldSize = 'xs' | 's' | 'm' | 'l' | 'xl';

/**
 * Contract that any control must implement to be hosted inside an `atom-form-field`.
 * Acts as the DI token for `atom-form-field` to discover the projected control.
 */
declare abstract class AtomFormFieldControl {
    /** Unique ID for the control, used to link labels and ARIA attributes. */
    abstract readonly controlId: string;
    /** Current size of the control. */
    abstract readonly size: Signal<AtomFormFieldSize>;
    /** Whether the control is disabled. */
    abstract readonly disabled: Signal<boolean>;
    /** Whether the control currently has a value. */
    abstract readonly hasValue: Signal<boolean>;
    /** Whether the control is in an error state. */
    abstract readonly hasError: Signal<boolean>;
    /** Whether the control has been touched. */
    abstract readonly touched: Signal<boolean>;
    /** Whether the control's value is pristine (untouched by user). */
    abstract readonly pristine: Signal<boolean>;
    /** The length of the current value (for counter). */
    abstract readonly valueLength: Signal<number>;
    /** The maximum length allowed for the value (null if no limit). */
    abstract readonly maxLength: Signal<number | null>;
    /**
     * Sets the IDs that should be referenced by the control's `aria-describedby` attribute.
     * Called by `atom-form-field` whenever the set of relevant IDs changes.
     */
    abstract setDescribedByIds(ids: string[]): void;
}

/**
 * `<atom-text-field>` — single-line text input pure control.
 * Now acts as an `AtomFormFieldControl` to be used inside an `atom-form-field`.
 */
declare class AtomTextFieldComponent extends AtomFormFieldControl {
    private static _nextUid;
    private readonly uid;
    readonly controlId: string;
    readonly size: _angular_core.InputSignal<_atomchat_io_ui_design_system.AtomFormFieldSize>;
    /**
     * Counter mode:
     * - 'char': count characters (default)
     * - 'word': count words
     */
    readonly counterMode: _angular_core.InputSignal<"char" | "word">;
    protected readonly _focused: _angular_core.WritableSignal<boolean>;
    protected readonly _inputDisabled: _angular_core.WritableSignal<boolean>;
    protected readonly _cvaDisabled: _angular_core.WritableSignal<boolean>;
    protected readonly _hasValue: _angular_core.WritableSignal<boolean>;
    protected readonly _hasError: _angular_core.WritableSignal<boolean>;
    protected readonly _touched: _angular_core.WritableSignal<boolean>;
    protected readonly _pristine: _angular_core.WritableSignal<boolean>;
    protected readonly _valueLength: _angular_core.WritableSignal<number>;
    protected readonly _maxLength: _angular_core.WritableSignal<number | null>;
    protected readonly _describedByIds: _angular_core.WritableSignal<string[]>;
    readonly disabled: _angular_core.Signal<boolean>;
    readonly hasValue: _angular_core.Signal<boolean>;
    readonly hasError: _angular_core.Signal<boolean>;
    readonly touched: _angular_core.Signal<boolean>;
    readonly pristine: _angular_core.Signal<boolean>;
    readonly valueLength: _angular_core.Signal<number>;
    readonly maxLength: _angular_core.Signal<number | null>;
    readonly focused: _angular_core.Signal<boolean>;
    /** Signal reading the IDs for aria-describedby */
    readonly ariaDescribedBy: _angular_core.Signal<string | null>;
    protected readonly hostClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'atom-text-field': boolean;
    }>;
    onFocus(): void;
    onBlur(): void;
    onInput(value: string): void;
    onValueChange(value: string): void;
    setDisabledFromInput(disabled: boolean): void;
    setDisabledFromCva(disabled: boolean): void;
    setMaxLength(value: number | null): void;
    syncFromControl(invalid: boolean, touched: boolean, pristine: boolean): void;
    setDescribedByIds(ids: string[]): void;
    private computeValueLength;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTextFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomTextFieldComponent, "atom-text-field", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "counterMode": { "alias": "counterMode"; "required": false; "isSignal": true; }; }, {}, never, ["[atomTextFieldLeading]", "input[atomTextFieldInput], textarea[atomTextFieldInput]", "[atomTextFieldTrailing]"], true, never>;
}

type AtomTextFieldSize = AtomFormFieldSize;
type AtomTextFieldValidationKind = 'error' | 'success';
declare const ATOM_TEXT_FIELD_SUPPORTED_INPUT_TYPES: readonly ["text", "url", "tel", "number", "email", "password", "hidden", "search"];
type AtomTextFieldInputType = (typeof ATOM_TEXT_FIELD_SUPPORTED_INPUT_TYPES)[number];

/**
 * Directive applied to the native `<input>` or `<textarea>` inside an
 * `atom-text-field`. Manages CVA, native attributes, and auto-resize.
 */
declare class AtomTextFieldInputDirective implements ControlValueAccessor, AfterViewInit, OnDestroy {
    protected readonly root: AtomTextFieldComponent;
    private readonly _el;
    private readonly _renderer;
    private readonly _injector;
    readonly type: _angular_core.InputSignal<"number" | "search" | "text" | "url" | "tel" | "email" | "password" | "hidden">;
    /**
     * `maxlength` attribute aliased so consumers can write either the native
     * `maxlength="20"` static form or `[maxlength]="signal()"` reactively.
     */
    readonly maxLength: _angular_core.InputSignalWithTransform<number | null, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    /**
     * Resolved once in `ngAfterViewInit` to avoid the NG0200 cycle between
     * `NgControl` and this directive's `NG_VALUE_ACCESSOR` provider.
     */
    private _ngControl;
    private _controlSubCleanup;
    readonly isTextArea: boolean;
    readonly element: any;
    /** Drives error shell on the host via `:has([aria-invalid])`. */
    protected readonly ariaInvalid: _angular_core.Signal<"true" | null>;
    private _minHeightPx;
    private _maxHeightPx;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onChange: (_: unknown) => void;
    onTouched: () => void;
    writeValue(value: unknown): void;
    registerOnChange(fn: (value: unknown) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    protected onFocus(): void;
    protected onBlur(): void;
    protected onInputChange(event: Event): void;
    private syncRoot;
    private computeAutoResizeBounds;
    /**
     * Dev-mode only: warn when an unsupported `type` is used.
     */
    private validateType;
    recalculateAutoResize(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTextFieldInputDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomTextFieldInputDirective, "input[atomTextFieldInput], textarea[atomTextFieldInput]", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Marker directive for the leading-enhancer slot of a form-field component
 * (`atom-text-field`, `atom-select-input`). Shared across the field family so
 * the projection contract stays consistent (paired with `[atomFormFieldLabel]`,
 * `[atomFormFieldSupport]`, etc.).
 *
 * `atom-text-field` matches it purely as an `ng-content` selector, but
 * `atom-select-input` also queries `contentChild(AtomTextFieldLeadingDirective)`
 * to detect a projected enhancer (`hasLeading()` → `data-has-leading`), which
 * is why the slot is backed by a real directive rather than a bare attribute.
 *
 * Intentionally empty — reserved for future inputs (e.g. polarity hints).
 */
declare class AtomTextFieldLeadingDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTextFieldLeadingDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomTextFieldLeadingDirective, "[atomTextFieldLeading]", never, {}, {}, never, never, true, never>;
}

/**
 * Marker directive for the trailing-enhancer slot of a form-field component
 * (`atom-text-field`). Shared across the field family so the projection
 * contract stays consistent.
 *
 * Intentionally empty — reserved for future inputs.
 */
declare class AtomTextFieldTrailingDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTextFieldTrailingDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomTextFieldTrailingDirective, "[atomTextFieldTrailing]", never, {}, {}, never, never, true, never>;
}

/** Visual states shared by text-field and text-area (same `atom-text-field` host). */
type AtomTextFieldVisualState = 'enabled' | 'hovered' | 'pressed' | 'focused' | 'filled' | 'disabled' | 'error-enabled' | 'error-filled' | 'error-focused';
declare const ATOM_TEXT_FIELD_VISUAL_STATES: AtomTextFieldVisualState[];
/**
 * Storybook matrix only — `--preview` locks pseudo-class styling so a single
 * BEM modifier (e.g. `--focused`) can force the shell appearance.
 */
declare function atomTextFieldPreviewClasses(state: AtomTextFieldVisualState): Record<string, boolean>;

declare class AtomFormFieldValidationDirective {
    protected readonly root: AtomFormFieldRootDirective;
    readonly id: string;
    readonly kind: _angular_core.InputSignal<"error" | "success">;
    protected readonly hidden: _angular_core.Signal<boolean>;
    protected readonly ariaLive: _angular_core.Signal<"assertive" | "polite">;
    protected readonly hostClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'atom-form-field__validation': boolean;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFormFieldValidationDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomFormFieldValidationDirective, "[atomFormFieldValidation]", never, { "kind": { "alias": "atomFormFieldValidation"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtomFormFieldSupportDirective {
    protected readonly root: AtomFormFieldRootDirective;
    readonly id: string;
    protected readonly hidden: _angular_core.Signal<boolean>;
    protected readonly hostClasses: _angular_core.Signal<{
        'atom-form-field__support': boolean;
        'atom-form-field__support--disabled': boolean;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFormFieldSupportDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomFormFieldSupportDirective, "[atomFormFieldSupport]", never, {}, {}, never, never, true, never>;
}

/**
 * Central state coordinator for `atom-form-field`.
 * Discovers the projected control and manages common state like IDs and visibility.
 */
declare class AtomFormFieldRootDirective {
    /** Projected control that implements the `AtomFormFieldControl` contract. */
    readonly control: _angular_core.Signal<AtomFormFieldControl | undefined>;
    private readonly uid;
    readonly labelId: string;
    readonly counterId: string;
    private readonly _supports;
    /** Projected validation directives in DOM order (FIFO). */
    readonly validations: _angular_core.Signal<readonly AtomFormFieldValidationDirective[]>;
    /**
     * Visibility precedence algorithm:
     * 1. !control.touched() && !control.pristine() → returns 'support' if support is projected, otherwise 'none'
     * 2. control.touched() && control.hasError() → 'error'
     * 3. control.touched() && !control.hasError() and kind='success' validation exists → 'success'
     * 4. Fallback → 'support' if support is projected, otherwise 'none'
     */
    readonly visibleMessage: _angular_core.Signal<"none" | "error" | "success" | "support">;
    /** The first validation directive whose kind matches the currently visible message. */
    readonly activeValidation: _angular_core.Signal<AtomFormFieldValidationDirective | null>;
    readonly showCounter: _angular_core.Signal<boolean>;
    /** The first support directive. */
    readonly activeSupport: _angular_core.Signal<AtomFormFieldSupportDirective>;
    /** List of IDs for aria-describedby. */
    readonly ariaDescribedBy: _angular_core.Signal<string | null>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFormFieldRootDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomFormFieldRootDirective, never, never, {}, {}, ["control", "_supports", "validations"], never, true, never>;
}

declare class AtomFormFieldComponent {
    protected readonly root: AtomFormFieldRootDirective;
    /** Structure typography only escalates at xl (Figma compact family is shared). */
    protected readonly isSizeXl: _angular_core.Signal<boolean>;
    /** Optional descriptive suffix for the counter. */
    readonly counterSuffix: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFormFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomFormFieldComponent, "atom-form-field", never, { "counterSuffix": { "alias": "counterSuffix"; "required": false; "isSignal": true; }; }, {}, never, ["label[atomFormFieldLabel]", "*", "[atomFormFieldSupport]", "[atomFormFieldValidation]"], true, [{ directive: typeof AtomFormFieldRootDirective; inputs: {}; outputs: {}; }]>;
}

declare class AtomFormFieldLabelDirective {
    protected readonly root: AtomFormFieldRootDirective;
    protected readonly hostClasses: _angular_core.Signal<{
        'atom-form-field__label': boolean;
        'atom-form-field__label--disabled': boolean;
        'atom-form-field__label--error': boolean | undefined;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFormFieldLabelDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomFormFieldLabelDirective, "label[atomFormFieldLabel]", never, {}, {}, never, never, true, never>;
}

/** Single import entry for `atom-form-field` and its slot directives. */
declare const ATOM_FORM_FIELD_IMPORTS: readonly [typeof AtomFormFieldComponent, typeof AtomFormFieldLabelDirective, typeof AtomFormFieldSupportDirective, typeof AtomFormFieldValidationDirective];

/**
 * Internal counter rendered automatically by `atom-form-field` when the
 * projected control carries a `maxLength`.
 */
declare class AtomFormFieldCounterComponent {
    protected readonly root: AtomFormFieldRootDirective;
    /** Optional descriptive suffix appended after `current/max` (e.g. `words`). */
    readonly suffix: _angular_core.InputSignal<string | undefined>;
    protected readonly max: _angular_core.Signal<number>;
    protected readonly current: _angular_core.Signal<number>;
    protected readonly hostClasses: _angular_core.Signal<{
        'atom-form-field__counter': boolean;
        'atom-form-field__counter--disabled': boolean;
    }>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFormFieldCounterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomFormFieldCounterComponent, "atom-form-field-counter", never, { "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Contract implemented by any component that wants to expand when the
 * global `Cmd+K` / `Ctrl+K` shortcut fires. The manager calls this method
 * on the top-priority registered instance.
 */
interface AtomSearchShortcutTarget {
    triggerExpandFromShortcut(): void;
}
/** Options accepted by `AtomSearchShortcutManager.register`. */
interface AtomSearchShortcutRegisterOptions {
    /**
     * Higher priority wins when several instances are registered. When omitted,
     * the most-recently-registered instance wins (LIFO).
     */
    priority?: number;
}
/**
 * Global manager for the `⌘` / `Ctrl` + letter shortcut that expands
 * `atom-search-input` instances configured with `expandable=true`. The
 * letter is configured globally via `ATOM_SEARCH_INPUT_SHORTCUT_KEY`
 * (default `'K'`), and the same token also drives the trailing-slot hint
 * inside the component so hint and listener stay in lockstep.
 *
 * Architecture (HU-020):
 *   - Singleton (`providedIn: 'root'`).
 *   - Single `document.keydown` listener attached on the first `register()`
 *     call and detached on the last `unregister()` call, so apps that never
 *     mount an expandable search input pay no runtime cost.
 *   - Shortcut detection uses `hasModifierKey` from `@angular/cdk/keycodes`
 *     for the modifier check, combined with the native
 *     `event.code === 'Key' + <letter>` (`KeyboardEvent.code` reports the
 *     *physical* key location, so this stays layout-agnostic across
 *     QWERTY / AZERTY / Dvorak — unlike the deprecated `event.keyCode`).
 *     The letter is resolved once from `ATOM_SEARCH_INPUT_SHORTCUT_KEY`.
 *   - Priority resolution prefers higher numeric `priority`; ties fall back
 *     to LIFO (most-recently-registered wins) so a search input mounted in
 *     a modal/sheet beats one that was already on the page.
 *   - **Not** built on `SelectionModel` from `@angular/cdk/collections`: that
 *     class models "selection state of options" and lacks the ordered-registry
 *     semantics this manager needs. HU-020 explicitly allows an alternative
 *     when SelectionModel does not fit; a small internal registry is clearer
 *     and easier to test.
 */
declare class AtomSearchShortcutManager {
    private readonly osDetector;
    private readonly shortcutKey;
    /** Pre-computed `KeyboardEvent.code` to match against, derived once from
     *  the injected token (e.g. `'K'` → `'KeyK'`). Letters are normalized to
     *  uppercase so providers can override with either casing. */
    private readonly expectedKeyCode;
    private readonly registry;
    private nextOrder;
    private listenerAttached;
    private readonly listener;
    /**
     * Register a search-input target. Idempotent: re-registering the same
     * target updates its `priority` instead of creating a duplicate entry.
     */
    register(target: AtomSearchShortcutTarget, options?: AtomSearchShortcutRegisterOptions): void;
    /**
     * Remove a previously-registered target. No-op when the target is not in
     * the registry. Detaches the global listener when the last target leaves.
     */
    unregister(target: AtomSearchShortcutTarget): void;
    /** @internal Exposed for testing — the count of currently-registered targets. */
    get size(): number;
    /** @internal Exposed for testing — whether the document listener is currently attached. */
    get isListenerAttached(): boolean;
    private onKeydown;
    /**
     * Returns the entry with the highest `priority`. Entries with explicit
     * `priority` outrank entries without one; ties resolve LIFO (highest
     * `order`).
     */
    private topPriority;
    private attachListenerIfNeeded;
    private detachListenerIfEmpty;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSearchShortcutManager, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AtomSearchShortcutManager>;
}

/**
 * `<atom-search-input>` — search input with two modes (HU-020):
 *
 *   - `expandable = false` (default) — **Search Field mode**: always renders
 *     the full `atom-text-field` (leading search icon, trailing clear button
 *     when filled, otherwise empty). The shortcut hint is **not** rendered
 *     because the global keyboard listener only registers in Expandable mode
 *     — showing `⌘K`/`Ctrl+K` here would advertise an inert shortcut.
 *   - `expandable = true` — **Expandable mode**: starts collapsed as an
 *     `atom-icon-button` and expands to the full Search Field on click, Tab
 *     focus, `expanded = true`, or the global keyboard shortcut. Auto-
 *     collapses on blur / mouseleave when the input is empty (filled inputs
 *     never auto-collapse).
 *
 * Expandable instances register with `AtomSearchShortcutManager` on init and
 * unregister on destroy. Both the trailing-slot hint and the global listener
 * resolve their letter from `ATOM_SEARCH_INPUT_SHORTCUT_KEY` (default `'K'`,
 * overridable at application root), and the OS-aware modifier glyph comes
 * from `OSDetectorService` so Mac shows `⌘K` and Windows/Linux show `Ctrl+K`.
 */
declare class AtomSearchInputComponent implements AtomSearchShortcutTarget {
    private readonly toolbarSize;
    readonly size: _angular_core.InputSignal<_atomchat_io_ui_design_system.AtomFormFieldSize | undefined>;
    readonly effectiveSize: _angular_core.Signal<_atomchat_io_ui_design_system.AtomFormFieldSize>;
    readonly value: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    /** Debounce window, in **milliseconds**, before `valueChange` fires after
     *  the user stops typing. Set to `0` to emit synchronously on every input. */
    readonly debounce: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly clearAriaLabel: _angular_core.InputSignal<string>;
    readonly collapsedAriaLabel: _angular_core.InputSignal<string>;
    /** Toggles between Search Field mode (`false`) and Expandable mode (`true`). */
    readonly expandable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Controls the expanded state in Expandable mode. Ignored when
     * `expandable = false`. Two-way friendly: pair with `(expandedChange)`.
     *
     * `[expanded]="false"` is also ignored while the field has a value (HU-020
     * business rule): a filled expandable field stays open so the value never
     * hides behind the icon trigger. Clear the value first to programmatically
     * collapse.
     */
    readonly expanded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Emits the current value after `debounce` ms of no further input. */
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    /**
     * Emits the current value immediately on Enter or via consumer-side flush.
     * Named `search` per HU-020 spec. The DOM `search` event only fires on
     * `<input type="search">`, not on the custom `<atom-search-input>` host,
     * so there is no collision with native event binding.
     */
    readonly search: _angular_core.OutputEmitterRef<string>;
    /** Emits when the expanded state changes (Expandable mode only). */
    readonly expandedChange: _angular_core.OutputEmitterRef<boolean>;
    protected readonly searchIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    protected readonly clearIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    protected readonly currentValue: _angular_core.WritableSignal<string>;
    protected readonly hasValue: _angular_core.Signal<boolean>;
    /** Internal expanded state. Mirrors `expanded` input when expandable=true;
     *  always true when expandable=false. Updated synchronously on user actions. */
    protected readonly isExpanded: _angular_core.WritableSignal<boolean>;
    /**
     * Visual state, lags `isExpanded` only on the collapse transition.
     *
     * The host's `inline-size` animates over 450 ms when `--collapsed` toggles.
     * On *expand*, the text-field should render immediately so the user sees
     * its content grow with the host. On *collapse*, swapping to the icon
     * trigger immediately would leave the text-field gone before the host
     * finishes shrinking — the right edge would just snap inward over empty
     * space. Keeping the text-field rendered for the duration of the
     * transition (then swapping) lets the content visibly compress from the
     * trailing edge, mirroring the expand animation in reverse.
     *
     * Skipped under `prefers-reduced-motion: reduce` so reduced-motion users
     * get an instant swap without a 450 ms wait that would just feel laggy.
     */
    protected readonly visualExpanded: _angular_core.WritableSignal<boolean>;
    /** True when the rendered tree should show the full field (Search Field
     *  mode, or Expandable mode while expanded — including the collapse
     *  transition window when the text-field is intentionally kept on screen). */
    protected readonly showField: _angular_core.Signal<boolean>;
    /** Host class map. Includes the BEM size modifier so the SCSS can resolve
     *  the collapsed pixel width per size for a smooth inline-size transition. */
    protected readonly hostClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'atom-search-input': boolean;
        'atom-search-input--disabled': boolean;
        'atom-search-input--collapsed': boolean;
    }>;
    /** Tracks whether the native input currently holds focus. Used to keep
     *  mouseleave from collapsing the field while a keyboard user is typing. */
    protected readonly inputFocused: _angular_core.WritableSignal<boolean>;
    private readonly inputRef;
    private readonly destroyRef;
    private readonly injector;
    private readonly osDetector;
    private readonly shortcutManager;
    private readonly shortcutKey;
    private debounceTimer;
    /** Trailing shortcut hint shown when the input is empty. OS-aware via
     *  `OSDetectorService` so Mac renders `⌘K` and Windows/Linux render `Ctrl+K`.
     *  The letter comes from `ATOM_SEARCH_INPUT_SHORTCUT_KEY`, the same token
     *  the global listener in `AtomSearchShortcutManager` consumes — overriding
     *  it at app root updates both hint and listener in lockstep. */
    protected readonly shortcutHint: _angular_core.Signal<string>;
    constructor();
    triggerExpandFromShortcut(): void;
    protected onInput(event: Event): void;
    protected onEnter(): void;
    onInputFocus(): void;
    protected onInputBlur(): void;
    /**
     * Empties the input, cancels any pending debounce, and emits an empty
     * `valueChange('')`. After the DOM settles, returns focus to the input so
     * the user can keep typing. Safe to call from outside (e.g. host
     * directives wiring a programmatic "clear" flow).
     */
    clear(): void;
    protected onCollapsedClick(): void;
    protected onCollapsedFocus(): void;
    protected onHostMouseLeave(): void;
    private expand;
    private collapseIfEligible;
    private setExpanded;
    private scheduleValueChange;
    private cancelDebounce;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSearchInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSearchInputComponent, "atom-search-input", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "debounce": { "alias": "debounce"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "collapsedAriaLabel": { "alias": "collapsedAriaLabel"; "required": false; "isSignal": true; }; "expandable": { "alias": "expandable"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; "search": "search"; "expandedChange": "expandedChange"; }, never, never, true, never>;
}

/**
 * Default placeholder shown inside the `atom-search-input`'s native input
 * when no `[placeholder]` is provided per-instance.
 *
 * Provided in root with a sensible default. Override at any injector level:
 *
 * ```ts
 * providers: [
 *   { provide: ATOM_SEARCH_INPUT_PLACEHOLDER, useValue: 'Buscar...' }
 * ]
 * ```
 */
declare const ATOM_SEARCH_INPUT_PLACEHOLDER: InjectionToken<string>;
/**
 * Default aria-label for the native search input element. Used when the
 * consumer does not provide `[ariaLabel]` per-instance.
 */
declare const ATOM_SEARCH_INPUT_ARIA_LABEL: InjectionToken<string>;
/**
 * Default aria-label for the trailing clear button. Used when the consumer
 * does not provide `[clearAriaLabel]` per-instance.
 */
declare const ATOM_SEARCH_INPUT_CLEAR_ARIA_LABEL: InjectionToken<string>;
/**
 * Default aria-label for the collapsed icon-button trigger in Expandable
 * mode. Used when the consumer does not provide `[collapsedAriaLabel]`
 * per-instance.
 */
declare const ATOM_SEARCH_INPUT_COLLAPSED_ARIA_LABEL: InjectionToken<string>;
/**
 * Global keyboard shortcut letter that expands any `atom-search-input`
 * configured with `expandable=true`. The actual keystroke is the OS-native
 * primary modifier (`⌘` on Mac, `Ctrl` elsewhere) + this letter.
 *
 * Single source of truth for both the visual hint shown in the trailing
 * slot **and** the global keyboard listener inside
 * `AtomSearchShortcutManager`, so a consumer that re-provides this token
 * sees the change applied consistently across the entire platform.
 *
 * Must be a single A–Z letter (case-insensitive); the manager maps it to
 * the corresponding `KeyboardEvent.code` (`'Key' + letter.toUpperCase()`)
 * so the listener stays keyboard-layout-agnostic.
 *
 * Override at application root:
 *
 * ```ts
 * providers: [{ provide: ATOM_SEARCH_INPUT_SHORTCUT_KEY, useValue: 'F' }]
 * ```
 */
declare const ATOM_SEARCH_INPUT_SHORTCUT_KEY: InjectionToken<string>;

type SearchFn<T> = (query: string, item: T) => boolean;
/**
 * Adaptive search for `atom-select-panel`. Applied as a host directive on the
 * panel element. Filters the panel's items per the active render mode:
 *
 * - **array**: filters `items[]` and calls `panel.setFilteredItems(subset)`
 *   so the template renders only the matching subset.
 * - **projection**: marks non-matching `atom-list-item [atomSelectValue]`
 *   hosts with the native `hidden` attribute (items stay mounted so their
 *   selection state persists across search cycles).
 * - **virtual**: no-op + one-time dev warning. The consumer is responsible
 *   for filtering `virtualScrollItems` externally.
 *
 * The internal filter is debounced 175 ms. The `searchValueChange` output
 * fires per keystroke (no debounce) so consumers control their own timing.
 */
declare class AtomSelectSearchDirective<T = unknown> {
    private readonly _panel;
    private readonly _destroyRef;
    /**
     * When `false`, the directive does not push `setSearchEmpty()` on the panel.
     * Use when a parent host (e.g. `atom-select-input`) owns empty-state via its
     * own `[isEmpty]` binding — re-projection hides `[atomSelectValue]` from the
     * panel's `optionDirectives`, so the directive would falsely report zero items.
     */
    readonly managePanelEmptyState: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Custom predicate. When absent, the default substring search is used
     * (case-insensitive, matches `labelKey` + every property in `propsForSearch`).
     */
    readonly searchFn: _angular_core.InputSignal<SearchFn<T> | undefined>;
    /** Override the panel's `labelKey` for the default substring search. */
    readonly labelKey: _angular_core.InputSignal<string | undefined>;
    /**
     * Additional properties included in the default substring search. Accepts
     * either a single property name or an array — coerced via the CDK's
     * `coerceStringArray` so `propsForSearch="email"` and
     * `[propsForSearch]="['name', 'email']"` both work.
     */
    readonly propsForSearch: _angular_core.InputSignalWithTransform<readonly string[], string | string[]>;
    /**
     * Raw input value. NOT debounced — consumers can interpolate this into the
     * empty-state copy ("No results for X") without waiting for the filter.
     */
    private readonly _rawValue;
    readonly searchValue: Signal<string>;
    /** Debounced filter input — drives the actual filter computation. */
    private readonly _debouncedValue;
    /**
     * Emits the raw current query on every change. NOT debounced — consumers
     * control their own timing.
     */
    readonly searchValueChange: _angular_core.OutputEmitterRef<string>;
    /**
     * `true` when the debounced filter yields zero visible items. Read-only
     * `computed()` — consumers cannot force it externally.
     */
    readonly isEmpty: Signal<boolean>;
    /** Projected `<atom-search-input>` — same content slot the panel reads. */
    private readonly _searchInput;
    private _debounceTimer;
    private _warnedVirtual;
    constructor();
    /**
     * Empties the input and restores the full list. `searchValue` returns to ''.
     * Does NOT touch the panel's selection state — `panel.clear()` is separate.
     * Used by Spec A's "Clear all" flow alongside `panel.clear()`.
     */
    clearSearch(): void;
    private _scheduleDebounce;
    /** Virtual-mode no-op + one-time dev warning. */
    private _warnVirtualOnce;
    /** Array-mode end-to-end: restore on empty query, otherwise filter+push. */
    private _applyArrayFilter;
    /** Projection-mode end-to-end: restore on empty query, otherwise compute+push. */
    private _applyProjectionFilter;
    private _filterArray;
    private _computeHiddenProjection;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectSearchDirective<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSelectSearchDirective<any>, "atom-select-panel[atomSelectSearch]", never, { "managePanelEmptyState": { "alias": "managePanelEmptyState"; "required": false; "isSignal": true; }; "searchFn": { "alias": "searchFn"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "propsForSearch": { "alias": "propsForSearch"; "required": false; "isSignal": true; }; }, { "searchValueChange": "searchValueChange"; }, ["_searchInput"], never, true, never>;
}

/**
 * Directive applied to each option inside an `atom-select-input`.
 * Associates a logical value with the list-item's visual label.
 */
declare class AtomSelectValueDirective<T = unknown> {
    readonly host: AtomListItemComponent;
    readonly elementRef: ElementRef<any>;
    /** Logical value associated with this option. */
    readonly value: _angular_core.InputSignal<T>;
    /** Unique ID for aria-activedescendant. */
    readonly optionId: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectValueDirective<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSelectValueDirective<any>, "atom-list-item[atomSelectValue]", never, { "value": { "alias": "atomSelectValue"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AtomSelectLoadingCaptionDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectLoadingCaptionDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSelectLoadingCaptionDirective, "[atomSelectLoadingCaption]", never, {}, {}, never, never, true, never>;
}

declare const ATOM_SELECT_INPUT_STATES: readonly ["enabled", "hovered", "focused", "opened", "pressed", "filled", "disabled", "error-enabled", "error-focused", "error-filled"];
type AtomSelectInputState = (typeof ATOM_SELECT_INPUT_STATES)[number];
type AtomSelectCompareWith<T = unknown> = (a: T, b: T) => boolean;
/** Storybook matrix only — `--preview` + one `--{state}` modifier per row. */
declare function atomSelectInputPreviewClasses(state: AtomSelectInputState): Record<string, boolean>;

/** See `./README.md` for the full component contract and usage patterns. */
declare class AtomSelectInputComponent<T = unknown> extends AtomFormFieldControl implements ControlValueAccessor {
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    readonly searchable: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    readonly size: _angular_core.InputSignal<AtomFormFieldSize>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly disabledInput: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    readonly error: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loadingCaption: _angular_core.InputSignal<string | undefined>;
    readonly chipRemoveAriaLabel: _angular_core.InputSignal<string>;
    readonly compareWith: _angular_core.InputSignal<AtomSelectCompareWith<T>>;
    readonly clearLabel: _angular_core.InputSignal<string>;
    /** Hides the clear footer — use when selection is mandatory. */
    readonly hideClearFooter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /** `T | null` (single) or `T[]` (multi). */
    readonly value: _angular_core.ModelSignal<T | T[] | null>;
    private readonly _directiveValuesReady;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    private static _nextId;
    readonly controlId: string;
    protected readonly _touched: _angular_core.WritableSignal<boolean>;
    protected readonly _pristine: _angular_core.WritableSignal<boolean>;
    protected readonly _hasError: _angular_core.WritableSignal<boolean>;
    readonly valueLength: _angular_core.WritableSignal<number>;
    readonly maxLength: _angular_core.WritableSignal<number | null>;
    protected readonly _describedByIds: _angular_core.WritableSignal<string[]>;
    readonly touched: _angular_core.Signal<boolean>;
    readonly pristine: _angular_core.Signal<boolean>;
    readonly hasError: _angular_core.Signal<boolean>;
    /** Signal reading the IDs for aria-describedby */
    readonly ariaDescribedBy: _angular_core.Signal<string | null>;
    setDescribedByIds(ids: string[]): void;
    private readonly trigger;
    protected readonly isOpen: _angular_core.Signal<boolean>;
    private readonly cvaDisabled;
    readonly disabled: _angular_core.Signal<boolean>;
    protected readonly leading: _angular_core.Signal<AtomTextFieldLeadingDirective | undefined>;
    readonly hasLeading: _angular_core.Signal<boolean>;
    protected readonly loadingCaptionSlot: _angular_core.Signal<AtomSelectLoadingCaptionDirective | undefined>;
    readonly hasLoadingCaptionSlot: _angular_core.Signal<boolean>;
    readonly resolvedPlaceholder: _angular_core.Signal<string>;
    protected readonly focusWithin: _angular_core.WritableSignal<boolean>;
    /** Overlay pane classes — panel is outside the host (CDK), so modifiers live here. */
    protected readonly dropdownPanelClasses: _angular_core.Signal<string[]>;
    /** Body scroll cap — lifted while loading so the 256px slot can center the spinner. */
    protected readonly panelMaxHeight: _angular_core.Signal<"none" | "var(--atom-select-panel-max-height, 300px)">;
    /** BEM modifiers — `opened` can coexist with `error-*` (chevron + error shell). */
    protected readonly hostClasses: _angular_core.Signal<Record<string, boolean>>;
    protected readonly chevronIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    protected readonly errorIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    readonly supportInError: _angular_core.Signal<boolean>;
    protected readonly optionDirectives: _angular_core.Signal<readonly AtomSelectValueDirective<any>[]>;
    readonly options: _angular_core.Signal<AtomListItemComponent[]>;
    readonly selectedItem: _angular_core.Signal<AtomListItemComponent | null>;
    readonly selectedOptions: _angular_core.Signal<AtomListItemComponent[]>;
    protected readonly searchDirective: _angular_core.Signal<AtomSelectSearchDirective<any> | undefined>;
    private readonly panel;
    protected readonly visibleOptionDirectives: _angular_core.Signal<AtomSelectValueDirective<any>[]>;
    readonly visibleOptions: _angular_core.Signal<AtomListItemComponent[]>;
    private readonly activeOptionIndex;
    protected readonly activeDescendantId: _angular_core.Signal<string | null>;
    readonly isEmpty: _angular_core.Signal<boolean>;
    readonly hasSelection: _angular_core.Signal<boolean>;
    readonly hasValue: _angular_core.Signal<boolean>;
    readonly resolvedLoadingCaption: _angular_core.Signal<string>;
    protected readonly chipStripRef: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly overflowCount: _angular_core.WritableSignal<number>;
    private chipResizeObserver;
    private overflowRafHandle;
    private readonly destroyRef;
    private readonly renderer;
    private readonly _injector;
    /** Resolved after first render to avoid NG0200 with NG_VALUE_ACCESSOR. */
    private _ngControl;
    constructor();
    private closeWhenDisabled;
    private syncWithNgControl;
    syncFromControl(invalid: boolean, touched: boolean, pristine: boolean): void;
    private syncOptionSelectionMode;
    private syncOptionSelectedState;
    private wireOptionClickSubscriptions;
    private observeChipStripResize;
    private recalcOverflowOnSelectionChange;
    private toggleOptionVisibilityOnFilter;
    private resetActiveOptionOnOpenAndFilter;
    private syncActiveOptionHighlight;
    private onOpenNavKeydown;
    private moveActiveOption;
    private setActiveOptionFrom;
    private pickActiveOption;
    protected onOptionPick(directive: AtomSelectValueDirective<T>): void;
    protected onChipRemove(host: AtomListItemComponent): void;
    private onChangeFn;
    private onTouchedFn;
    writeValue(value: T | T[] | null): void;
    registerOnChange(fn: (value: T | T[] | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    protected commitValue(next: T | T[] | null): void;
    protected commitTouched(): void;
    protected onDropdownOpened(): void;
    protected onDropdownClosed(): void;
    protected onTriggerKeydown(event: KeyboardEvent): void;
    protected onFieldFocusIn(): void;
    protected onFieldFocusOut(event: FocusEvent): void;
    protected onClearAction(): void;
    private scheduleOverflowRecalc;
    private recalcOverflow;
    private clearOverflowFlags;
    private allChipsFit;
    private reservedOverflowWidth;
    private hideOverflowingChips;
    private disposeChipObserver;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectInputComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSelectInputComponent<any>, "atom-select-input", never, { "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "searchable": { "alias": "searchable"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingCaption": { "alias": "loadingCaption"; "required": false; "isSignal": true; }; "chipRemoveAriaLabel": { "alias": "chipRemoveAriaLabel"; "required": false; "isSignal": true; }; "compareWith": { "alias": "compareWith"; "required": false; "isSignal": true; }; "clearLabel": { "alias": "clearLabel"; "required": false; "isSignal": true; }; "hideClearFooter": { "alias": "hideClearFooter"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "opened": "opened"; "closed": "closed"; }, ["leading", "loadingCaptionSlot", "optionDirectives"], ["[atomTextFieldLeading]", "[atomSelectLoadingCaption]", "[atomSelectValue]"], true, never>;
}

/**
 * Operating-system detection on top of Angular CDK's `Platform`.
 *
 * Inherits the full browser/engine detection from `Platform` (`isBrowser`,
 * `EDGE`, `TRIDENT`, `BLINK`, `WEBKIT`, `FIREFOX`, `SAFARI`, `IOS`, `ANDROID`)
 * and adds host-OS detection used by shortcut handling and key-glyph
 * rendering across the design system.
 *
 * SSR-safe: `navigator` is read through a `typeof` guard, so the service
 * silently degrades to "no OS detected" on the server instead of throwing.
 */
declare class OSDetectorService extends Platform {
    /**
     * Raw `navigator.userAgent` snapshot captured at construction. Reading
     * `navigator` directly through a field initializer (rather than gating on
     * the inherited `this.isBrowser` from the constructor body) avoids subtle
     * class-field initialization ordering in TypeScript when `target: "es2022"`
     * subclasses a base whose own properties are field-initialized — under
     * certain bundlers / hot-reload paths the inherited flag can read as
     * `undefined` from the subclass body even though it is correct elsewhere.
     * The `typeof navigator !== 'undefined'` guard keeps this SSR-safe.
     */
    private readonly _userAgent;
    /** Apple-family operating systems (macOS, iOS / iPadOS). */
    readonly isMac: boolean;
    /** Microsoft Windows. */
    readonly isWindows: boolean;
    /**
     * Linux desktop (also matches X11). Mutually exclusive with `isMac` /
     * `isWindows` — Android is reported via the inherited `ANDROID` flag.
     */
    readonly isLinux: boolean;
    /**
     * Primary keyboard modifier for "command-style" shortcuts, encoded as the
     * `KeyboardEvent` property name (`'metaKey'` on Mac for the ⌘ key, `'ctrlKey'`
     * everywhere else). Pair with `hasModifierKey(event, primaryModifier)` from
     * `@angular/cdk/keycodes`, whose `ModifierKey` type is exactly these
     * property names. The HU-020 spec describes the values as `'Meta'` /
     * `'Control'`; that names the *physical key*, but the CDK utility consumes
     * the property name, so we expose the property name to keep callsites
     * direct.
     */
    get primaryModifier(): 'metaKey' | 'ctrlKey';
    /**
     * Glyph representation of the primary modifier for visual hints. Returns
     * `'⌘'` on Mac and `'Ctrl+'` elsewhere; concatenate with the shortcut
     * letter to render a complete hint (e.g. `${primaryModifierGlyph}K`).
     */
    get primaryModifierGlyph(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OSDetectorService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<OSDetectorService>;
}

/**
 * ARIA role exposed by a dropdown panel. Drives the trigger's `aria-haspopup`
 * attribute. `'menu'` for action menus (`AtomDropdownMenuComponent`),
 * `'listbox'` for selection panels (`AtomSelectPanelComponent`), `'dialog'` for
 * composite popups with internal navigation (`AtomFilterPanelComponent`).
 */
type AtomDropdownPanelRole = 'menu' | 'listbox' | 'dialog';
/**
 * Contract shared by every panel that `AtomDropdownTriggerDirective` can anchor
 * via CDK Overlay. Implemented by `AtomDropdownMenuComponent` (`'menu'`),
 * `AtomSelectPanelComponent` (`'listbox'`) and `AtomFilterPanelComponent`
 * (`'dialog'`).
 */
interface AtomDropdownPanel {
    /** Template projected into the overlay. Read at attach time. */
    readonly templateRef: Signal<TemplateRef<unknown>>;
    /** ARIA role on the inner wrapper. Drives the trigger's `aria-haspopup`. */
    readonly panelRole: AtomDropdownPanelRole;
    /** Panel-driven dismissal (Escape, Tab, item activation). */
    readonly closed: OutputRef<void>;
    /**
     * Called by the trigger after attach so the panel can claim focus on the
     * right element (first menuitem, search input, etc.) per WAI-ARIA APG.
     */
    onAttached?(): void;
}

/**
 * Floating contextual menu of actions. Composes `<atom-list-item>` rows via
 * `<ng-content>` and is rendered through a `TemplatePortal` by
 * `AtomDropdownTriggerDirective` — the entire view lives inside `<ng-template>`,
 * so ARIA roles and classes apply to the wrapper `<div>` inside the template,
 * not to the component selector (the host stays detached after attach).
 *
 * Every descendant `<atom-list-item>` receives `role="menuitem"` declaratively
 * via the `ATOM_LIST_ITEM_ROLE` token (the list-item host binding picks it up
 * reactively — no imperative setAttribute needed). Keyboard navigation is
 * delegated to `FocusKeyManager` (vertical, wrap-around). `Escape` / `Tab`
 * emit `closed` so the trigger detaches the overlay and restores focus.
 */
declare class AtomDropdownMenuComponent implements AtomDropdownPanel {
    /**
     * When defined, activates the _Scrollable_ variant: applies `max-height`
     * and `overflow-y: auto` to the items container.
     */
    readonly maxHeight: _angular_core.InputSignal<string | undefined>;
    /** Panel dismissal request. Emitted on `Escape` and `Tab`. */
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly panelRole: "menu";
    readonly templateRef: _angular_core.Signal<TemplateRef<unknown>>;
    protected readonly projectedItems: _angular_core.Signal<readonly AtomListItemComponent[]>;
    protected readonly projectedItemElements: _angular_core.Signal<readonly ElementRef<any>[]>;
    private focusKeyManager?;
    private readonly destroyRef;
    private readonly renderer;
    constructor();
    /** Focuses the first enabled menuitem per WAI-ARIA APG. */
    onAttached(): void;
    protected onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDropdownMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomDropdownMenuComponent, "atom-dropdown-menu", never, { "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, ["projectedItems", "projectedItemElements"], ["[atomDropdownTitle]", "*"], true, never>;
}

/**
 * Marker for the optional title slot of `<atom-dropdown-menu>` (HU-023).
 *
 * Applies `atom-dropdown-menu__title` to the projected element so the consumer
 * chooses the underlying tag (`<span>`, `<h3>`, etc.) while typography
 * cascades from the dropdown stylesheet (label size, bold, single-line clamp
 * with ellipsis — mirrors `<atom-select-panel>`'s title). Presence of an
 * element carrying `[atomDropdownTitle]` is what makes the title zone render
 * at all — there is no boolean flag on the parent component.
 *
 * @example
 * <atom-dropdown-menu>
 *   <span atomDropdownTitle>Acciones</span>
 *   <atom-list-item label="Editar" />
 *   <atom-list-item label="Duplicar" />
 * </atom-dropdown-menu>
 */
declare class AtomDropdownTitleDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDropdownTitleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDropdownTitleDirective, "[atomDropdownTitle]", never, {}, {}, never, never, true, never>;
}

/** Horizontal alignment of the dropdown panel relative to the trigger. */
type AtomDropdownHorizontalPosition = 'before' | 'after';
/** Vertical alignment of the dropdown panel relative to the trigger. */
type AtomDropdownVerticalPosition = 'above' | 'below';
/**
 * Anchors any element (button, icon-button, chip, avatar, input) to an
 * `AtomDropdownPanel` via CDK Overlay. Uses `FlexibleConnectedPositionStrategy`
 * with `withPush(true)` and 4 preferred positions so the panel stays inside
 * the viewport. The default backdrop is transparent (outside-click only).
 * Escape, Tab and other panel-driven dismissals come through `panel.closed`;
 * Escape is additionally handled at the overlay level so it works even when
 * focus never entered the panel (e.g. a focus-less empty state).
 * Focus is restored to the trigger host on close. ARIA (`aria-haspopup`,
 * `aria-expanded`, `aria-controls`) is wired automatically.
 */
declare class AtomDropdownTriggerDirective {
    /** The panel this trigger opens. Must implement `AtomDropdownPanel`. */
    readonly atomDropdownTriggerFor: _angular_core.InputSignal<AtomDropdownPanel>;
    /** Horizontal alignment. `'after'` (LTR: left edge); `'before'` (LTR: right edge). */
    readonly atomDropdownHorizontalPosition: _angular_core.InputSignal<AtomDropdownHorizontalPosition>;
    /** Vertical alignment relative to the trigger. */
    readonly atomDropdownVerticalPosition: _angular_core.InputSignal<AtomDropdownVerticalPosition>;
    /**
     * Transparent backdrop for outside-click dismissal. Set `false` for
     * non-modal flows where the page stays interactive while open.
     */
    readonly atomDropdownHasBackdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When `true`, the overlay pane is sized to match the trigger's current
     * width (measured at open time). Off by default — menus size to their own
     * content; selection fields (e.g. `atom-select-input`) opt in so the panel
     * spans the full trigger width.
     */
    readonly atomDropdownMatchTriggerWidth: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Extra class(es) added to the overlay pane alongside the built-in
     * `atom-dropdown-overlay-panel`. Lets a consumer scope panel-level overrides
     * (e.g. CSS custom properties) to its own dropdowns without affecting others.
     */
    readonly atomDropdownPanelClass: _angular_core.InputSignal<string | string[] | undefined>;
    /**
     * When `true`, the panel's view is created once and mounted through a
     * `DomPortal`, so `close()` only detaches the overlay (and backdrop) without
     * destroying the embedded view. The panel instance and any state it holds
     * survive across open/close cycles, and `dispose()` is reserved for
     * `ngOnDestroy`. Off by default — menus and selects rebuild their content on
     * every open. `atom-filter` opts in so per-category selections persist.
     */
    readonly atomDropdownPreserveContent: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dropdownOpened: _angular_core.OutputEmitterRef<void>;
    readonly dropdownClosed: _angular_core.OutputEmitterRef<void>;
    protected readonly overlayId: string;
    private readonly isOpenState;
    readonly isOpen: _angular_core.Signal<boolean>;
    protected readonly ariaHasPopup: _angular_core.Signal<AtomDropdownPanelRole>;
    private overlayRef;
    private overlaySubscriptions;
    private preservedView;
    private preservedPortal;
    private preservedHolder;
    private readonly overlay;
    private readonly positionBuilder;
    private readonly scrollStrategies;
    private readonly hostElementRef;
    private readonly viewContainerRef;
    private readonly destroyRef;
    private readonly document;
    private readonly renderer;
    constructor();
    open(): void;
    private applyPlacementAttr;
    /**
     * Builds (once) the cached `DomPortal` wrapping the panel's embedded view.
     * The view is created in this directive's container so Angular keeps running
     * change detection on it; its root node is moved into a `display:none` holder
     * appended to `<body>` so the `DomPortal` has a stable parent to return to on
     * detach.
     */
    private ensurePreservedPortal;
    close(): void;
    toggle(): void;
    private buildOverlayConfig;
    /**
     * Order: preferred → flip Y → flip X → flip both. CDK picks the first one
     * that fits the viewport; `withPush(true)` then nudges within bounds.
     */
    private buildPositions;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDropdownTriggerDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDropdownTriggerDirective, "[atomDropdownTriggerFor]", ["atomDropdownTrigger"], { "atomDropdownTriggerFor": { "alias": "atomDropdownTriggerFor"; "required": true; "isSignal": true; }; "atomDropdownHorizontalPosition": { "alias": "atomDropdownHorizontalPosition"; "required": false; "isSignal": true; }; "atomDropdownVerticalPosition": { "alias": "atomDropdownVerticalPosition"; "required": false; "isSignal": true; }; "atomDropdownHasBackdrop": { "alias": "atomDropdownHasBackdrop"; "required": false; "isSignal": true; }; "atomDropdownMatchTriggerWidth": { "alias": "atomDropdownMatchTriggerWidth"; "required": false; "isSignal": true; }; "atomDropdownPanelClass": { "alias": "atomDropdownPanelClass"; "required": false; "isSignal": true; }; "atomDropdownPreserveContent": { "alias": "atomDropdownPreserveContent"; "required": false; "isSignal": true; }; }, { "dropdownOpened": "dropdownOpened"; "dropdownClosed": "dropdownClosed"; }, never, never, true, never>;
}

type AtomFilterRowSize = 'xs' | 's' | 'm' | 'l' | 'xl';

declare class AtomFilterTriggerComponent {
    private readonly rowContext;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly badgeCount: _angular_core.InputSignal<number | null>;
    readonly size: _angular_core.InputSignal<AtomFilterRowSize | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    protected readonly slidersIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    protected readonly isActive: _angular_core.Signal<boolean>;
    protected readonly effectiveSize: _angular_core.Signal<AtomFilterRowSize>;
    protected readonly effectiveDisabled: _angular_core.Signal<boolean>;
    protected readonly hostClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'atom-filter-trigger': boolean;
        'atom-filter-trigger--disabled': boolean;
        'atom-filter-trigger--active': boolean;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFilterTriggerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomFilterTriggerComponent, "button[atom-filter-trigger]", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "badgeCount": { "alias": "badgeCount"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtomFilterChipComponent {
    private readonly rowContext;
    readonly displayText: _angular_core.ModelSignal<string>;
    readonly removeAriaLabel: _angular_core.InputSignal<string>;
    readonly chipAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly size: _angular_core.InputSignal<AtomFilterRowSize | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly cleared: _angular_core.OutputEmitterRef<void>;
    readonly chipClick: _angular_core.OutputEmitterRef<void>;
    /**
     * Counter suffix (e.g. `"+3"`) rendered in its own non-truncating span.
     * Internal: computed by `AtomFilterChipLabelsDirective` via
     * `setTruncatedText()`, not a consumer-facing input/model.
     */
    private readonly counterTextSignal;
    protected readonly counterText: _angular_core.Signal<string>;
    protected readonly closeIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    protected readonly effectiveSize: _angular_core.Signal<AtomFilterRowSize>;
    /**
     * Resolved disabled state (own input OR inherited row context). Intentionally
     * public (not `protected`): `AtomFilterRowComponent` reads it to build the
     * roving-tabindex items for projected chips. Part of the component contract.
     */
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    /**
     * Apply the truncation result computed by `AtomFilterChipLabelsDirective`.
     * Kept as a method (rather than two public models) so the `+N` counter stays
     * an internal detail of the chip's API.
     */
    setTruncatedText(displayText: string, counterText: string): void;
    protected readonly hostClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'atom-filter-chip': boolean;
        'atom-filter-chip--disabled': boolean;
    }>;
    protected onChipClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFilterChipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomFilterChipComponent, "atom-filter-chip", never, { "displayText": { "alias": "displayText"; "required": false; "isSignal": true; }; "removeAriaLabel": { "alias": "removeAriaLabel"; "required": true; "isSignal": true; }; "chipAriaLabel": { "alias": "chipAriaLabel"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "displayText": "displayTextChange"; "cleared": "cleared"; "chipClick": "chipClick"; }, never, never, true, never>;
}

/**
 * Computes the `displayText` (and `+N` counter) for an `atom-filter-chip` from
 * a list of selected value labels (HU-028, decision P1).
 *
 * Per the Figma spec the rule is purely count-based: the **maximum visible
 * values is always 3**, regardless of total selected, followed by a `+N`
 * counter where `N = total − 3`. If the joined string still exceeds the
 * chip's `max-width`, the label is truncated with CSS `text-overflow:
 * ellipsis` (applied on `.atom-filter-chip__label`); the `+N` counter lives
 * in its own non-truncating span so it is never clipped.
 *
 * Examples:
 *   ['A']                   → "A"                              (no counter)
 *   ['A', 'B']              → "A, B"                           (no counter)
 *   ['A', 'B', 'C']         → "A, B, C"                        (no counter)
 *   ['A', 'B', 'C', 'D']    → "A, B, C"                + "+1"
 *   ['A', …, 6 items]       → "A, B, C"                + "+3"
 *   ['Loooong, very long…'] → "Loooong, very lo…"      (CSS ellipsis)
 */
declare class AtomFilterChipLabelsDirective {
    private readonly chip;
    readonly atomFilterChipLabels: _angular_core.InputSignal<string[]>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFilterChipLabelsDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomFilterChipLabelsDirective, "atom-filter-chip[atomFilterChipLabels]", never, { "atomFilterChipLabels": { "alias": "atomFilterChipLabels"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtomFilterRowComponent {
    private readonly renderer;
    private readonly destroyRef;
    private readonly injector;
    protected readonly labels: _atomchat_io_ui_design_system.AtomFilterRowLabels;
    private readonly contextSize;
    private keyManager;
    readonly triggerLabel: _angular_core.InputSignal<string | undefined>;
    readonly size: _angular_core.InputSignal<AtomFilterRowSize | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly cleanable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly effectiveSize: _angular_core.Signal<AtomFilterRowSize>;
    readonly triggerClick: _angular_core.OutputEmitterRef<void>;
    readonly allFiltersCleared: _angular_core.OutputEmitterRef<void>;
    protected readonly projectedTrigger: _angular_core.Signal<AtomFilterTriggerComponent | undefined>;
    protected readonly chips: _angular_core.Signal<readonly AtomFilterChipComponent[]>;
    protected readonly chipElements: _angular_core.Signal<readonly ElementRef<any>[]>;
    protected readonly chipCount: _angular_core.Signal<number>;
    protected readonly hasChips: _angular_core.Signal<boolean>;
    protected readonly showClearButton: _angular_core.Signal<boolean>;
    protected readonly hasProjectedTrigger: _angular_core.Signal<boolean>;
    protected readonly hostClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'atom-filter-row': boolean;
        'atom-filter-row--disabled': boolean;
    }>;
    constructor();
    protected onChipsKeydown(event: KeyboardEvent): void;
    protected onTriggerClick(): void;
    protected onClearAll(): void;
    private setupKeyboardNavigation;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFilterRowComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomFilterRowComponent, "atom-filter-row", never, { "triggerLabel": { "alias": "triggerLabel"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "cleanable": { "alias": "cleanable"; "required": false; "isSignal": true; }; }, { "triggerClick": "triggerClick"; "allFiltersCleared": "allFiltersCleared"; }, ["projectedTrigger", "chips", "chipElements"], ["button[atom-filter-trigger]", "atom-filter-chip"], true, never>;
}

interface AtomFilterRowContext {
    size: Signal<AtomFilterRowSize>;
    disabled: Signal<boolean>;
}
declare const ATOM_FILTER_ROW_CONTEXT: InjectionToken<AtomFilterRowContext>;

/**
 * Internal, translatable labels owned by `atom-filter-row`.
 *
 * Contains the labels the row generates itself (the "Clear filters" button,
 * the toolbar aria-label and the internal trigger's aria-label) plus the
 * default visible trigger label consumed by the `atom-filter` organism. The
 * aria-labels for the chip remove button and a projected trigger are provided
 * by the consumer per usage as required inputs — see the HU-028 spec.
 */
interface AtomFilterRowLabels {
    /** Text + aria-label of the internal "Clear filters" button. */
    cleanFiltersButton: string;
    /** aria-label of the row `role="toolbar"` container. */
    rowAriaLabel: string;
    /**
     * aria-label of the internal trigger button. Action-oriented (e.g. "Open
     * filters") so a screen reader doesn't announce the same text as the parent
     * toolbar when no `triggerLabel` is set.
     */
    triggerAriaLabel: string;
    /**
     * Default visible label for the filter trigger. The `atom-filter` organism
     * falls back to this when the consumer does not set `[label]`, so the trigger
     * text localizes through the same DI token as the rest of the row. The
     * standalone `atom-filter-row` trigger stays icon-only unless given a
     * `triggerLabel` input — it does not consume this default.
     */
    triggerLabel: string;
}
/** English defaults. Override the token in `app.config.ts` to localize. */
declare const ATOM_FILTER_ROW_DEFAULT_LABELS: AtomFilterRowLabels;
declare const ATOM_FILTER_ROW_LABELS: InjectionToken<AtomFilterRowLabels>;

/**
 * Contract a registered panel (e.g. Spec B `atom-select-panel`) must satisfy
 * so `AtomFilterCategoryDirective` can proxy its state. Lives in this leaf
 * file (not the directive) so external consumers can import it without
 * triggering the `filter-panel.component ↔ filter-category.directive` ESM
 * cycle.
 */
interface FilterPanelRegisteredPanel {
    readonly selectedCount: Signal<number>;
    readonly totalCount: Signal<number>;
    readonly itemsCount: Signal<number>;
    readonly selectedLabels: Signal<string[]>;
    /** Fires on Escape/Tab; the directive forwards it to the parent filter-panel. */
    readonly closed: OutputRef<void>;
    clear(): void;
}
/**
 * Indirection so a registered panel can call `registerPanel` / `deregisterPanel`
 * without importing `AtomFilterCategoryDirective` as a class reference (which
 * would create a circular module graph through `atom-filter-panel.component`).
 * The directive provides itself for this token via `{ useExisting: AtomFilterCategoryDirective }`.
 */
interface FilterCategoryRegistration {
    registerPanel(panel: FilterPanelRegisteredPanel): void;
    deregisterPanel(panel?: FilterPanelRegisteredPanel): void;
    /** Footer the registered panel projects into its own `[atomSelectFooter]` slot. */
    readonly footerTemplate: Signal<TemplateRef<unknown> | null>;
}
declare const ATOM_FILTER_CATEGORY_REGISTRATION: InjectionToken<FilterCategoryRegistration>;

/**
 * Marker for the optional footer slot of `<atom-select-panel>`. Detected by
 * the panel via `contentChild()` to suppress its default footer button.
 */
declare class AtomSelectFooterDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectFooterDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSelectFooterDirective, "[atomSelectFooter]", never, {}, {}, never, never, true, never>;
}

/**
 * Map-backed source of truth for `<atom-select-panel>` selections.
 *
 * Every mutating method bumps a single internal `_version` signal exactly
 * once, so dependent `computed()` chains (selectedCount, selectedLabels,
 * totalCount, itemsCount) recompute once per logical operation — even when
 * the operation touches N entries at once.
 */
declare class SelectionStore {
    private readonly _entries;
    private readonly _version;
    readonly version: Signal<number>;
    size(): number;
    selectedSize(): number;
    has(value: unknown): boolean;
    isSelected(value: unknown): boolean;
    getLabel(value: unknown): string | undefined;
    /** Iterates selected values in insertion order. */
    getSelected(): IterableIterator<unknown>;
    /** Labels of selected entries in insertion order. */
    getSelectedLabels(): string[];
    /**
     * Inserts the entry if missing or updates its label if present, preserving
     * any existing `selected` flag. Bumps the version only if the entry was
     * newly inserted or its label actually changed.
     */
    upsert(value: unknown, label: string): void;
    setSelected(value: unknown, selected: boolean): void;
    /**
     * Atomically sets the `selected` flag on every supplied value. Bumps
     * version exactly once for the whole batch — regardless of N.
     */
    batchSet(values: Iterable<unknown>, selected: boolean): void;
    /**
     * Drops any entry whose value is NOT in the supplied set. Used when
     * `items[]` is replaced by reference — selections for values absent from
     * the new array are pruned.
     */
    pruneTo(allowedValues: ReadonlySet<unknown>): void;
    /** Empties every entry (labels included). Distinct from `clearSelections()`. */
    reset(): void;
    /**
     * Empties only the `selected` flags; entries themselves stay so labels
     * remain available for subsequent re-selection. Bumps version once.
     */
    clearSelections(): void;
    private _bump;
}

/**
 * Internal contract `atom-select-panel` exposes to its host directives
 * (`AtomSelectSearchDirective`, `AtomSelectAllDirective`). Not part of the
 * public DS API — host directives consume it via the injection token below,
 * never the concrete component class. Keeps the public surface free to
 * evolve without breaking the directives.
 *
 * The `<T>` parameter is the **item** type for array mode (`User`,
 * `{ label, value }`, etc.). It propagates to `items()` and
 * `setFilteredItems()` so a typed consumer sees the right shape. The methods
 * that operate on `valueKey` values (`setProjectionHidden`,
 * `applyBatchSelection`) intentionally stay `unknown` — the actual value
 * type is `T[ValueKey]` which cannot be inferred from `T` alone at the
 * interface level. `AtomSelectValueDirective<unknown>` is for the same
 * reason: its generic is the `[atomSelectValue]` value, not the raw item.
 */
interface AtomSelectPanelInternal<T = unknown> {
    readonly renderMode: Signal<'array' | 'projection' | 'virtual'>;
    readonly items: Signal<readonly T[]>;
    readonly labelKey: Signal<string>;
    readonly valueKey: Signal<string>;
    /** Frozen at construction. Reads after init reflect the initial value. */
    readonly multiple: boolean;
    /**
     * The `[atomSelectValue]` directives currently mounted in the active
     * render mode (projection: `<ng-content>` children; array / virtual:
     * directives rendered by the panel's own view). Renamed from
     * `contentChildren` to avoid collision with the Angular signal function
     * of the same name; matches the `optionDirectives` naming used by
     * `atom-select-input` (HU-022).
     */
    readonly optionDirectives: Signal<readonly AtomSelectValueDirective<unknown>[]>;
    readonly selectionStore: SelectionStore;
    readonly totalCount: Signal<number>;
    readonly itemsCount: Signal<number>;
    readonly selectedCount: Signal<number>;
    /**
     * Search hook for ARRAY mode. Pass the filtered subset; pass `null` to
     * clear the filter and restore the full list.
     */
    setFilteredItems(items: readonly T[] | null): void;
    /**
     * Search hook for PROJECTION mode. `values` is the set of `valueKey`
     * values to HIDE (i.e. non-matching). The panel toggles the native
     * `hidden` attribute on each non-matching directive's host element.
     */
    setProjectionHidden(values: ReadonlySet<unknown>): void;
    /**
     * Batch-update hook for `AtomSelectAllDirective`. Sets every supplied
     * value to `selected` atomically — single signal-version bump.
     */
    applyBatchSelection(values: Iterable<unknown>, selected: boolean): void;
    /**
     * Search-driven empty-state hook for `AtomSelectSearchDirective`. ORs into
     * the panel's effective empty state so a zero-result query renders the
     * empty slot automatically — consumers no longer need to wire
     * `[isEmpty]="searchDir.isEmpty()"` by hand.
     */
    setSearchEmpty(empty: boolean): void;
}

/**
 * Marker for the optional title slot of `<atom-select-panel>`. Applies the
 * title class so the consumer chooses the underlying tag (`<span>`, `<h3>`,
 * etc.) while typography cascades from the panel stylesheet.
 */
declare class AtomSelectTitleDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectTitleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSelectTitleDirective, "[atomSelectTitle]", never, {}, {}, never, never, true, never>;
}

/**
 * Marker on a `<ng-template>` that supplies the per-item template used by
 * `<atom-select-panel>` when virtual scroll is enabled. Inside the panel, the
 * template is rendered with `*cdkVirtualFor` over `virtualScrollItems`, which
 * sidesteps the projection-boundary DI issue that would otherwise prevent
 * `*cdkVirtualFor` from finding the viewport.
 *
 * @example
 * ```html
 * <atom-select-panel
 *   [virtualScrollItems]="countries"
 *   [virtualScrollItemSize]="32">
 *   <ng-template atomSelectVirtualItem let-country>
 *     <atom-list-item [label]="country.name" />
 *   </ng-template>
 * </atom-select-panel>
 * ```
 */
declare class AtomSelectVirtualItemDirective<T = unknown> {
    readonly templateRef: TemplateRef<AtomSelectVirtualItemContext<T>>;
    static ngTemplateContextGuard<T>(_dir: AtomSelectVirtualItemDirective<T>, ctx: unknown): ctx is AtomSelectVirtualItemContext<T>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectVirtualItemDirective<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSelectVirtualItemDirective<any>, "ng-template[atomSelectVirtualItem]", never, {}, {}, never, never, true, never>;
}
interface AtomSelectVirtualItemContext<T> {
    $implicit: T;
    index: number;
}

/**
 * Floating data-selection panel. Composes up to five optional zones via
 * projection — `[atomSelectTitle]` (slot) or `title` (text-only input),
 * `<atom-search-input>` (matched by tag — visual layout only; behavior wires
 * via `[atomSelectSearch]` host directive in HU-029B story US3), the default
 * items slot, a projected `<atom-empty-state>` (override for the internal
 * empty state, active only when `isEmpty()` is `true`), and
 * `[atomSelectFooter]` — plus a configurable default footer button.
 *
 * Selection state is the panel's responsibility — it owns an internal
 * `SelectionStore` (`Map<value, { selected, label }>`) and reflects state
 * onto each projected `atom-list-item [atomSelectValue]` via
 * `setProgrammaticSelected` / `setProgrammaticSelectionType`. Items without
 * `[atomSelectValue]` are decorative — they participate in keyboard nav but
 * not in selection.
 *
 * When the panel is rendered as a descendant of
 * `atom-list-item[atomFilterCategory]` (Spec A), it auto-registers with the
 * directive so the filter panel can derive `hasSelections`, `selectedCount`,
 * `totalCount`, `itemsCount`, and `selectedLabels` from a single source.
 *
 * Footer resolves to one of three states: projected slot → render it; no
 * slot + non-empty `config.footerActionLabel` + `hasSelection()` → default
 * tertiary button; otherwise → no footer.
 *
 * Keyboard navigation uses `FocusKeyManager` (vertical, wrap, Home/End)
 * only in static-list mode. With `virtualScrollItemSize` defined, the
 * `*cdkVirtualFor` rendered set changes on every scroll, so the manager
 * is disabled and the consumer owns focus. `Escape` emits `closed` with
 * `preventDefault`; `Tab` emits `closed` without it so focus leaves the
 * overlay naturally.
 */
declare class AtomSelectPanelComponent implements AtomDropdownPanel, FilterPanelRegisteredPanel, AtomSelectPanelInternal {
    /** Max height of the items body. Default reads `--atom-select-panel-max-height` (fallback `300px`) so an ancestor can override without a binding. */
    readonly maxHeight: _angular_core.InputSignal<string>;
    /**
     * Accessible label applied to the inner `role="listbox"` element. Lets
     * containers (e.g. `atom-filter-panel`) name the rail without forcing a
     * visible title slot. `undefined` (default) omits the attribute.
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Renders the panel inline in its own host. Default `false`: the panel only
     * exists as a `TemplateRef` to be mounted in a CDK overlay by
     * `AtomDropdownTriggerDirective` (the canonical usage). Containers that
     * compose the panel as a static surface (e.g. `atom-filter-panel`'s
     * left-column listbox) flip this to `true` so the body renders directly in
     * the host — avoiding a double render (inline + overlay).
     */
    readonly renderInline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When defined, the panel switches to virtual-scroll mode and iterates
     * `virtualScrollItems` internally with `*cdkVirtualFor` at this fixed
     * `itemSize`. Consumers supply the per-row template via
     * `<ng-template atomSelectVirtualItem let-item>`. Both `virtualScrollItems`
     * and the template are required for items to render.
     */
    readonly virtualScrollItemSize: _angular_core.InputSignal<number | undefined>;
    /**
     * Data source consumed by `*cdkVirtualFor` when `virtualScrollItemSize` is
     * defined. Ignored in static (projected) mode.
     */
    readonly virtualScrollItems: _angular_core.InputSignal<readonly unknown[]>;
    /**
     * Replaces the items area with `<atom-empty-state>`. Toggled by the consumer.
     * OR'd at the template level with the search-driven `_searchEmpty` signal
     * (pushed by `AtomSelectSearchDirective` via `setSearchEmpty`) so a zero-
     * result query renders the empty slot without any manual binding.
     */
    readonly isEmpty: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Pushed by `AtomSelectSearchDirective` whenever its debounced query yields
     * zero visible items. Kept private — consumers stay on `[isEmpty]` (input)
     * for explicit overrides; the OR below merges the two sources.
     */
    private readonly _searchEmpty;
    /** Either source flips the panel into the empty branch. */
    protected readonly _effectiveIsEmpty: Signal<boolean>;
    /**
     * Reported by the consumer when at least one option is selected. Gates the
     * default ("Clear selection") footer button. Ignored when a footer slot is
     * projected.
     */
    readonly hasSelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Text-only shortcut for the title zone. Rendered only when the
     * `[atomSelectTitle]` projection slot is empty — projection always wins so
     * complex titles (badge + text, custom typography) keep working.
     */
    readonly title: _angular_core.InputSignal<string | undefined>;
    /**
     * Multi-select mode. Default `true`. With `false`, selecting one item
     * automatically deselects the previous — same convention as
     * `atom-select-input` (HU-022). **Immutable post-init.** Runtime changes
     * emit a single dev-mode warning and are ignored. Reads after construction
     * use the frozen `this.multiple` field below.
     */
    readonly multipleInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Options for ARRAY rendering mode. When provided (and projection is empty
     * and virtual scroll is off), the panel renders one
     * `atom-list-item [atomSelectValue]` per element using `labelKey` /
     * `valueKey`. Reference replacements with overlapping `valueKey` preserve
     * selections (selection persistence — AC15).
     */
    readonly items: _angular_core.InputSignal<readonly unknown[]>;
    /** Object property used as visible text in array mode. Default `'label'`. */
    readonly labelKey: _angular_core.InputSignal<string>;
    /** Object property used as the unique value (and `SelectionStore` key) in array mode. Default `'value'`. */
    readonly valueKey: _angular_core.InputSignal<string>;
    /** Default footer button click. Suppressed when a footer slot is projected. */
    readonly footerActionClick: _angular_core.OutputEmitterRef<void>;
    /** Panel dismissal request. Emitted on `Escape` and `Tab`. */
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly panelRole: "listbox";
    readonly templateRef: Signal<TemplateRef<unknown>>;
    protected readonly config: _atomchat_io_ui_design_system.AtomSelectPanelConfig;
    protected readonly searchInput: Signal<AtomSearchInputComponent | undefined>;
    protected readonly footerSlot: Signal<AtomSelectFooterDirective | undefined>;
    protected readonly titleSlot: Signal<AtomSelectTitleDirective | undefined>;
    protected readonly emptySlot: Signal<AtomEmptyStateComponent | undefined>;
    protected readonly projectedItems: Signal<readonly AtomListItemComponent[]>;
    protected readonly projectedItemElements: Signal<readonly ElementRef<any>[]>;
    protected readonly viewItems: Signal<readonly AtomListItemComponent[]>;
    protected readonly viewItemElements: Signal<readonly ElementRef<any>[]>;
    protected readonly virtualItem: Signal<AtomSelectVirtualItemDirective<any> | undefined>;
    private readonly _contentValueDirectives;
    private readonly _viewValueDirectives;
    /** Footer template handed to us by an enclosing filter-panel category, if any. */
    protected readonly registeredFooterTemplate: _angular_core.WritableSignal<TemplateRef<unknown> | null>;
    /** True when the default footer button should render: no slot, no registered footer, a label, and an active selection. */
    protected readonly hasDefaultFooter: Signal<boolean>;
    /**
     * True when the `title` input should render as fallback. Projection wins: if
     * the consumer projects `[atomSelectTitle]`, the input is suppressed.
     */
    protected readonly showTitleInput: Signal<boolean>;
    /** Internal source of truth — exposed via AtomSelectPanelInternal for host directives. */
    readonly selectionStore: SelectionStore;
    private readonly _filteredItems;
    private readonly _hiddenProjectionValues;
    private _multipleResolved;
    /**
     * Frozen effective `multiple` value. First read locks the value for the
     * lifetime of the instance.
     *
     * **Invariant (do not break):** never read `this.multiple` from the
     * constructor body or any synchronous path that runs before the first
     * change-detection cycle. Reading too early freezes the value to the
     * input default (`true`) instead of the bound value. Reads from
     * `effect()`, lifecycle hooks (`ngOnInit` onwards), and user-driven event
     * handlers are all safe.
     */
    get multiple(): boolean;
    /**
     * Active render mode. Priority: virtual > projection > array.
     * Projection wins whenever ANY content is projected (selection-aware items
     * with `[atomSelectValue]`, decorative items, search input, footer, …)
     * — detected via `projectedItems` rather than `_contentValueDirectives` so
     * decorative items still render through `<ng-content>`.
     */
    private readonly _renderMode;
    readonly renderMode: Signal<'array' | 'projection' | 'virtual'>;
    /**
     * Active set of `[atomSelectValue]` directives for the current render mode.
     * Projection mode reads `<ng-content>` children; array + virtual modes read
     * the panel's own view (where @for / *cdkVirtualFor mount items).
     */
    readonly valueDirectives: Signal<readonly AtomSelectValueDirective<unknown>[]>;
    /**
     * Active set of `[atomSelectValue]` directives exposed to host directives
     * via `AtomSelectPanelInternal`. Renamed from `contentChildren` (which
     * collided with the Angular signal-function name) — matches the
     * `optionDirectives` naming used by `atom-select-input` (HU-022).
     */
    readonly optionDirectives: Signal<readonly AtomSelectValueDirective<unknown>[]>;
    /**
     * Post-search visible subset of `optionDirectives`. In projection mode it
     * excludes directives whose value is in `_hiddenProjectionValues` (set by
     * `AtomSelectSearchDirective`). In array mode the panel's @for already
     * renders only the filtered subset, so the active set is already the
     * visible set. Virtual mode disables search → equals the full set.
     */
    readonly visibleOptionDirectives: Signal<readonly AtomSelectValueDirective<unknown>[]>;
    /** Number of currently selected items. Derived from the store. */
    readonly selectedCount: Signal<number>;
    /** Labels of selected items in insertion order. Required by Spec A's chip strip. */
    readonly selectedLabels: Signal<string[]>;
    /** Global total for the active mode. Ignores any search filter. */
    readonly totalCount: Signal<number>;
    /**
     * Post-search visible item count. Equals `totalCount` when no search is
     * active. Matches Spec A's `FilterPanelRegisteredPanel.itemsCount`.
     */
    readonly itemsCount: Signal<number>;
    /**
     * Items to render in array mode — the search-filtered subset when a filter
     * is active, otherwise the raw input. Internal to the template; the public
     * `items()` signal continues to return the raw input so the search
     * directive can compute its filter without recursing on itself.
     */
    protected readonly visibleItems: Signal<readonly unknown[]>;
    /**
     * Pre-processed array-mode rows: `{ label, value }` derived from
     * `visibleItems()` × current `labelKey()` / `valueKey()`. Computed up-front
     * so the template renders `{{ row.label }}` / `[atomSelectValue]="row.value"`
     * — no per-row function calls in the template (would force re-evaluation
     * on every change-detection cycle).
     */
    protected readonly renderableItems: Signal<readonly {
        label: string;
        value: unknown;
    }[]>;
    private focusKeyManager?;
    private readonly destroyRef;
    private readonly renderer;
    private readonly _warnedFlags;
    constructor();
    /**
     * Moves initial focus per WAI-ARIA APG for listbox/combobox: the projected
     * search input when one is present, otherwise the first option. When focus
     * lands on the first option the manager's active index is synced so the
     * first ArrowUp/Down keystroke is not a no-op.
     */
    onAttached(): void;
    protected onKeydown(event: KeyboardEvent): void;
    /**
     * Empties the current selection. `selectedLabels` and `selectedCount` return
     * to defaults reactively. Does NOT touch any search input — search state is
     * the responsibility of `AtomSelectSearchDirective.clearSearch()`.
     */
    clear(): void;
    /**
     * Selects every currently visible item (post-search when US3 lands).
     * Mirror of `clear()`.
     */
    selectAll(): void;
    /**
     * Returns the full selected item objects (not just `valueKey` values).
     * In array mode the panel knows the raw `items()` array and resolves each
     * selected value-key back to its source object. In projection / virtual
     * modes there is no raw object set the panel can map back to (the consumer
     * owns the value space and may not be passing objects at all), so the
     * `valueKey` values themselves are returned.
     */
    getSelectedValues(): unknown[];
    /**
     * Search hook for ARRAY mode. Pass the filtered subset; pass `null` to
     * clear the filter and restore the full list. Stored in the panel's
     * private `_filteredItems` signal; the template renders `visibleItems`.
     *
     * Guard: skip the signal write when the directive pushes `null` and the
     * filter was already inactive — prevents a redundant downstream effect
     * cycle on the directive's first run when the query starts empty.
     */
    setFilteredItems(items: readonly unknown[] | null): void;
    /**
     * Search hook for PROJECTION mode. `values` is the set of `valueKey`
     * values to HIDE (non-matching items). The panel applies the `hidden`
     * attribute on each matching directive's host element via the effect
     * wired in the constructor.
     *
     * Guard: skip the signal write when both the incoming and current sets
     * are empty — without this, every empty-query tick creates a new `Set`
     * instance whose reference differs from the previous (still-empty) one
     * and triggers the projection-hidden effect for nothing.
     */
    setProjectionHidden(values: ReadonlySet<unknown>): void;
    /**
     * Batch-update hook for `AtomSelectAllDirective` (US4). Atomic mutation —
     * one signal version bump regardless of N entries.
     */
    applyBatchSelection(values: Iterable<unknown>, selected: boolean): void;
    /**
     * Search-driven empty-state hook. Pushed by `AtomSelectSearchDirective`
     * whenever its debounced query produces zero visible items so the panel
     * flips into the empty branch without a manual `[isEmpty]` binding.
     */
    setSearchEmpty(empty: boolean): void;
    private _onPick;
    /**
     * Values currently visible — used by `selectAll()`. Matches the visibility
     * logic in `AtomSelectAllDirective._visibleValues()` (skip directives
     * carrying the `hidden` attribute set by `AtomSelectSearchDirective` in
     * projection mode) so both entry points agree on what "visible" means.
     */
    private _visibleValues;
    /** Dev-mode warning gated by a per-instance per-key flag. */
    private _warnOnce;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSelectPanelComponent, "atom-select-panel", never, { "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "renderInline": { "alias": "renderInline"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollItems": { "alias": "virtualScrollItems"; "required": false; "isSignal": true; }; "isEmpty": { "alias": "isEmpty"; "required": false; "isSignal": true; }; "hasSelection": { "alias": "hasSelection"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "multipleInput": { "alias": "multiple"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": false; "isSignal": true; }; "valueKey": { "alias": "valueKey"; "required": false; "isSignal": true; }; }, { "footerActionClick": "footerActionClick"; "closed": "closed"; }, ["searchInput", "footerSlot", "titleSlot", "emptySlot", "projectedItems", "projectedItemElements", "virtualItem", "_contentValueDirectives"], ["[atomSelectTitle]", "atom-search-input", "atom-empty-state", "*", "[atomSelectFooter]"], true, never>;
}

/**
 * UI text and visual defaults for `<atom-select-panel>`. Exposed through an
 * injection token so applications override once at root (or per feature
 * scope) and every panel updates in lockstep without per-template props.
 */
interface AtomSelectPanelConfig {
    /** Placeholder applied to the projected search input when its own is unset. */
    searchPlaceholder: string;
    /** Heading rendered by the internal empty state. */
    emptyStateTitle: string;
    /** Supporting text on the empty state. Empty string keeps it out of the DOM. */
    emptyStateDescription?: string;
    /** Empty-state visual. `null` hides the icon. */
    emptyStateIcon?: AtomIconSpec | null;
    /**
     * Label for the default tertiary footer button. Empty string disables the
     * default footer entirely (no DOM, no `footerActionClick`).
     */
    footerActionLabel: string;
    /** Label for the "Select all" affordance exposed by `AtomSelectAllDirective`. */
    selectAllLabel: string;
}
/**
 * English defaults. Spread when providing partial overrides:
 *
 * ```ts
 * {
 *   provide: ATOM_SELECT_PANEL_CONFIG,
 *   useValue: { ...ATOM_SELECT_PANEL_DEFAULT_CONFIG, footerActionLabel: 'Limpiar selección' },
 * }
 * ```
 */
declare const ATOM_SELECT_PANEL_DEFAULT_CONFIG: AtomSelectPanelConfig;
/** DI token. `providedIn: 'root'` means consumers don't need to register it. */
declare const ATOM_SELECT_PANEL_CONFIG: InjectionToken<AtomSelectPanelConfig>;

/**
 * Headless "Select All" contract for `atom-select-panel`. Applied as a host
 * directive on the panel element. Exposes `allSelected` / `indeterminate`
 * signals and an `allSelectionChange` output so consumers can wire any
 * visual control (checkbox row, button, menu item, …) to the panel's
 * batch-select state.
 *
 * Active when `multiple = true` AND `atomSelectAll` input resolves truthy
 * (the input doubles as a runtime enable/disable toggle so consumers can
 * gate the feature with `[atomSelectAll]="someCondition"` without removing
 * the directive). With `multiple = false` OR `atomSelectAll = false` the
 * directive silently no-ops — signals stay falsy, `toggle()` is a no-op,
 * no errors, no warnings.
 *
 * Operates exclusively over currently visible items (post-search) — Gmail /
 * Outlook / Jira convention. Items rendered as `disabled` are skipped
 * (matching the legacy `SelectAllDirective` behavior). Mass select uses the
 * panel's atomic `applyBatchSelection` so 500 items produce a single
 * `selectedCount` recomputation rather than 500.
 *
 * The visual control is NOT shipped in this story — only the headless API.
 *
 * Exported as `atomSelectAll` so consumers can grab a template ref var:
 * `<atom-select-panel #all="atomSelectAll" atomSelectAll>`.
 */
declare class AtomSelectAllDirective<T = unknown> {
    private readonly _panel;
    /**
     * Runtime enable/disable toggle. Defaults to `true` (just applying the
     * directive enables it). Pass `[atomSelectAll]="someBool"` to gate the
     * feature without removing the host directive. When `false` the directive
     * silently no-ops — `toggle()` is a no-op and signals stay falsy.
     */
    readonly atomSelectAll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** True when the directive is active (panel is multi-select AND input is truthy). */
    private readonly _active;
    /**
     * `true` when every visible (and enabled) item is selected
     * (`selectedCount === itemsCount > 0`).
     */
    readonly allSelected: Signal<boolean>;
    /**
     * `true` when partial selection exists
     * (`0 < selectedCount < itemsCount`).
     */
    readonly indeterminate: Signal<boolean>;
    /**
     * Emits the values that became selected after the toggle (matches the
     * legacy `SelectAllDirective<T>.allSelectionChange: output<T[]>` contract).
     * On a deselect-all the emitted array is empty.
     */
    readonly allSelectionChange: _angular_core.OutputEmitterRef<T[]>;
    /**
     * Toggle handler. From `allSelected` → deselect all visible. Otherwise →
     * select all visible (skipping items marked `disabled`). No-op when the
     * directive is inactive (`multiple = false` or `[atomSelectAll]="false"`).
     *
     * Public so the future visual control can call it; consumers calling it
     * directly from code is supported but unusual (most cases use
     * `panel.selectAll()` / `panel.clear()`).
     */
    toggle(): void;
    /**
     * Values currently considered "visible":
     * - array mode: items rendered by @for (post-search subset)
     * - projection mode: directives whose host does NOT carry the `hidden` attr
     * - virtual mode: directives currently mounted by *cdkVirtualFor (viewport)
     *
     * Items rendered as `disabled` are excluded so the batch select-all
     * mirrors the legacy `SelectAllDirective` behavior (`enabledOptions`).
     *
     * Drawn from `panel.optionDirectives()` which is the active directive set
     * for the current render mode.
     */
    private _visibleValues;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSelectAllDirective<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSelectAllDirective<any>, "atom-select-panel[atomSelectAll]", ["atomSelectAll"], { "atomSelectAll": { "alias": "atomSelectAll"; "required": false; "isSignal": true; }; }, { "allSelectionChange": "allSelectionChange"; }, never, never, true, never>;
}

type SkeletonVariant = 'circle' | 'square' | 'rectangle';
type SkeletonAnimation = 'shimmer' | 'pulse' | 'none';

declare class AtomSkeletonComponent {
    readonly variant: _angular_core.InputSignal<SkeletonVariant>;
    readonly width: _angular_core.InputSignal<string>;
    readonly height: _angular_core.InputSignal<string>;
    readonly animation: _angular_core.InputSignal<SkeletonAnimation>;
    protected readonly hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSkeletonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSkeletonComponent, "atom-skeleton", never, { "variant": { "alias": "variant"; "required": true; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "animation": { "alias": "animation"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtomSkeletonDirective {
    readonly atomSkeleton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly atomSkeletonAnimation: _angular_core.InputSignal<SkeletonAnimation>;
    readonly atomSkeletonVariant: _angular_core.InputSignal<SkeletonVariant | undefined>;
    private readonly host;
    private readonly renderer;
    private readonly viewContainerRef;
    private readonly isBrowser;
    private readonly componentRef;
    private readonly detectedVariant;
    private positionWasModified;
    private readonly resolvedVariant;
    constructor();
    private activate;
    private deactivate;
    private cleanup;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSkeletonDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSkeletonDirective, "[atomSkeleton]", never, { "atomSkeleton": { "alias": "atomSkeleton"; "required": false; "isSignal": true; }; "atomSkeletonAnimation": { "alias": "atomSkeletonAnimation"; "required": false; "isSignal": true; }; "atomSkeletonVariant": { "alias": "atomSkeletonVariant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type AtomSnackbarIconType = 'none' | 'info' | 'success' | 'warning' | 'error' | 'loading' | 'custom';

declare class AtomSnackbarComponent implements AfterContentInit, OnInit {
    readonly body: _angular_core.InputSignal<string>;
    readonly headline: _angular_core.InputSignal<string | undefined>;
    readonly iconType: _angular_core.InputSignal<AtomSnackbarIconType>;
    readonly actionLabel: _angular_core.InputSignal<string | undefined>;
    readonly iconTemplate: _angular_core.InputSignal<TemplateRef<unknown> | null>;
    readonly actionTemplate: _angular_core.InputSignal<TemplateRef<unknown> | null>;
    readonly duration: _angular_core.InputSignal<number>;
    readonly dismissable: _angular_core.InputSignal<boolean>;
    readonly actionClick: _angular_core.OutputEmitterRef<void>;
    readonly dismissed: _angular_core.OutputEmitterRef<void>;
    readonly _dismiss$: _angular_core.InputSignal<Observable<void> | null>;
    readonly _pauseRequested: _angular_core.OutputEmitterRef<void>;
    readonly _resumeRequested: _angular_core.OutputEmitterRef<void>;
    private readonly _actionSlot;
    private readonly _iconSlot;
    private readonly _actionDirectives;
    readonly hasActionSlot: _angular_core.Signal<boolean>;
    readonly hasIconSlot: _angular_core.Signal<boolean>;
    readonly hasActionTemplate: _angular_core.Signal<boolean>;
    readonly hasIconTemplate: _angular_core.Signal<boolean>;
    readonly showDismissButton: _angular_core.Signal<boolean>;
    private readonly _destroyRef;
    private _timerId;
    private _emitted;
    ngOnInit(): void;
    ngAfterContentInit(): void;
    onActionClick(): void;
    private _emitDismissed;
    private _clearTimer;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSnackbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSnackbarComponent, "atom-snackbar", never, { "body": { "alias": "body"; "required": true; "isSignal": true; }; "headline": { "alias": "headline"; "required": false; "isSignal": true; }; "iconType": { "alias": "iconType"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; "iconTemplate": { "alias": "iconTemplate"; "required": false; "isSignal": true; }; "actionTemplate": { "alias": "actionTemplate"; "required": false; "isSignal": true; }; "duration": { "alias": "duration"; "required": false; "isSignal": true; }; "dismissable": { "alias": "dismissable"; "required": false; "isSignal": true; }; "_dismiss$": { "alias": "_dismiss$"; "required": false; "isSignal": true; }; }, { "actionClick": "actionClick"; "dismissed": "dismissed"; "_pauseRequested": "_pauseRequested"; "_resumeRequested": "_resumeRequested"; }, ["_actionSlot", "_iconSlot", "_actionDirectives"], ["[atomSnackbarIcon]", "button[atom-button][atomSnackbarAction][size='s'], button[atom-icon-button][atomSnackbarAction][size='s']"], true, never>;
}

declare class AtomSnackbarIconDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSnackbarIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSnackbarIconDirective, "[atomSnackbarIcon]", never, {}, {}, never, never, true, never>;
}

declare class AtomSnackbarActionDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSnackbarActionDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSnackbarActionDirective, "button[atom-button][atomSnackbarAction][size=\"s\"], button[atom-icon-button][atomSnackbarAction][size=\"s\"]", never, {}, {}, never, never, true, never>;
}

interface AtomSnackbarConfig {
    body: string;
    headline?: string;
    iconType?: AtomSnackbarIconType;
    iconTemplate?: TemplateRef<unknown>;
    actionLabel?: string;
    actionTemplate?: TemplateRef<unknown>;
    duration?: number;
    dismissable?: boolean;
}

type AtomSnackbarDismissDelegate = (ref: AtomSnackbarRef) => void;
declare class AtomSnackbarRef {
    readonly id: string;
    private readonly _dismissDelegate;
    readonly _action$: Subject<void>;
    readonly _dismissed$: ReplaySubject<void>;
    constructor(id: string, _dismissDelegate: AtomSnackbarDismissDelegate);
    onAction(): Observable<void>;
    afterDismissed(): Observable<void>;
    dismiss(): void;
}

declare class AtomSnackbarService {
    private readonly _matSnackBar;
    private readonly _defaultDuration;
    private _containerRef;
    open(config: AtomSnackbarConfig): AtomSnackbarRef;
    dismiss(ref: AtomSnackbarRef): void;
    dismissAll(): void;
    private _ensureContainer;
    private _idCounter;
    private _generateId;
    private _warnUntrackedDismiss;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSnackbarService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AtomSnackbarService>;
}

declare const ATOM_SNACKBAR_DURATION: InjectionToken<number>;

/** i18n hook for the filter panel's text surfaces. See `./README.md`. */
interface AtomFilterPanelConfig {
    readonly clearAllLabel: string;
    readonly clearCategoryLabel: string;
    /** Counter pattern with `{selected}` / `{total}` placeholders. */
    readonly countPattern: string;
    /** Accessible name for the categories listbox (`aria-label`). */
    readonly categoriesLabel: string;
    /**
     * Accessible name for the whole popup (`role="dialog"` `aria-label`).
     * Describes the popup's overall purpose — distinct from `categoriesLabel`,
     * which names only the left-column listbox.
     */
    readonly dialogLabel: string;
}
/** Detail emitted with `(categoryCleared)`. */
interface CategoryClearedDetail {
    readonly index: number;
    readonly label: string;
}
/** Detail emitted with `(categoryActivated)`. */
interface CategoryActivatedDetail {
    readonly index: number;
    readonly label: string;
}

/**
 * Turns an `atom-list-item` into a filter-panel category trigger. Carries
 * the right-column `TemplateRef` and proxies state from the registered
 * panel. See `./README.md` ("Category directive").
 */
declare class AtomFilterCategoryDirective {
    readonly atomFilterCategory: _angular_core.InputSignal<TemplateRef<unknown>>;
    private readonly _injectedPanel;
    private readonly _linkedPanel;
    private readonly _panel;
    private readonly _hostRef;
    private readonly _host;
    private readonly _isBrowser;
    private readonly _registeredPanel;
    private _registeredPanelClosedUnsubscribe;
    protected readonly _isActive: Signal<boolean>;
    /**
     * Lets the host panel register itself when this category was reprojected and
     * could not resolve the panel through the element injector. No-op for direct
     * usage (the injected panel already wins in `_panel`).
     */
    linkPanel(panel: AtomFilterPanelComponent): void;
    /**
     * Symmetric counterpart of {@link linkPanel}, called from the panel's
     * `ngOnDestroy`. Clears the linked reference (only if it still points at the
     * panel that is tearing down) so a category that outlives the panel — e.g. the
     * organism removed via control flow, where projection cleanup can destroy the
     * panel first — does not keep calling into a destroyed instance through
     * `_panel()`. No-op when a different, still-live panel has since linked.
     */
    unlinkPanel(panel: AtomFilterPanelComponent): void;
    readonly hasSelections: Signal<boolean>;
    readonly selectedCount: Signal<number>;
    readonly totalCount: Signal<number>;
    readonly selectedLabels: Signal<string[]>;
    /** Right-column footer template proxied from the parent panel to the registered panel. */
    readonly footerTemplate: Signal<TemplateRef<unknown> | null>;
    /**
     * `true` iff the registered panel reports zero visible items. Defaults
     * to `false` so an unregistered panel is treated as populated.
     * See `./README.md` ("`itemsCount` caveat — search conflation").
     */
    readonly selectedPanelHasZeroOptions: Signal<boolean>;
    registerPanel(panel: FilterPanelRegisteredPanel): void;
    /**
     * Clears the registration. With a `panel` argument, only clears when it
     * matches the currently registered one; without arguments, clears
     * unconditionally. See `./README.md` ("Registered panel contract").
     */
    deregisterPanel(panel?: FilterPanelRegisteredPanel): void;
    clear(): void;
    focus(): void;
    /** Accessible label read from the host element's text content. */
    get label(): string;
    /** True iff the host atom-list-item is rendering as disabled. */
    get disabled(): boolean;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFilterCategoryDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomFilterCategoryDirective, "atom-list-item[atomFilterCategory]", ["atomFilterCategory"], { "atomFilterCategory": { "alias": "atomFilterCategory"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtomFilterPanelComponent implements AtomDropdownPanel, OnDestroy {
    /**
     * Renders the panel inline in its own host (HU-029 standalone usage, the
     * default). The `atom-filter` organism sets this to `false` so the panel only
     * exists as a `TemplateRef` to be mounted in the CDK overlay by the trigger —
     * avoiding a double render (inline + overlay).
     */
    readonly renderInline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly defaultCategoryIndex: _angular_core.InputSignal<number>;
    readonly clearAllLabel: _angular_core.InputSignal<string | undefined>;
    readonly clearCategoryLabel: _angular_core.InputSignal<string | undefined>;
    readonly countPattern: _angular_core.InputSignal<string | undefined>;
    readonly categoriesLabel: _angular_core.InputSignal<string | undefined>;
    readonly dialogLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Externally supplied category list. The `atom-filter` organism reprojects
     * categories through its own `<ng-content>`; Angular content queries do not
     * cross that reprojection boundary, so the organism — which DOES see them as
     * its direct content — passes them in here. Rendering still flows through the
     * left-column `<ng-content>` normally. Empty for direct usage, where the
     * `contentChildren` query below is the source of truth.
     */
    readonly externalCategories: _angular_core.InputSignal<readonly AtomFilterCategoryDirective[]>;
    readonly allCleared: _angular_core.OutputEmitterRef<void>;
    readonly categoryCleared: _angular_core.OutputEmitterRef<CategoryClearedDetail>;
    readonly categoryActivated: _angular_core.OutputEmitterRef<CategoryActivatedDetail>;
    /**
     * Root `<ng-template>` portaled into the overlay by the trigger directive.
     * Queried by the `#panelContent` reference variable rather than by
     * `TemplateRef` type: a type query resolves the first root-level
     * `<ng-template>` in declaration order, which could silently become the wrong
     * one if another root template is ever added (e.g. a lazy empty state).
     */
    readonly templateRef: Signal<TemplateRef<unknown>>;
    /** Right-column footer (Clear + counter) projected into the active panel's `[atomSelectFooter]`. */
    readonly rightColumnFooterTemplate: Signal<TemplateRef<unknown> | undefined>;
    /** `[maxHeight]` for the left-column `<atom-select-panel>`; right column inherits via CSS var. */
    protected readonly _columnMaxHeight = "var(--filter-panel-column-max-height)";
    /** Composite popup with internal `role="listbox"` navigation → `'dialog'`. */
    readonly panelRole: "dialog";
    /** Dismissal request emitted on `Escape`/`Tab` (closes & confirms, no rollback). */
    readonly closed: _angular_core.OutputEmitterRef<void>;
    private readonly _injector;
    private readonly _vcr;
    private readonly _renderer;
    private readonly _isBrowser;
    private readonly _config;
    private readonly _projectedCategories;
    /**
     * The category list: externally supplied (organism composition) when present,
     * otherwise the directly-projected content children (direct usage).
     */
    readonly categories: Signal<readonly AtomFilterCategoryDirective[]>;
    private readonly _portalOutlets;
    private readonly _categoryHosts;
    private readonly _activeCategoryIndex;
    private readonly _portalRegistry;
    private readonly _hasEverRendered;
    private _previousActive;
    private readonly _hasUserNavigated;
    readonly activeCategory: Signal<AtomFilterCategoryDirective | null>;
    readonly globalHasSelections: Signal<boolean>;
    protected readonly _isEmpty: Signal<boolean>;
    protected readonly _effectiveClearAllLabel: Signal<string>;
    protected readonly _effectiveClearCategoryLabel: Signal<string>;
    protected readonly _effectiveCountPattern: Signal<string>;
    protected readonly _effectiveCategoriesLabel: Signal<string>;
    protected readonly _effectiveDialogLabel: Signal<string>;
    protected readonly _counterText: Signal<string>;
    constructor();
    ngOnDestroy(): void;
    activateCategory(target: AtomFilterCategoryDirective | number): void;
    clearAll(): void;
    clearCategory(target: AtomFilterCategoryDirective | number): void;
    protected _onClearActiveCategory(): void;
    focus(): void;
    /**
     * Called by the trigger after the overlay attaches. Places initial focus on
     * the active category whenever one was selected programmatically — opening
     * from a category chip calls `activateCategory()` synchronously, before this
     * deferred microtask runs, so focus must land on the same category the right
     * column renders (and marks `aria-selected`). Only on a fresh open with no
     * prior navigation does it fall back to the heuristic: the first category
     * with selections, or the first category otherwise (resolution Pe1). Does not
     * replace the per-category keyboard navigation.
     */
    onAttached(): void;
    /** `Escape`/`Tab` dismiss the panel; everything else is left to the list nav. */
    protected onKeydown(event: KeyboardEvent): void;
    /**
     * Forwards an inner column's dismissal to this panel's `closed` so the
     * trigger detaches the overlay. Both columns are `<atom-select-panel>`s —
     * themselves `AtomDropdownPanel`s whose own keydown handler calls
     * `stopPropagation()` on `Escape`/`Tab`. Since focus lives on a category
     * item or option INSIDE a column (see `onAttached`), that handler fires
     * first and swallows the keystroke before it can reach this dialog's
     * `(keydown)` or the overlay's keyboard dispatcher. Re-emitting the column's
     * `closed` here is what actually closes the filter panel on `Escape`/`Tab`.
     */
    protected _onColumnDismiss(): void;
    /** Defensive coercion: NaN, negative, or out-of-range → 0. */
    private _coerceIndex;
    private _indexOf;
    private _resolveTarget;
    private _ensureAttached;
    private _showOnly;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFilterPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomFilterPanelComponent, "atom-filter-panel", never, { "renderInline": { "alias": "renderInline"; "required": false; "isSignal": true; }; "defaultCategoryIndex": { "alias": "defaultCategoryIndex"; "required": false; "isSignal": true; }; "clearAllLabel": { "alias": "clearAllLabel"; "required": false; "isSignal": true; }; "clearCategoryLabel": { "alias": "clearCategoryLabel"; "required": false; "isSignal": true; }; "countPattern": { "alias": "countPattern"; "required": false; "isSignal": true; }; "categoriesLabel": { "alias": "categoriesLabel"; "required": false; "isSignal": true; }; "dialogLabel": { "alias": "dialogLabel"; "required": false; "isSignal": true; }; "externalCategories": { "alias": "externalCategories"; "required": false; "isSignal": true; }; }, { "allCleared": "allCleared"; "categoryCleared": "categoryCleared"; "categoryActivated": "categoryActivated"; "closed": "closed"; }, ["_projectedCategories"], ["atom-empty-state", "*"], true, never>;
}

declare const ATOM_FILTER_PANEL_DEFAULT_CONFIG: AtomFilterPanelConfig;
declare const ATOM_FILTER_PANEL_CONFIG: InjectionToken<AtomFilterPanelConfig>;

/**
 * `atom-filter` — the integrating organism of the Atom filtering system.
 * Composes `atom-filter-row` (HU-028 toolbar: trigger + applied-category chips +
 * "clear filters") with `atom-filter-panel` (HU-029), opened via a projected
 * `button[atom-filter-trigger]` + `AtomDropdownTriggerDirective` at fixed
 * `bottom-start`. Per-category selection state lives in the reprojected
 * `atom-select-panel`s (HU-029B) and survives close→reopen via the trigger's
 * `atomDropdownPreserveContent` (detach-without-dispose) mode.
 *
 * The consumer only projects `atom-list-item[atomFilterCategory]` and reads the
 * exposed signals/outputs; every public signal is a `computed` proxy of the
 * panel/trigger state, so the organism stays the single source of truth.
 *
 * ## Restriction: categories must be declared statically
 *
 * ```html
 * <atom-filter>
 *   <atom-list-item label="Status" [atomFilterCategory]="statusTpl" />
 *   <atom-list-item label="Tags"   [atomFilterCategory]="tagsTpl" />
 * </atom-filter>
 * ```
 *
 * Generating them with `@for`/`@if` is not supported: Angular does not reproject
 * control-flow content across the organism's nested `<ng-content>` into the
 * overlay panel, so the panel's left column would render empty.
 */
declare class AtomFilterComponent {
    /**
     * Trigger label. Propagated to the row as `[triggerLabel]`. When unset it
     * falls back to `ATOM_FILTER_ROW_LABELS.triggerLabel` (English `'Filters'` by
     * default) so the trigger text localizes through the same DI token as the
     * rest of the filter system — override that token in `app.config.ts` rather
     * than hardcoding a translated string here. Resolved via `_effectiveLabel`.
     */
    readonly label: _angular_core.InputSignal<string | undefined>;
    /** Disables the trigger; the panel cannot open. Propagated to the row. */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Initial category passthrough to `atom-filter-panel`. */
    readonly defaultCategoryIndex: _angular_core.InputSignal<number>;
    /**
     * Renders the applied-category chips in the row. When `false`, the row shows
     * only the trigger: chips are suppressed but the badge still counts categories
     * with selections, so the count increments as filters are applied (e.g. a
     * compact "Filtros bandeja N" toolbar). The counter is independent of the
     * chips — it reads `appliedCategories().length` directly — so hiding them does
     * not affect it. With no chips the row's "clear filters" button is also hidden
     * (it is chip-driven); clearing still works via the panel and `clearAll()`.
     * Defaults to `true`.
     */
    readonly showChips: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly _rowLabels;
    /** Resolved trigger label: explicit `[label]` input, else the DI-token default. */
    protected readonly _effectiveLabel: Signal<string>;
    private readonly panel;
    private readonly trigger;
    protected readonly projectedCategories: Signal<readonly AtomFilterCategoryDirective[]>;
    /** `true` when any category has at least one selection. */
    readonly isFiltered: Signal<boolean>;
    /** Current overlay state. */
    readonly isOpened: Signal<boolean>;
    /** Proxy of the panel's projected categories. */
    readonly categories: Signal<readonly AtomFilterCategoryDirective[]>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly allCleared: _angular_core.OutputEmitterRef<void>;
    readonly categoryCleared: _angular_core.OutputEmitterRef<CategoryClearedDetail>;
    /** Opens the panel programmatically (no-op when disabled). */
    open(): void;
    /** Closes the panel programmatically. */
    close(): void;
    /**
     * Clears every category via `panel.clearAll()`; `onPanelAllCleared` is the
     * single close+emit path (avoids double emits). No-op while `disabled` so the
     * component stays inert to mutations, matching `open`/`activateCategory`.
     */
    clearAll(): void;
    /** Activates a category by reference or index, opening the panel if needed. */
    activateCategory(target: AtomFilterCategoryDirective | number): void;
    /**
     * Clears a single category by reference or index. Keeps the panel open.
     * No-op while `disabled`, matching `clearAll`/`open`/`activateCategory`.
     */
    clearCategory(target: AtomFilterCategoryDirective | number): void;
    /** Categories with at least one active selection — drives the badge count. */
    protected readonly appliedCategories: Signal<AtomFilterCategoryDirective[]>;
    /**
     * Applied categories to render as chips — `appliedCategories()` when
     * `showChips` is on, empty otherwise (counter-only toolbar). Kept as a flat
     * single-`@for` source rather than wrapping the loop in `@if (showChips())`:
     * the extra control-flow nesting hides the chips from the row's
     * `contentChildren(AtomFilterChipComponent)` query (`descendants: false`), so
     * `hasChips()` would read false and the chips would never project. The badge
     * still reads `appliedCategories()` directly, so the count is unaffected.
     */
    protected readonly chipCategories: Signal<AtomFilterCategoryDirective[]>;
    /**
     * A category chip also acts as a trigger: open the panel if closed, then
     * navigate to that category. If already open, only navigate — no reopen.
     * No-op while `disabled` — the guard covers BOTH `open()` and the subsequent
     * `activateCategory()` so a disabled control emits no navigation side-effects.
     */
    protected onCategoryChipClick(category: AtomFilterCategoryDirective): void;
    /** Single close+emit path for any "clear all" source (panel emits `allCleared`). */
    protected onPanelAllCleared(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFilterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomFilterComponent, "atom-filter", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "defaultCategoryIndex": { "alias": "defaultCategoryIndex"; "required": false; "isSignal": true; }; "showChips": { "alias": "showChips"; "required": false; "isSignal": true; }; }, { "opened": "opened"; "closed": "closed"; "allCleared": "allCleared"; "categoryCleared": "categoryCleared"; }, ["projectedCategories"], ["atom-list-item[atomFilterCategory]"], true, never>;
}

/**
 * Internationalization service for `AtomPaginationComponent`.
 *
 * Owns every human-readable string the paginator renders plus the
 * range-label function. Mirrors the override ergonomics of Angular
 * Material's `MatPaginatorIntl`: consumers extend the class, override the
 * label fields / `getRangeLabel`, and re-provide at module or component
 * scope.
 *
 * Subclasses that mutate labels after construction (e.g. on an async i18n
 * bundle load) MUST call `changes.next()` so every mounted paginator
 * refreshes its visible labels in the next change-detection tick.
 */
declare class AtomPaginatorIntl {
    /** `aria-label` exposed on the paginator host (landmark name). */
    paginatorLabel: string;
    /** Label rendered next to the records-per-page selector. */
    itemsPerPageLabel: string;
    /** `aria-label` for the jump-to-first navigation control. */
    firstPageLabel: string;
    /** `aria-label` for the jump-to-last navigation control. */
    lastPageLabel: string;
    /** `aria-label` for the next-page navigation control. */
    nextPageLabel: string;
    /** `aria-label` for the previous-page navigation control. */
    previousPageLabel: string;
    /**
     * Notifies mounted paginators that labels have changed and the DOM
     * should be refreshed. Call `changes.next()` after mutating any label
     * or after `getRangeLabel`'s output depends on newly-loaded i18n data.
     */
    readonly changes: Subject<void>;
    /**
     * Build the human-readable page-range label shown in the page-info zone.
     *
     * Default format:
     * - `length === 0` → `"0 of 0"`
     * - `length > 0`   → `"Page {pageIndex + 1} of {totalPages}"`
     *   where `totalPages = ceil(length / pageSize)`.
     *
     * Pure function: same inputs always yield the same output. Subclasses
     * overriding this method MUST preserve that property and SHOULD localize
     * the surrounding text (e.g. `"Página X de Y"`).
     */
    getRangeLabel(pageIndex: number, pageSize: number, length: number): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomPaginatorIntl, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AtomPaginatorIntl>;
}

/**
 * Public types for the atom-pagination organism.
 *
 * Decoupled from Angular Material's `PageEvent` so consumers do not pull
 * in `@angular/material` types when integrating with the design system.
 */
/**
 * Payload emitted by `AtomPaginationComponent.pageChange` for every page
 * transition (user-driven or self-correcting).
 *
 * The `previousPageIndex` field may exceed `Math.ceil(length / pageSize) - 1`
 * only when the event is a corrective emission triggered by a runtime
 * `length` shrink — in that case it captures the now-invalid index the
 * component held before clamping.
 */
interface AtomPageEvent {
    /** Post-change effective page index, 0-based. */
    readonly pageIndex: number;
    /** Pre-change page index, 0-based. */
    readonly previousPageIndex: number;
    /** Page size in effect after the change. Always ≥ 1. */
    readonly pageSize: number;
    /** Dataset length in effect at emission time. Always ≥ 0. */
    readonly length: number;
}

/**
 * Pagination organism. Internal override signals win over inputs until a
 * consumer rebind resets them to `null` (no echo). `pageChange` only
 * fires on component-initiated transitions.
 */
declare class AtomPaginationComponent {
    protected readonly intl: AtomPaginatorIntl;
    readonly length: _angular_core.InputSignal<number>;
    readonly pageSize: _angular_core.InputSignal<number>;
    readonly pageIndex: _angular_core.InputSignal<number>;
    readonly pageSizeOptions: _angular_core.InputSignal<readonly number[]>;
    readonly pageChange: _angular_core.OutputEmitterRef<AtomPageEvent>;
    private readonly _internalPageIndex;
    private readonly _internalPageSize;
    protected readonly effectivePageSize: _angular_core.Signal<number>;
    protected readonly effectiveLength: _angular_core.Signal<number>;
    protected readonly totalPages: _angular_core.Signal<number>;
    protected readonly effectivePageIndex: _angular_core.Signal<number>;
    protected readonly isFirstPage: _angular_core.Signal<boolean>;
    protected readonly isLastPage: _angular_core.Signal<boolean>;
    protected readonly isEmpty: _angular_core.Signal<boolean>;
    protected readonly rangeLabel: _angular_core.WritableSignal<string>;
    constructor();
    protected onPageSizeChange(newSize: number): void;
    /**
     * Silently updates the displayed page index without emitting `pageChange`.
     * Used by `AtomPaginatorMatBridge` to reflect a page clamped by
     * `MatTableDataSource` (e.g. after a filter reduces total pages).
     * Do NOT call from user-interaction code — use `_navigateTo()` instead.
     */
    setInternalPageIndex(index: number): void;
    firstPage(): void;
    previousPage(): void;
    nextPage(): void;
    lastPage(): void;
    private _navigateTo;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomPaginationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomPaginationComponent, "atom-pagination", never, { "length": { "alias": "length"; "required": true; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "pageIndex": { "alias": "pageIndex"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; }, { "pageChange": "pageChange"; }, never, never, true, never>;
}

/**
 * DI token for the `aria-label` on the sort icon button rendered inside
 * `[atomSortHeader]`. Override at module or component scope to localize:
 *
 * ```typescript
 * providers: [{ provide: ATOM_SORT_HEADER_SORT_LABEL, useValue: 'Ordenar' }]
 * ```
 *
 * The `[atomSortHeaderLabel]` input on the component takes precedence when set.
 */
declare const ATOM_SORT_HEADER_SORT_LABEL: InjectionToken<string>;

/**
 * Client-side data source for atom-table with sorting, filtering and pagination.
 * Extends MatTableDataSource and adds {@link atomPaginator} for Atom DS pagination.
 */
declare class AtomTableDataSource<T extends object> extends MatTableDataSource<T> {
    private _atomPaginator;
    private _atomPaginatorBridge;
    /**
     * Connects an {@link AtomPaginationComponent} instance.
     * Wires pagination through {@link AtomPaginatorMatBridge} so MatTableDataSource
     * can slice rows without MatPaginator UI.
     */
    set atomPaginator(paginator: AtomPaginationComponent | null | undefined);
    get atomPaginator(): AtomPaginationComponent | null;
    _updatePaginator(filteredDataLength: number): void;
    disconnect(): void;
}

/** Row selection mode for {@link AtomTableComponent}. */
type AtomTableSelectionMode = 'single' | 'multiple';

/**
 * Atom Design System table container.
 * Extends CDK Table without Material MDC styling.
 *
 * Header rows are always sticky — no flag needed.
 * Set `atomSelectable` to enable interactive row styling for selection flows.
 */
declare class AtomTableComponent<T> extends CdkTable<T> implements AfterViewInit {
    protected stickyCssClass: string;
    protected needsPositionStickyOnElement: boolean;
    /** Enables row hover, selection styling and pointer cursor on data rows. */
    readonly atomSelectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Selection mode when `atomSelectable` is enabled. Defaults to multiple. */
    readonly atomSelectionMode: _angular_core.InputSignal<AtomTableSelectionMode>;
    /** Optional maximum number of rows that can be selected (multiple mode only). */
    readonly atomMaxSelection: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Renders a checkbox column (place `<atom-table-selection-column />` and
     * include `atom-select` in displayed columns). Multiple mode only.
     */
    readonly atomSelectionCheckboxes: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Emits whenever the table selection changes. */
    readonly atomSelectionChange: _angular_core.OutputEmitterRef<readonly T[]>;
    /**
     * TrackBy function for stable row identity across re-renders (sort, filter, pagination).
     * Aliased to avoid collision with CDK's own `trackBy` property setter.
     */
    readonly atomTrackBy: _angular_core.InputSignal<TrackByFunction<T> | undefined>;
    private readonly selectionController;
    private readonly destroyRef;
    private readonly elementRef;
    private readonly renderer;
    private readonly columnDefs;
    private readonly projectedNoDataRow;
    private readonly selectionColumn;
    private readonly sort;
    private readonly injector;
    private stickyLayoutPassScheduled;
    private contentInitialized;
    private viewInitialized;
    private focusKeyManager;
    private focusKeyManagerCleanup;
    private currentRowElements;
    constructor();
    /** Returns whether a row is selected by the built-in selection controller. */
    isRowSelected(row: T): boolean;
    /** Toggles a row through the built-in selection controller. */
    toggleRowSelection(row: T, disabled?: boolean): boolean;
    ngAfterViewInit(): void;
    protected onTableKeydown(event: KeyboardEvent): void;
    private teardownKeyboardManager;
    private setupKeyboardManager;
    ngAfterContentInit(): void;
    ngAfterContentChecked(): void;
    /** Triggers a full CDK render after programmatic column registration. */
    requestRender(): void;
    private completeContentInit;
    set dataSource(dataSource: CdkTableDataSourceInput<T>);
    get dataSource(): CdkTableDataSourceInput<T>;
    /** Wires `atomSort` on the host to {@link MatTableDataSource} instances. */
    private connectAtomSort;
    /** Registers the projected no-data row before CDK renders rows. */
    private syncNoDataRow;
    /** Defers CDK render until the checkbox column is registered via addColumnDef. */
    private shouldWaitForSelectionColumn;
    /** Enables fixed layout before the first render when sticky columns are declared. */
    private ensureFixedLayoutForStickyColumns;
    /** Enables fixed layout and refreshes sticky offsets for sticky columns and header. */
    private syncStickyLayout;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTableComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomTableComponent<any>, "table[atom-table], table[atomTable]", ["atomTable"], { "atomSelectable": { "alias": "atomSelectable"; "required": false; "isSignal": true; }; "atomSelectionMode": { "alias": "atomSelectionMode"; "required": false; "isSignal": true; }; "atomMaxSelection": { "alias": "atomMaxSelection"; "required": false; "isSignal": true; }; "atomSelectionCheckboxes": { "alias": "atomSelectionCheckboxes"; "required": false; "isSignal": true; }; "atomTrackBy": { "alias": "atomTrackBy"; "required": false; "isSignal": true; }; }, { "atomSelectionChange": "atomSelectionChange"; }, ["columnDefs", "projectedNoDataRow", "selectionColumn"], ["caption", "colgroup, col"], true, never>;
}

/**
 * Data cell host. Applies DS styles and wraps projected content in the
 * `div.atom-table__cell-inner > span.atom-table__cell-content` layout container.
 *
 * Declared as a `@Component` (not `@Directive`) so the wrapper is created
 * declaratively via `<ng-content>` — avoiding the imperative DOM re-parenting
 * that would break Angular event listeners and ContentChild queries inside cells.
 */
declare class AtomCellComponent extends CdkCell {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCellComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomCellComponent, "[atomCell]", never, {}, {}, never, ["*"], true, never>;
}

/** Footer row placeholder (CDK parity). */
declare class AtomFooterRowComponent extends CdkFooterRow {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomFooterRowComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomFooterRowComponent, "atom-footer-row, tr[atom-footer-row], tr[atomFooterRow]", ["atomFooterRow"], {}, {}, never, never, true, never>;
}

/** Header row for atom-table. */
declare class AtomHeaderRowComponent extends CdkHeaderRow {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomHeaderRowComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomHeaderRowComponent, "atom-header-row, tr[atom-header-row], tr[atomHeaderRow]", ["atomHeaderRow"], {}, {}, never, never, true, never>;
}

/** Data row for atom-table. */
declare class AtomRowComponent<T = unknown> extends CdkRow implements OnInit {
    private readonly table;
    private readonly selection;
    private readonly _el;
    private readonly _renderer;
    /** Manual selected state when not using `[atomRowValue]`. */
    readonly atomSelected: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Row value tracked by the table selection controller. */
    readonly atomRowValue: _angular_core.InputSignal<T | undefined>;
    readonly atomDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    constructor();
    ngOnInit(): void;
    private readonly selectable;
    protected showSelected: _angular_core.Signal<boolean>;
    protected ariaSelected: _angular_core.Signal<boolean | null>;
    /** Satisfies {@link RovingTabindexItem} — lets the table's FocusKeyManager skip disabled rows. */
    disabled(): boolean;
    private static readonly INTERACTIVE_SELECTOR;
    protected onRowClick(event: Event): void;
    protected onRowKeydown(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomRowComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomRowComponent<any>, "atom-row, tr[atom-row], tr[atomRow]", ["atomRow"], { "atomSelected": { "alias": "atomSelected"; "required": false; "isSignal": true; }; "atomRowValue": { "alias": "atomRowValue"; "required": false; "isSignal": true; }; "atomDisabled": { "alias": "atomDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Implements {@link MatSortable} and integrates with `atomSort` on the table.
 */
declare class AtomSortHeaderComponent implements MatSortable, OnInit, OnDestroy {
    private readonly sort;
    private readonly columnDef;
    private readonly destroyRef;
    private readonly _sortRevision;
    /** Sort column id. Defaults to the parent column definition name. */
    readonly sortHeaderId: _angular_core.InputSignal<string>;
    /**
     * `aria-label` for the sort icon button. Defaults to the value of
     * `ATOM_SORT_HEADER_SORT_LABEL` (English `'Sort'`); override at module
     * or component scope via that token, or bind this input directly for
     * per-column labels (e.g. `atomSortHeaderLabel="Sort by name"`).
     */
    readonly sortLabel: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly sortStart: _angular_core.InputSignal<SortDirection>;
    readonly sortDisableClear: _angular_core.InputSignalWithTransform<boolean | undefined, string | boolean | undefined>;
    /** MatSortable contract — Material reads these as plain properties. */
    get id(): string;
    get start(): SortDirection;
    get disableClear(): boolean;
    ngOnInit(): void;
    ngOnDestroy(): void;
    protected readonly isSorted: _angular_core.Signal<boolean>;
    protected readonly sortIcon: _angular_core.Signal<_fortawesome_fontawesome_common_types.IconDefinition>;
    protected readonly ariaSort: _angular_core.Signal<"none" | "ascending" | "descending">;
    toggleSort(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSortHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSortHeaderComponent, "[atomSortHeader]", never, { "sortHeaderId": { "alias": "atomSortHeader"; "required": false; "isSignal": true; }; "sortLabel": { "alias": "atomSortHeaderLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "atomSortHeaderDisabled"; "required": false; "isSignal": true; }; "sortStart": { "alias": "atomSortStart"; "required": false; "isSignal": true; }; "sortDisableClear": { "alias": "atomSortDisableClear"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** Column id inserted by {@link AtomTableSelectionColumnComponent}. */
declare const ATOM_TABLE_SELECTION_COLUMN = "atom-select";
/** Prepends the selection checkbox column id to a displayed-columns list. */
declare function prependAtomTableSelectionColumn(columns: readonly string[]): string[];
/**
 * Checkbox column for multi-select tables.
 * Must be a direct child of `atom-table` when `atomSelectionCheckboxes` is enabled.
 *
 * ### Supported data source types
 * - `T[]` — static array (re-read on every CDK render pass)
 * - `MatTableDataSource<T>` / `AtomTableDataSource<T>` — reads `filteredData`
 * - `Observable<T[]>` or any custom `DataSource<T>` — reads CDK's internal
 *   `_data` buffer, which is kept up-to-date by the table's data-source subscription
 *
 * Rows are re-computed on every `CdkTable.contentChanged` emission so that
 * filter, sort and pagination changes are reflected immediately.
 */
declare class AtomTableSelectionColumnComponent implements OnDestroy {
    private readonly selection;
    private readonly tableHost;
    private readonly columnDef;
    private readonly headerCellDef;
    private readonly cellDef;
    private registeredColumnDef;
    /** Marks a row as not selectable for checkbox/master-toggle logic. */
    readonly isRowDisabled: _angular_core.InputSignal<(row: unknown) => boolean>;
    protected readonly visible: Signal<boolean>;
    /**
     * Reactive row list — re-evaluated on every `CdkTable.contentChanged` so
     * that filter, sort and pagination changes invalidate downstream computeds
     * (allSelected, indeterminate, disabledRows) immediately.
     */
    protected readonly rows: Signal<readonly unknown[]>;
    protected readonly allSelected: Signal<boolean>;
    protected readonly indeterminate: Signal<boolean>;
    /** O(1) lookup delegated to the controller's reactive Set. */
    protected readonly selectedSet: Signal<Set<unknown>>;
    /**
     * Rows where the **checkbox** must render as disabled — only the selection-limit
     * overflow case (row is NOT intrinsically disabled, so it has no
     * `pointer-events: none` from CSS, and the checkbox must block clicks itself).
     *
     * Intrinsically disabled rows (`[atomDisabled]`) already have `pointer-events:none`
     * on the row element; adding `[disabled]` to their checkbox is redundant and would
     * show the disabled checkbox visual on top of the row's opacity treatment.
     */
    protected readonly checkboxDisabledRows: Signal<Set<unknown>>;
    constructor();
    ngOnDestroy(): void;
    /** Whether the column def was registered on the parent table. */
    isRegistered(): boolean;
    protected onMasterToggle(event: AtomCheckboxChange): void;
    protected onRowToggle(row: unknown, event: AtomCheckboxChange): void;
    private registerColumn;
    private unregisterColumn;
    /**
     * Extracts the current row data from the active data source.
     *
     * Called on every `contentChanged` emission so the result is always current:
     * - `T[]` — returned as-is
     * - `MatTableDataSource<T>` — `filteredData` (post-filter, pre-pagination slice)
     * - `Observable<T[]>` / custom `DataSource<T>` — reads CDK's internal `_data`
     *   buffer, which the table keeps synchronized with its data-source subscription
     */
    private readRows;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTableSelectionColumnComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomTableSelectionColumnComponent, "atom-table-selection-column", never, { "isRowDisabled": { "alias": "isRowDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AtomTableSelectionController<T> {
    private readonly selectionModel;
    private readonly _disabledRows;
    private readonly _changed;
    private mode;
    private maxSelection;
    /** Currently selected row values as a readonly array. */
    readonly selected: _angular_core.Signal<readonly T[]>;
    /** Currently selected row values as a Set — O(1) lookup in templates. */
    readonly selectedSet: _angular_core.Signal<Set<T>>;
    /** Set of row values explicitly marked disabled via `[atomDisabled]` on the row component. */
    readonly disabledRowsSet: _angular_core.Signal<Set<T>>;
    /** Underlying CDK {@link SelectionModel} for advanced use. */
    get selection(): SelectionModel<T>;
    /** Updates selection mode — single mode clears down to at most one selected row. */
    setMode(mode: AtomTableSelectionMode): void;
    /** Sets the optional maximum number of selectable rows (multiple mode only). */
    setMaxSelection(maxSelection: number | undefined): void;
    /** Marks a row value as intrinsically disabled (via `[atomDisabled]` on its row component). */
    registerDisabled(row: T): void;
    /** Removes a row value from the intrinsic disabled registry. */
    unregisterDisabled(row: T): void;
    /** Whether a row value is selected. */
    isSelected(row: T): boolean;
    /** Whether the selection limit has been reached. */
    isSelectionFull(): boolean;
    /** Whether a row can be selected (not at capacity unless already selected). */
    canSelect(row: T): boolean;
    /** Toggles selection for a row. Returns whether the selection changed. */
    toggle(row: T, disabled?: boolean): boolean;
    /** Selects a row when allowed. */
    select(row: T, disabled?: boolean): boolean;
    /** Clears a row from the selection. */
    deselect(row: T): void;
    /** Clears the current selection. */
    clear(): void;
    /** Whether every selectable row in the list is selected. */
    isAllSelected(rows: readonly T[], isDisabled?: (row: T) => boolean): boolean;
    /** Whether some but not all selectable rows are selected. */
    isIndeterminate(rows: readonly T[], isDisabled?: (row: T) => boolean): boolean;
    /** Selects or clears all selectable rows in the list. */
    masterToggle(rows: readonly T[], isDisabled?: (row: T) => boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTableSelectionController<any>, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AtomTableSelectionController<any>>;
}

/** Selection controller provided by {@link AtomTableComponent} when `atomSelectable` is enabled. */
declare const ATOM_TABLE_SELECTION: InjectionToken<AtomTableSelectionController<unknown>>;

/**
 * Sort container for atom-table.
 * Wraps Material {@link MatSort} with Atom DS selectors and signal inputs.
 *
 * Usage: `<table atom-table atomSort [dataSource]="dataSource">`
 */
declare class AtomSortDirective extends MatSort {
    readonly atomSortActive: _angular_core.InputSignal<string>;
    readonly atomSortStart: _angular_core.InputSignal<SortDirection>;
    readonly atomSortDirection: _angular_core.InputSignal<SortDirection>;
    readonly atomSortDisableClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly atomSortDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly atomSortChange: _angular_core.OutputRef<Sort>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSortDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSortDirective, "[atomSort]", ["atomSort"], { "atomSortActive": { "alias": "atomSortActive"; "required": false; "isSignal": true; }; "atomSortStart": { "alias": "atomSortStart"; "required": false; "isSignal": true; }; "atomSortDirection": { "alias": "atomSortDirection"; "required": false; "isSignal": true; }; "atomSortDisableClear": { "alias": "atomSortDisableClear"; "required": false; "isSignal": true; }; "atomSortDisabled": { "alias": "atomSortDisabled"; "required": false; "isSignal": true; }; }, { "atomSortChange": "atomSortChange"; }, never, never, true, never>;
}

/** Column definition for atom-table. */
declare class AtomColumnDefDirective extends CdkColumnDef {
    readonly atomColumnDef: _angular_core.InputSignal<string>;
    readonly stickyInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly stickyEndInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomColumnDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomColumnDefDirective, "[atomColumnDef]", never, { "atomColumnDef": { "alias": "atomColumnDef"; "required": true; "isSignal": true; }; "stickyInput": { "alias": "sticky"; "required": false; "isSignal": true; }; "stickyEndInput": { "alias": "stickyEnd"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** Header cell template definition. Usage: `*atomHeaderCellDef`. */
declare class AtomHeaderCellDefDirective extends CdkHeaderCellDef {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomHeaderCellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomHeaderCellDefDirective, "[atomHeaderCellDef]", never, {}, {}, never, never, true, never>;
}
/** Data cell template definition. Usage: `*atomCellDef="let row"`. */
declare class AtomCellDefDirective extends CdkCellDef {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomCellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomCellDefDirective, "[atomCellDef]", never, {}, {}, never, never, true, never>;
}
/** Header cell host. Applies DS styles to `<th atomHeaderCell>`. */
declare class AtomHeaderCellDirective extends CdkHeaderCell {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomHeaderCellDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomHeaderCellDirective, "th[atomHeaderCell]", never, {}, {}, never, never, true, never>;
}
/** Header row definition. Usage: `*atomHeaderRowDef="columns"`. */
declare class AtomHeaderRowDefDirective extends CdkHeaderRowDef implements OnChanges {
    readonly atomHeaderRowDef: _angular_core.InputSignal<Iterable<string>>;
    private _firstNgOnChanges;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomHeaderRowDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomHeaderRowDefDirective, "[atomHeaderRowDef]", never, { "atomHeaderRowDef": { "alias": "atomHeaderRowDef"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** Data row definition. Usage: `*atomRowDef="let row; columns: cols"`. */
declare class AtomRowDefDirective<T> extends CdkRowDef<T> implements OnChanges {
    readonly atomRowDefColumns: _angular_core.InputSignal<Iterable<string>>;
    readonly atomRowDefWhen: _angular_core.InputSignal<((index: number, rowData: T) => boolean) | undefined>;
    private _firstNgOnChanges;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomRowDefDirective<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomRowDefDirective<any>, "[atomRowDef]", never, { "atomRowDefColumns": { "alias": "atomRowDefColumns"; "required": true; "isSignal": true; }; "atomRowDefWhen": { "alias": "atomRowDefWhen"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** No-data row template. Usage: `*atomNoDataRow` or `<ng-template atomNoDataRow>`. */
declare class AtomNoDataRowDirective extends CdkNoDataRow {
    _cellSelector: string;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomNoDataRowDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomNoDataRowDirective, "ng-template[atomNoDataRow]", never, {}, {}, never, never, true, never>;
}

/** Single import entry for all atom-table building blocks. */
declare const ATOM_TABLE_IMPORTS: readonly [typeof AtomTableComponent, typeof AtomHeaderRowComponent, typeof AtomRowComponent, typeof AtomFooterRowComponent, typeof AtomColumnDefDirective, typeof AtomHeaderCellDefDirective, typeof AtomCellDefDirective, typeof AtomHeaderCellDirective, typeof AtomCellComponent, typeof AtomHeaderRowDefDirective, typeof AtomRowDefDirective, typeof AtomNoDataRowDirective, typeof AtomSortDirective, typeof AtomSortHeaderComponent, typeof AtomTableSelectionColumnComponent];

type AtomTableColumnType = 'text' | 'number' | 'currency' | 'date' | 'custom';
interface AtomTableColumn<T> {
    /** Unique column identifier. Forwarded to [atomColumnDef]. */
    columnName: string;
    /** Default header text. */
    columnLabel: string;
    /**
     * Determines the automatic formatter and implicit cell alignment
     * (text/date -> start; number/currency -> end).
     * @default 'text'
     */
    columnType?: AtomTableColumnType;
    /** Extracts the cell value from the row. Supports a function or a direct key path. */
    accessor: ((row: T) => unknown) | keyof T;
    /** Full cell override. Overrides the columnType formatter. */
    cellTpl?: TemplateRef<AtomCellContext<T>>;
    /** Header override. Overrides columnLabel. */
    headerTpl?: TemplateRef<void>;
    /** Enables [atomSortHeader] on the header cell. */
    sortable?: boolean;
    /**
     * Sets this column as the initial active sort when the table renders.
     * Only one column should define this. The column must also have `sortable: true`.
     * @default 'asc'
     */
    defaultSort?: 'asc' | 'desc';
    /** Pins the column to the left (forwarded to [atomColumnDef]). */
    sticky?: boolean;
    /** Pins the column to the right (forwarded to [atomColumnDef]). */
    stickyEnd?: boolean;
    /** CSS width hint applied to the column (e.g. '120px', '15%'). */
    width?: string;
    /** Format for DecimalPipe. Only applies to columnType: 'number'. @default '1.0-2' */
    numberFormat?: string;
    /** ISO 4217 currency code. Only applies to columnType: 'currency'. @default 'USD' */
    currencyCode?: string;
    /** Only applies to columnType: 'currency'. @default 'symbol' */
    currencyDisplay?: 'code' | 'symbol' | 'symbol-narrow' | 'name';
    /** Format for DatePipe. Only applies to columnType: 'date'. @default 'mediumDate' */
    dateFormat?: string;
    /** Locale override for number, currency, and date formatting. */
    locale?: string;
}
interface AtomCellContext<T> {
    /** Full row object. */
    $implicit: T;
    /** Result of accessor(row). */
    value: unknown;
    /** Row index on the current page. */
    index: number;
    /** Column configuration. */
    column: AtomTableColumn<T>;
}

declare class AtomTableBuilderComponent<T extends object> {
    /** Array of column configurations. */
    readonly columns: _angular_core.InputSignal<AtomTableColumn<T>[]>;
    /** Data source for the table. */
    readonly dataSource: _angular_core.InputSignal<AtomTableDataSource<T> | T[]>;
    /** TrackBy function for row rendering. Required to ensure stable DOM recycling. */
    readonly atomTrackBy: _angular_core.InputSignal<TrackByFunction<T>>;
    /** Enables row selection styling and events. */
    readonly selectable: _angular_core.InputSignal<boolean>;
    /** Whether multiple rows can be selected. Defaults to true. */
    readonly multiple: _angular_core.InputSignal<boolean>;
    /** Maximum number of rows that can be selected. */
    readonly maxSelection: _angular_core.InputSignal<number | undefined>;
    /** Emits when a row is clicked. */
    readonly rowClick: _angular_core.OutputEmitterRef<T>;
    /** Emits when the selection changes. */
    readonly selectionChange: _angular_core.OutputEmitterRef<readonly T[]>;
    /** The column marked with `defaultSort`, if any. */
    private readonly defaultSortColumn;
    /** Column name to pass as [atomSortActive] — empty string means no initial sort. */
    protected readonly initialSortActive: _angular_core.Signal<string>;
    /** Sort direction to pass as [atomSortDirection]. */
    protected readonly initialSortDirection: _angular_core.Signal<SortDirection>;
    /** Computed data source to ensure it's always an AtomTableDataSource. */
    protected readonly internalDataSource: _angular_core.Signal<AtomTableDataSource<T>>;
    /** Computed displayed columns. */
    protected readonly displayedColumns: _angular_core.Signal<string[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTableBuilderComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomTableBuilderComponent<any>, "atom-table-builder", never, { "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "dataSource": { "alias": "dataSource"; "required": true; "isSignal": true; }; "atomTrackBy": { "alias": "atomTrackBy"; "required": true; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "maxSelection": { "alias": "maxSelection"; "required": false; "isSignal": true; }; }, { "rowClick": "rowClick"; "selectionChange": "selectionChange"; }, never, ["[atomNoDataRow]"], true, never>;
}

declare class AtomTableAlignPipe implements PipeTransform {
    transform<T>(column: AtomTableColumn<T>, element: 'header-cell' | 'cell'): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTableAlignPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<AtomTableAlignPipe, "atomTableAlign", true>;
}

declare class AtomTableCellRenderPipe implements PipeTransform {
    private readonly decimalPipe;
    private readonly currencyPipe;
    private readonly datePipe;
    private readonly cellValuePipe;
    private readonly defaultLocale;
    transform<T>(row: T, column: AtomTableColumn<T>): string | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTableCellRenderPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<AtomTableCellRenderPipe, "atomTableCellRender", true>;
}

declare class AtomTableCellValuePipe implements PipeTransform {
    transform<T>(row: T, accessor: AtomTableColumn<T>['accessor']): unknown;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomTableCellValuePipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<AtomTableCellValuePipe, "atomTableCellValue", true>;
}

/** Single import entry for `atom-table-builder` and its cell-formatting pipes. */
declare const ATOM_TABLE_BUILDER_IMPORTS: readonly [typeof AtomTableBuilderComponent, typeof AtomTableCellRenderPipe, typeof AtomTableAlignPipe, typeof AtomTableCellValuePipe];

/**
 * Contract for `AtomDataLayoutIntl`.
 *
 * Extend to create a custom intl class and re-provide at module or component scope.
 * After mutating any field call `changes.next()` to notify mounted layouts.
 */
interface AtomDataLayoutIntlContract {
    emptyStateTitle: string;
    emptyStateDescription: string;
    emptyStateIcon: AtomIconSpec;
    noDataTitle: string;
    noDataDescription: string;
    noDataIcon: AtomIconSpec;
    errorTitle: string;
    errorDescription: string;
    errorIcon: AtomIconSpec;
    /** Notify mounted layouts that labels have changed. */
    readonly changes: Subject<void>;
}

/**
 * Internationalization service for `AtomDataLayoutComponent`.
 *
 * Owns every human-readable string rendered by the body fallback states
 * (empty, no-data, error). Mirrors the override ergonomics of `AtomPaginatorIntl`:
 * consumers extend the class, override fields, and re-provide at module or
 * component scope.
 *
 * Subclasses that mutate labels after construction MUST call `changes.next()`
 * so every mounted layout refreshes its visible labels in the next change-detection tick.
 */
declare class AtomDataLayoutIntl implements AtomDataLayoutIntlContract {
    /** Title shown in the body when `bodyState='empty'` and no template is projected. */
    emptyStateTitle: string;
    /** Supporting text shown in the body when `bodyState='empty'` and no template is projected. */
    emptyStateDescription: string;
    /** Icon shown in the body when `bodyState='empty'` and no template is projected. */
    emptyStateIcon: AtomIconSpec;
    /** Title shown in the body when `bodyState='no-data'` and no template is projected. */
    noDataTitle: string;
    /** Supporting text shown in the body when `bodyState='no-data'` and no template is projected. */
    noDataDescription: string;
    /** Icon shown in the body when `bodyState='no-data'` and no template is projected. */
    noDataIcon: AtomIconSpec;
    /** Title shown in the body when `bodyState='error'` and no template is projected. */
    errorTitle: string;
    /** Supporting text shown in the body when `bodyState='error'` and no template is projected. */
    errorDescription: string;
    /** Icon shown in the body when `bodyState='error'` and no template is projected. */
    errorIcon: AtomIconSpec;
    /**
     * Notifies mounted layouts that labels have changed and the DOM should be refreshed.
     * Call `changes.next()` after mutating any label field.
     */
    readonly changes: Subject<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDataLayoutIntl, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AtomDataLayoutIntl>;
}

type DataLayoutState = 'loading' | 'empty' | 'noData' | 'error';
/**
 * Apply to `<ng-template>` with a state selector to override the default overlay for a specific state.
 * Reduces boilerplate vs. four separate directivas (Loading/Empty/NoData/Error).
 *
 * ```html
 * <ng-template atomDataLayoutState="loading">
 *   <my-custom-loader />
 * </ng-template>
 *
 * <ng-template atomDataLayoutState="empty">
 *   <my-custom-empty-state />
 * </ng-template>
 * ```
 */
declare class AtomDataLayoutStateDirective {
    readonly atomDataLayoutState: _angular_core.InputSignal<DataLayoutState>;
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDataLayoutStateDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomDataLayoutStateDirective, "ng-template[atomDataLayoutState]", never, { "atomDataLayoutState": { "alias": "atomDataLayoutState"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Organismo contenedor que organiza una pantalla de datos en tres zonas verticales:
 * toolbar superior, área de cuerpo scrolleable con manejo de estados, y paginación inferior.
 *
 * ### Usage
 * ```html
 * <atom-data-layout [loading]="isLoading" [error]="hasError">
 *   <atom-toolbar>...</atom-toolbar>
 *
 *   <table atom-table [dataSource]="ds">
 *     <ng-container atomColumnDef="name">...</ng-container>
 *     ...
 *   </table>
 *
 *   <atom-pagination [length]="total" [pageSize]="10" />
 * </atom-data-layout>
 * ```
 *
 * ### Zones
 * - **Toolbar** — `<ng-content select="atom-toolbar">` — always visible.
 * - **Body** — content-switched based on state flags — scrollable on both axes.
 * - **Pagination** — `<ng-content select="atom-pagination">` — always visible, `border-top`.
 *
 * ### State priority (highest to lowest)
 * `loading` → `empty` → `no-data` → `error` → data (default when no flag is set).
 *
 * ### Empty state overrides
 * Project an `<ng-template atomDataLayoutState="empty">`,
 * `<ng-template atomDataLayoutState="noData">`, or
 * `<ng-template atomDataLayoutState="error">` to replace the `AtomDataLayoutIntl`
 * fallback for each state. The consumer controls precedence by deciding which
 * flags to activate.
 */
declare class AtomDataLayoutComponent implements AfterContentInit {
    protected readonly intl: AtomDataLayoutIntl;
    private readonly cdr;
    /** Shows the skeleton table and hides the projected table. Highest priority. */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    /** Hides the table and shows the empty-state fallback (or projected override). */
    readonly empty: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    /** Hides the table and shows the no-data fallback (or projected override). */
    readonly noData: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    /** Hides the table and shows the error fallback (or projected override). */
    readonly error: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    /** Number of rows in the internal skeleton table when `loading=true`. */
    readonly skeletonRows: _angular_core.InputSignalWithTransform<number, string | number>;
    /**
     * Track whether content children have been initialized (i.e., ngAfterContentInit has run).
     * Used to defer skeleton column rendering until column defs are available, avoiding
     * observable jank from 4 → N column repaints.
     */
    private readonly contentInitialized;
    private readonly columnDefs;
    private readonly tableBuilder;
    /**
     * Skeleton column list. Falls back to 4 columns if the real count is unavailable.
     * Only computes after content has been initialized to avoid jank from early
     * contentChildren snapshot (which is empty on first CD cycle before ngAfterContentInit).
     */
    protected readonly skeletonColumns: _angular_core.Signal<string[]>;
    protected readonly skeletonDataSource: _angular_core.Signal<number[]>;
    private readonly stateOverrides;
    /**
     * Query state overrides by name.
     */
    private getStateOverride;
    protected readonly loadingTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    protected readonly emptyTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    protected readonly noDataTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    protected readonly errorTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    /**
     * Compute active state once. Priority: loading → empty → no-data → error → data.
     * Both the [data-state] host attribute and the template overlay rendering
     * derive from this single source of truth.
     */
    protected readonly activeState: _angular_core.Signal<"loading" | "error" | "empty" | "no-data" | "data">;
    constructor();
    /**
     * Mark content as initialized after Angular has projected and initialized
     * the content children. This defers skeleton column rendering until
     * contentChildren(AtomColumnDefDirective) has a real value.
     */
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomDataLayoutComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomDataLayoutComponent, "atom-data-layout", never, { "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "empty": { "alias": "empty"; "required": false; "isSignal": true; }; "noData": { "alias": "noData"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "skeletonRows": { "alias": "skeletonRows"; "required": false; "isSignal": true; }; }, {}, ["columnDefs", "tableBuilder", "stateOverrides"], ["atom-toolbar", "table[atom-table], table[atomTable], atom-table-builder", "atom-pagination"], true, never>;
}
declare const ATOM_DATA_LAYOUT_IMPORTS: readonly [typeof AtomDataLayoutComponent, typeof AtomDataLayoutStateDirective];

declare class AtomSectionHeadingBackDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSectionHeadingBackDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSectionHeadingBackDirective, "button[atom-icon-button][atomSectionHeadingBack], a[atom-icon-button][atomSectionHeadingBack]", never, {}, {}, never, never, true, never>;
}
declare class AtomSectionHeadingTitleDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSectionHeadingTitleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSectionHeadingTitleDirective, "[atomSectionHeadingTitle]", never, {}, {}, never, never, true, never>;
}
declare class AtomSectionHeadingDescriptionDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSectionHeadingDescriptionDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomSectionHeadingDescriptionDirective, "[atomSectionHeadingDescription]", never, {}, {}, never, never, true, never>;
}

type AtomSectionHeadingLevel = 'h1' | 'h2' | 'h3';
declare class AtomSectionHeadingComponent {
    readonly heading: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string | undefined>;
    readonly backButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly backFallbackUrl: _angular_core.InputSignalWithTransform<string | undefined, string | undefined>;
    readonly backAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly headingLevel: _angular_core.InputSignal<AtomSectionHeadingLevel>;
    readonly back: _angular_core.OutputEmitterRef<void>;
    private readonly backLabel;
    protected readonly hasBackSlot: _angular_core.Signal<AtomSectionHeadingBackDirective | undefined>;
    protected readonly hasTitleSlot: _angular_core.Signal<AtomSectionHeadingTitleDirective | undefined>;
    protected readonly hasDescriptionSlot: _angular_core.Signal<AtomSectionHeadingDescriptionDirective | undefined>;
    protected readonly resolvedBackAriaLabel: _angular_core.Signal<string>;
    protected readonly arrowLeftIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomSectionHeadingComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomSectionHeadingComponent, "atom-section-heading", never, { "heading": { "alias": "heading"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "backButton": { "alias": "backButton"; "required": false; "isSignal": true; }; "backFallbackUrl": { "alias": "backFallbackUrl"; "required": false; "isSignal": true; }; "backAriaLabel": { "alias": "backAriaLabel"; "required": false; "isSignal": true; }; "headingLevel": { "alias": "headingLevel"; "required": false; "isSignal": true; }; }, { "back": "back"; }, ["hasBackSlot", "hasTitleSlot", "hasDescriptionSlot"], ["button[atom-icon-button][atomSectionHeadingBack], a[atom-icon-button][atomSectionHeadingBack]", "[atomSectionHeadingTitle]", "[atomSectionHeadingDescription]", "*"], true, never>;
}

declare const ATOM_SECTION_HEADING_BACK_LABEL: InjectionToken<string>;

declare class AtomBulkActionBarDismissDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomBulkActionBarDismissDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AtomBulkActionBarDismissDirective, "[atomBulkActionBarDismiss]", never, {}, {}, never, never, true, never>;
}

declare class AtomBulkActionBarComponent {
    private readonly intl;
    protected readonly closeIcon: _fortawesome_fontawesome_common_types.IconDefinition;
    readonly count: _angular_core.InputSignal<number>;
    readonly countLabel: _angular_core.InputSignal<((count: number) => string) | undefined>;
    readonly dismissed: _angular_core.OutputEmitterRef<void>;
    protected readonly intlChanges: _angular_core.Signal<void | null>;
    protected readonly resolvedLabel: _angular_core.Signal<string>;
    protected readonly dismissOverride: _angular_core.Signal<AtomBulkActionBarDismissDirective | undefined>;
    protected readonly hasDismissOverride: _angular_core.Signal<boolean>;
    /** Accessible name of the built-in X button (i18n via AtomBulkActionBarIntl). */
    protected get dismissLabel(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomBulkActionBarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomBulkActionBarComponent, "atom-bulk-action-bar", never, { "count": { "alias": "count"; "required": true; "isSignal": true; }; "countLabel": { "alias": "countLabel"; "required": false; "isSignal": true; }; }, { "dismissed": "dismissed"; }, ["dismissOverride"], ["button[atom-button]:not([atomBulkActionBarDismiss]), button[atom-icon-button]:not([atomBulkActionBarDismiss])", "[atomBulkActionBarDismiss]"], true, never>;
}

declare class AtomBulkActionBarIntl {
    readonly changes: Subject<void>;
    getSelectedLabel: (count: number) => string;
    dismissLabel: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomBulkActionBarIntl, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AtomBulkActionBarIntl>;
}

/**
 * Shared size values accepted by design-system components that participate
 * in the context-aware sizing system.
 */
type AtomComponentSize = 's' | 'm';
/**
 * DI token for propagating a size context from a container component to its
 * slotted children **without coupling children to the specific container**.
 *
 * Any container component (e.g. `atom-toolbar`) can provide this token.
 * Any child component (e.g. `atom-search-input`, `atom-button`) can inject it
 * as an optional fallback — the child remains completely unaware of which
 * ancestor is providing the size.
 *
 * Resolution order inside each child:
 * 1. Explicit `[size]` binding on the child → highest priority
 * 2. `ATOM_COMPONENT_SIZE` from the nearest ancestor that provides it
 * 3. The child's own default size
 *
 * ### Providing
 * ```typescript
 * providers: [{
 *   provide: ATOM_COMPONENT_SIZE,
 *   useFactory: () => inject(MyContainerComponent).size,
 * }]
 * ```
 *
 * ### Consuming
 * ```typescript
 * private readonly contextSize = inject(ATOM_COMPONENT_SIZE, { optional: true });
 * readonly effectiveSize = computed(() => this.size() ?? this.contextSize?.() ?? 'm');
 * ```
 */
declare const ATOM_COMPONENT_SIZE: InjectionToken<Signal<AtomComponentSize>>;

/**
 * `<atom-toolbar>` — compositional, slot-based action bar (HU-031).
 *
 * No zone-activation inputs: projecting a component into a slot is what
 * activates that zone, and empty slots collapse via CSS `:empty`. One
 * never-wrapping row of two zones — a flexible **Tools** zone (search → filter →
 * nested-actions) and an **Actions** zone pinned right. The Tools zone bounds
 * the projected filter's chip rail so it scrolls internally on overflow.
 *
 * Slots (each `ng-content` accepts only its selectors):
 *   - search        — `<atom-search-input>`
 *   - filter        — `<atom-filter>`
 *   - nested-actions — `button[atom-button|atom-icon-button][atomToolbarLeft]`
 *   - right-actions  — `button[atom-button|atom-icon-button][atomToolbarRight]`
 *
 * `atomToolbarLeft` and `atomToolbarRight` select the target zone. Left actions
 * only accept `secondary` and `tertiary` variants; `primary` or untyped buttons
 * are ignored. Right actions accept any variant and are intended for the primary
 * CTA. Buttons without a zone marker are not projected.
 *
 * A11y: `role="group"` (+ optional `ariaLabel`), NOT `role="toolbar"` — the
 * projected `atom-filter` is already a toolbar, so nesting one here would be
 * invalid (ARIA 1.2) and fight its focus management.
 */
declare class AtomToolbarComponent {
    /**
     * Controls the visual density of the toolbar and is propagated to all
     * slotted children (`atom-search-input`, `atom-button`, `atom-icon-button`)
     * via the `ATOM_COMPONENT_SIZE` injection token.
     *
     * Children only inherit the toolbar size when they have **no explicit**
     * `[size]` binding. An explicit binding always wins.
     *
     * - `'m'` (default) — standard density, suitable for most screens.
     * - `'s'` — compact density, suitable for dense data views.
     */
    readonly size: _angular_core.InputSignal<AtomComponentSize>;
    /**
     * Accessible name for the toolbar group. Optional — when unset, the host
     * carries no `aria-label` (the consumer may instead label it via
     * `aria-labelledby` on the host element). Provide a localized string; the DS
     * does not hardcode a default to avoid shipping an untranslated label.
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AtomToolbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AtomToolbarComponent, "atom-toolbar", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, ["atom-search-input", "atom-filter", "button[atom-button='secondary'][atomToolbarLeft], button[atom-icon-button='secondary'][atomToolbarLeft],button[atom-button='tertiary'][atomToolbarLeft], button[atom-icon-button='tertiary'][atomToolbarLeft]", "button[atom-button][atomToolbarRight], button[atom-icon-button][atomToolbarRight]"], true, never>;
}

export { ATOM_COMPONENT_SIZE, ATOM_DARK_MODE_CLASS_DEFAULT, ATOM_DATA_LAYOUT_IMPORTS, ATOM_DIALOG_CLOSE_ARIA_LABEL, ATOM_DIALOG_CTA_ARIA_LABEL, ATOM_DIALOG_DATA, ATOM_FILTER_CATEGORY_REGISTRATION, ATOM_FILTER_PANEL_CONFIG, ATOM_FILTER_PANEL_DEFAULT_CONFIG, ATOM_FILTER_ROW_CONTEXT, ATOM_FILTER_ROW_DEFAULT_LABELS, ATOM_FILTER_ROW_LABELS, ATOM_FORM_FIELD_IMPORTS, ATOM_ICONS_SUBSET, ATOM_LIST_ITEM_DISCLOSURE, ATOM_LIST_ITEM_ROLE, ATOM_LIST_ITEM_SELECTABLE, ATOM_PLAIN_TOOLTIP_DATA, ATOM_RADIO_GROUP, ATOM_RICH_TOOLTIP_DATA, ATOM_SEARCH_INPUT_ARIA_LABEL, ATOM_SEARCH_INPUT_CLEAR_ARIA_LABEL, ATOM_SEARCH_INPUT_COLLAPSED_ARIA_LABEL, ATOM_SEARCH_INPUT_PLACEHOLDER, ATOM_SEARCH_INPUT_SHORTCUT_KEY, ATOM_SECTION_HEADING_BACK_LABEL, ATOM_SEGMENT_CONTEXT, ATOM_SELECT_INPUT_STATES, ATOM_SELECT_PANEL_CONFIG, ATOM_SELECT_PANEL_DEFAULT_CONFIG, ATOM_SNACKBAR_DURATION, ATOM_SORT_HEADER_SORT_LABEL, ATOM_TABLE_BUILDER_IMPORTS, ATOM_TABLE_IMPORTS, ATOM_TABLE_SELECTION, ATOM_TABLE_SELECTION_COLUMN, ATOM_TEXT_FIELD_VISUAL_STATES, ATOM_TOOLTIP_MOTION_OVERRIDES, AtomAvatarComponent, AtomAvatarIconDirective, AtomAvatarImageDirective, AtomAvatarLabelGroupComponent, AtomAvatarOutnameDirective, AtomAvatarStatusDirective, AtomBadgeDirective, AtomBulkActionBarComponent, AtomBulkActionBarDismissDirective, AtomBulkActionBarIntl, AtomButtonComponent, AtomButtonIconDirective, AtomButtonLabelHostDirective, AtomCardBodyComponent, AtomCardBodyHeadlineDirective, AtomCardBodySubheadDirective, AtomCardBodyTextDirective, AtomCardComponent, AtomCardFooterComponent, AtomCardFooterDynamicDirective, AtomCardHeaderComponent, AtomCardHeaderEndDirective, AtomCardHeaderStartDirective, AtomCardHeaderTextDirective, AtomCardMediaComponent, AtomCardMediaContentDirective, AtomCardTextDirective, AtomCellComponent, AtomCellDefDirective, AtomChipComponent, AtomChipIconDirective, AtomColumnDefDirective, AtomConfirmDialogComponent, AtomDataLayoutComponent, AtomDataLayoutIntl, AtomDataLayoutStateDirective, AtomDescriptionDirective, AtomDialogBodyComponent, AtomDialogCloseDirective, AtomDialogFooterComponent, AtomDialogFooterStartDirective, AtomDialogHeaderComponent, AtomDialogHeaderCtaDirective, AtomDialogHeaderIconDirective, AtomDialogHeaderSubtitleDirective, AtomDialogHeaderTitleDirective, AtomDialogHeaderTitleRowDirective, AtomDialogService, AtomDialogShellComponent, AtomDisabledHostDirective, AtomDividerComponent, AtomDropdownMenuComponent, AtomDropdownTitleDirective, AtomDropdownTriggerDirective, AtomDualIconSlotHostDirective, AtomEmptyStateActionDirective, AtomEmptyStateComponent, AtomEmptyStateHeadingDirective, AtomEmptyStateResultTextDirective, AtomEmptyStateSubGroupDirective, AtomEmptyStateSupportingTextDirective, AtomEmptyStateVisualDirective, AtomFilterCategoryDirective, AtomFilterChipComponent, AtomFilterChipLabelsDirective, AtomFilterComponent, AtomFilterPanelComponent, AtomFilterRowComponent, AtomFilterTriggerComponent, AtomFooterRowComponent, AtomFormFieldComponent, AtomFormFieldControl, AtomFormFieldCounterComponent, AtomFormFieldLabelDirective, AtomFormFieldRootDirective, AtomFormFieldSupportDirective, AtomFormFieldValidationDirective, AtomHeaderCellDefDirective, AtomHeaderCellDirective, AtomHeaderRowComponent, AtomHeaderRowDefDirective, AtomIconButtonComponent, AtomLabelDirective, AtomLabelHostDirective, AtomLeadingIconSlotHostDirective, AtomLinkButtonComponent, AtomListItemComponent, AtomLoadingHostDirective, AtomNoDataRowDirective, AtomOptionalAriaLabelHostDirective, AtomPaginationComponent, AtomPaginatorIntl, AtomPlainTooltipComponent, AtomRadioButtonComponent, AtomRadioGroupComponent, AtomRequiredAriaLabelHostDirective, AtomRichTooltipComponent, AtomRichTooltipDirective, AtomRowComponent, AtomRowDefDirective, AtomSearchInputComponent, AtomSearchShortcutManager, AtomSectionHeadingBackDirective, AtomSectionHeadingComponent, AtomSectionHeadingDescriptionDirective, AtomSectionHeadingTitleDirective, AtomSegmentComponent, AtomSegmentControlComponent, AtomSelectAllDirective, AtomSelectFooterDirective, AtomSelectInputComponent, AtomSelectLoadingCaptionDirective, AtomSelectPanelComponent, AtomSelectSearchDirective, AtomSelectTitleDirective, AtomSelectValueDirective, AtomSelectVirtualItemDirective, AtomSelectableControlDirective, AtomSelectionControlLabelComponent, AtomSingleIconSlotHostDirective, AtomSkeletonComponent, AtomSkeletonDirective, AtomSnackbarActionDirective, AtomSnackbarComponent, AtomSnackbarIconDirective, AtomSnackbarRef, AtomSnackbarService, AtomSolidButtonDirective, AtomSortDirective, AtomSortHeaderComponent, AtomSpinnerComponent, AtomTableAlignPipe, AtomTableBuilderComponent, AtomTableCellRenderPipe, AtomTableCellValuePipe, AtomTableComponent, AtomTableDataSource, AtomTableSelectionColumnComponent, AtomTableSelectionController, AtomTagComponent, AtomTagLeadingDirective, AtomTextFieldComponent, AtomTextFieldInputDirective, AtomTextFieldLeadingDirective, AtomTextFieldTrailingDirective, AtomToggleComponent, AtomToolbarComponent, AtomTooltipDirective, AtomTooltipTriggerDirective, CheckboxComponent, OSDetectorService, atomSelectInputPreviewClasses, atomTextFieldPreviewClasses, prependAtomTableSelectionColumn, provideDesignSystemIcons };
export type { AtomAvatarLabelGroupSize, AtomAvatarShape, AtomAvatarSize, AtomAvatarStatus, AtomAvatarType, AtomBadgePosition, AtomBadgeState, AtomBadgeType, AtomButtonColor, AtomButtonIconPosition, AtomButtonSize, AtomButtonType, AtomCardFooterVariant, AtomCardMediaRatio, AtomCardPadding, AtomCellContext, AtomCheckboxChange, AtomCheckboxSize, AtomChipSize, AtomChipType, AtomComponentSize, AtomConfirmDialogData, AtomConfirmDialogResult, AtomDataLayoutIntlContract, AtomDialogCloseEvent, AtomDialogCloseReason, AtomDialogConfig, AtomDialogFooterMode, AtomDialogHeaderAlign, AtomDividerOrientation, AtomDropdownPanel, AtomEmptyStateSize, AtomFilterPanelConfig, AtomFilterRowContext, AtomFilterRowLabels, AtomFilterRowSize, AtomFormFieldSize, AtomIconSpec, AtomLinkButtonSize, AtomListItemRole, AtomPageEvent, AtomPlainTooltipData, AtomRadioButtonSize, AtomRadioChange, AtomRadioGroupApi, AtomRichTooltipData, AtomSearchShortcutRegisterOptions, AtomSearchShortcutTarget, AtomSectionHeadingLevel, AtomSegmentContext, AtomSegmentMode, AtomSegmentSize, AtomSelectCompareWith, AtomSelectInputState, AtomSelectPanelConfig, AtomSelectVirtualItemContext, AtomSelectionControlSize, AtomSnackbarConfig, AtomSnackbarIconType, AtomSpinnerSize, AtomTableColumn, AtomTableColumnType, AtomTableSelectionMode, AtomTagIntent, AtomTagLeading, AtomTagSize, AtomTagVariant, AtomTextFieldInputType, AtomTextFieldSize, AtomTextFieldValidationKind, AtomTextFieldVisualState, AtomToggleChange, AtomTooltipMotionOverrides, CategoryActivatedDetail, CategoryClearedDetail, FilterCategoryRegistration, FilterPanelRegisteredPanel, SkeletonAnimation, SkeletonVariant, TooltipPlacement };
