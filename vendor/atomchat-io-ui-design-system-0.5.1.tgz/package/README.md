# @atomchat-io/ui-design-system

Angular **standalone** UI components, styles, and icon wiring for Atom products. Built for **Angular 20+** with signals-friendly APIs where applicable.

## What’s included

- **Components** (non-exhaustive; see your installed version’s `public-api` / main entry):
  - **Button** — sizes, variants, loading state, icon slots.
  - **Toggle** — switch control with size variants and state coverage aligned with the selection-control pattern.
  - **Checkbox** and **radio** patterns — including **radio group** APIs.
  - **Selection control labels** — directives and helpers for accessible form controls.
  - **Card suite** — `atom-card` shell plus header/body/media/footer sub-components and text/dynamic directives.
  - **Divider** — `hr[atom-divider]` host-element API with horizontal/vertical orientation and accessibility metadata.
  - **Dialog suite** — shell/header/body/footer components, close directive, close/data tokens, and typed dialog service.
  - **Tooltip suite** — `[atomTooltip]` for a single-line-to-six-line Plain label (`role="tooltip"`) and `[atomRichTooltip]` for a non-modal popover with subhead / supporting text / optional action button (`role="dialog"`, `aria-modal="false"`). Rich supports a `TemplateRef` content slot via `[extraContent]` for arbitrary projected layouts. Logical placements (`top | end | bottom | start`) resolve against `dir` and auto-flip on viewport overflow. Single-active-at-a-time across both variants. Lifecycle outputs `(opened)` / `(closed)`. See [`specs/001-tooltip-component/quickstart.md`](../../specs/001-tooltip-component/quickstart.md) for usage examples.
- **Icons** — `provideDesignSystemIcons` and curated icon subsets for tree-shaking with Font Awesome Pro (see peers below).
- **Styles** — SCSS entry points for design tokens as CSS variables, utility classes, effects utilities (`elevation-*`, `blur-surface-*`), and optional **Angular Material** theme bridges (`atom-theme`, Material 3 radio helpers, etc.). Details of class names and variables are documented in the `src/styles` assets shipped with the package.

Install **`@atomchat-io/ui-tokens`** alongside this package; components and themes expect the same token system.

**Compatibility note:** this package currently expects **`@atomchat-io/ui-tokens` `^0.2.1`** as a peer dependency.

## Installation

Configure access to the `@atomchat-io` scope, then:

```bash
npm install @atomchat-io/ui-tokens @atomchat-io/ui-design-system
```

Align versions between these packages per your internal release notes or lockfile.

### Peer dependencies

`@atomchat-io/ui-design-system` expects compatible versions of **Angular** (`@angular/core`, `@angular/forms`, **Angular Material** and **CDK**), and **Font Awesome** packages (`@fortawesome/angular-fontawesome`, `@fortawesome/fontawesome-svg-core`, and the icon packs you use). Check the `peerDependencies` field in this package’s `package.json` for exact ranges before upgrading an app.

## Using components

Import symbols from the package entry (path may vary slightly by bundler):

```typescript
import { AtomButtonComponent, provideDesignSystemIcons } from '@atomchat-io/ui-design-system';
import { bootstrapApplication } from '@angular/platform-browser';

bootstrapApplication(AppComponent, {
  providers: [provideDesignSystemIcons()],
});
```

Register only the components you need in your standalone `imports` arrays. Refer to Storybook or internal docs for props and accessibility notes for each component.

## Styles, fonts, and Angular assets

### Fonts: why the host app must expose static files

The design system emits **`@font-face`** rules that point at URLs such as **`/assets/fonts/inter/...`**. The **browser** requests those URLs at runtime; the npm package does not bundle fonts into your JS bundle. You therefore need **whatever your stack uses** (Angular **`assets`**, static hosting, CDN) to **serve the font files** at the same path you configure.

The files ship inside **`node_modules/@atomchat-io/ui-design-system/src/assets/fonts/inter`**. Typical Angular **`assets`** entries only **copy** those files into the build output so the URLs resolve — this is normal for any `@font-face` URL, not a quirk of this library.

**Option A — only Inter** (matches default **`$font-base-path`** `/assets/fonts/inter`):

```json
{
  "glob": "**/*",
  "input": "node_modules/@atomchat-io/ui-design-system/src/assets/fonts/inter",
  "output": "/assets/fonts/inter"
}
```

**Option B — entire `src/assets`** from the package:

```json
{
  "glob": "**/*",
  "input": "node_modules/@atomchat-io/ui-design-system/src/assets",
  "output": "/assets"
}
```

In **Nx**, add these under the app `build` target `options.assets`. If fonts are hosted elsewhere, set **`$font-base-path`** in config to that base URL instead.

### SCSS configuration (`styles/scss/_config.scss`)

Import **`config` first** (with `with (...)` overrides), then a single theme entry (`_tokens`, `_index`, `atom-theme`, or `atom-theme-m3`).

| Variable | Default | Purpose |
| -------- | ------- | ------- |
| **`$atom-prefix`** | `'atom-'` | Prefix for utility classes (e.g. `.atom-color-neutral-500`). |
| **`$atom-dark-mode-class`** | `null` | Class **name** (no `.`) for dark semantic tokens. If `null`, it becomes **`#{$atom-prefix}dark-mode`** (e.g. **`atom-dark-mode`**). Set explicitly (e.g. `'my-theme-dark'`) to override the whole name. |
| **`$use-important`** | `true` | Spacing utilities: whether to emit `!important`. |
| **`$font-base-path`** | `'/assets/fonts/inter'` | Base URL for `@font-face` `url(...)`; must match where your app serves font files. |

**Dark mode in TypeScript:** with defaults, use **`ATOM_DARK_MODE_CLASS_DEFAULT`** from **`@atomchat-io/ui-design-system`** when adding/removing the class on `document.body`. If you override **`$atom-prefix`** or **`$atom-dark-mode-class`** in SCSS, use the **same** string in code (the compiler and runtime are not linked automatically).

### Choosing a themed SCSS entry point

Import **one** primary entry from `@atomchat-io/ui-design-system/styles/scss/...` in global styles (after `config` if you override).

| Entry file | What it includes | Use when |
| ---------- | ---------------- | -------- |
| **`_tokens.scss`** | CSS variables (primitives + semantic), `@font-face`. **No** utility classes, **no** Angular Material. | Tokens only; you bring your own classes. |
| **`_index.scss`** | Tokens + utilities + semantic theme + fonts. **No** Angular Material. | No Material styles from this entry. |
| **`atom-theme.scss`** | Same as `_index.scss` **plus** Material **M2**-style radio, checkbox, typography. | **Default** for Angular + Material. |
| **`atom-theme-m3.scss`** | Same as `atom-theme.scss` with **M3** radio/checkbox helpers. | Opt-in M3 alignment for those controls. |

Semantic light/dark: use one of the entries above, then toggle the dark-mode class on the root (default **`.atom-dark-mode`**) — see **`src/styles/README.md`** for token names.

### Imports (published `exports`)

```scss
@use '@atomchat-io/ui-design-system/styles/scss/config' with (
  $atom-prefix: 'atom-',
  $font-base-path: '/assets/fonts/inter'
);
@use '@atomchat-io/ui-design-system/styles/scss/atom-theme';
```

Full variable and utility reference: **`src/styles/README.md`** in the published package.

## VS Code

Teams using the Atom workspace often rely on the **Atom Design Tokens** extension for CSS variable hints and color previews when editing templates and styles.

## Changelog

See `CHANGELOG.md` in the published package for release notes.
