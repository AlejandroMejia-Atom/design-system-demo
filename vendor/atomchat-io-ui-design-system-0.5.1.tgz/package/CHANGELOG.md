# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.5.1] - 2026-06-09

### Fixed (0.5.1)

- **Public API — table** — export `AtomSortDirective`, `AtomTableSelectionColumnComponent`, and related selection helpers (`AtomTableSelectionController`, `ATOM_TABLE_SELECTION`, `ATOM_TABLE_SELECTION_COLUMN`, `prependAtomTableSelectionColumn`, `AtomTableSelectionMode`) from `@atomchat-io/ui-design-system`. `ATOM_TABLE_IMPORTS` already referenced these symbols in the compiled bundle, but they were missing from the package entry-point `export { … }`, which caused Angular NG3004 in downstream apps (`Unable to import directive AtomSortDirective` / `component AtomTableSelectionColumnComponent`). Consumers can remove `postinstall` patches that manually edited `index.d.ts` or FESM.

## [0.5.0] - 2026-06-08

### Added (0.5.0)


- **`atom-filter-panel`** — two-column selection panel for filter flows. The left column lists filter categories; the right shows the matching `atom-select-panel` for the active one. Add `atomFilterCategory` to each `atom-list-item` and the panel auto-registers them — no manual wiring. Exposes `activateCategory()`, `clear()`, and `clearAll()` methods, plus `selectedCount` and `totalCount` signals. Keyboard navigable, fully ARIA-labelled, and localizable via `AtomFilterPanelIntl`. Works out of the box with `[atomDropdownTriggerFor]`.

- **`atom-filter`** — top-level filtering organism that orchestrates `atom-filter-row` and `atom-filter-panel`. Place a `button[atom-filter-trigger]` inside it: the organism handles open/close, generates applied-filter chips per category, and emits `opened`, `closed`, `allCleared`, and `categoryCleared`. Set `[showChips]="false"` for a compact trigger-and-badge layout. **Categories must be declared statically** — `@for` / `@if` in the panel slot is not supported.

- **Filter Chips (`atom-filter-row`, `atom-filter-chip`, `AtomFilterChipLabelsDirective`)** — display and manage applied filters in a horizontal scrollable chip list. Each chip shows up to 3 selected values inline; more appear as a `+N` badge. Includes a trigger button with auto-badge and an optional "Clear all" button. Arrow-key navigation between chips, 5 sizes (`xs`–`xl`), and localizable via `ATOM_FILTER_ROW_CLEAR_LABEL` / `ATOM_FILTER_ROW_ARIA_LABEL`.

- **`atom-snackbar`** — programmatic toast notifications via `AtomSnackbarService`. Four semantic variants (`info`, `success`, `warning`, `error`) with an optional action button. Toasts stack from the bottom; rapid calls stagger to avoid visual jumps. Includes enter/exit animations that respect `prefers-reduced-motion`. The headline and body use `<h6>` / `<p>` for correct accessibility semantics.

- **`atom-toolbar`** — horizontal action bar with `primary`, `secondary`, and `tertiary` button slots. Inherits size automatically from a parent `atom-data-layout`; defaults to `s` when used standalone. Only `secondary` and `tertiary` buttons are permitted in the `nested-actions` slot.

- **`atom-data-layout`** — full-page data management organism that composes a toolbar, table, and paginator into a single container. Declare `[atomDataLayoutState]` to switch between `loading`, `empty`, `no-data`, `error`, and `populated` body states — no `@if` chains required. The table header is always sticky inside this container.

- **`atom-table`** — production-ready CDK data table:
  - **Row selection** — checkbox column with master-toggle, per-row disable support, and an `atomSelectionChange` output.
  - **Sorting** — `[atomSortHeader]` column directive; re-clicking cycles through ascending, descending, and unsorted.
  - **Data source** — `AtomTableDataSource<T>` bridges to Angular Material's paginator and keeps page state in sync automatically.
  - **Cells** — `AtomCellComponent` handles text overflow with line clamping, and aligns rows that mix text, buttons, and inputs.
  - Always sticky inside `atom-data-layout`.

- **`atom-pagination`** — navigation bar with previous/next buttons, a page-range selector, and an optional page-size picker. All controls are disabled when `length = 0`. Warns in dev mode if `pageSize` is not listed in `pageSizeOptions`. Fully localizable via `AtomPaginationIntl`.

- **`atom-section-heading`** — page-section title bar with an optional back button. Title truncates at 2 lines on mobile; description at 3. Both accept slot directives (`[atomSectionHeadingTitle]`, `[atomSectionHeadingDescription]`) or plain string inputs. The back button is a real `<button>` element and emits `backClick`.

- **`atom-bulk-action-bar`** — contextual action bar for row-selection flows. Shows a selected-item count (localizable via `AtomBulkActionBarIntl`) and an action slot for batch operation buttons. Announced to screen readers via an ARIA live region.

- **`atom-skeleton`** — loading placeholder primitives:
  - `atom-skeleton` — standalone shimmer block, configurable in width, height, and shape.
  - `[atomSkeleton]` directive — overlays a shimmer on any host element while `[atomSkeleton]="true"`, without collapsing the layout.

### Changed (0.5.0)

- **`atom-select-panel` — takes ownership of selection state (HU-029B)** — the panel now manages selection internally, removing the need for external state in filter flows. It auto-registers with `atom-filter-panel` and exposes `selectedCount`, `selectedLabels`, `totalCount`, and `getSelectedValues()` for chip labels and counters.

  New capabilities added to the panel:
  - **Array mode** — bind `[items]`, `labelKey`, and `valueKey` to render a list declaratively. Replacing the array preserves existing selections for matching value keys.
  - **`atomSelectSearch` host directive** — adds filtering. In array mode it filters the rendered list; in projection mode it shows/hides projected items. 175 ms debounce with a per-keystroke `searchValueChange` event.
  - **`atomSelectAll` host directive** — exposes `allSelected` / `indeterminate` signals and a `toggle()` method. Applies batch selection in a single operation regardless of list size.
  - `ATOM_SELECT_PANEL_CONFIG` gains `selectAllLabel` (default `'Select all'`).

  > **Breaking change:** The `searchChange` output is removed. Replace any `(searchChange)` listener with `atom-select-panel[atomSelectSearch]` — the directive now owns the filter logic. (IV-979)

- **`atom-list-item` — `selectedBrand` input** — set `[selectedBrand]="true"` to show a leading check icon and apply brand-tint styling to the row. Designed for items that represent an active filter category or an applied selection. Powered by new `--list-item-selected-brand-*` CSS custom properties.

- **`AtomDropdownTriggerDirective` — `atomDropdownPreserveContent` input** — set to `true` to keep the panel's embedded view alive across open/close cycles, preserving any internal state (e.g. selections). Default is `false`; all existing consumers are unaffected. `AtomDropdownPanelRole` now accepts `'dialog'`.

### Fixed (0.5.0)

- **`atom-select-panel`** — the "Clear selection" footer is now hidden when no items are selected; replacing the items array no longer drops valid selections; overlay z-index overlap in Docs mode resolved.
- **`atom-select-input`** — the chevron stays vertically centered in both open and closed states; the default panel footer is correctly hidden when `[hideClearFooter]="true"`; a gap is now applied between the trigger and the floating panel.
- **`atom-tooltip`** — the Rich tooltip no longer closes when the pointer moves from the trigger into the panel.

## [0.4.1] - 2026-05-28

### Changed (0.4.1)

- **Dialog theme tokens** — `atom-dialog` backdrop and panel styles now align with semantic tokens from `@atomchat-io/ui-tokens`:
  - `--dialog-backdrop-bg` maps to `--bg-overlay-primary` (replaces compiled dark blur `surface-subtle-bg`).
  - `--dialog-backdrop-blur` uses `calc(var(--effects-blur-surface-subtle) * 0.5)` for the Figma→CSS blur conversion at consumption time.
  - `--dialog-shadow` maps to `--effects-shadows-elevation-modal`; applied on `.atom-dialog-panel` via `box-shadow`.

| Commit    | Detail                                                                                 |
| --------- | -------------------------------------------------------------------------------------- |
| `37f1989` | Updated dialog backdrop, blur, and elevation shadow to semantic CSS custom properties. |

## [0.4.0] - 2026-05-25

### Added (0.4.0)

- **Plain & Rich Tooltip** — two new directives for contextual help:
  - `[atomTooltip]` — simple 1-to-6-line label on hover or keyboard focus. Supports four placements (`top | end | bottom | start`, default `top`) with automatic viewport-collision flipping.
  - `[atomRichTooltip]` — richer popover with subhead, supporting text, and an optional action button. The cursor can move freely from trigger into the panel without the tooltip closing. The action button emits `actionClick` and closes the tooltip on activation. Supports a custom `extraContent` template slot for fully bespoke content.
  - Both dismiss on blur or Escape, enforce one visible tooltip at a time, emit `opened` / `closed` lifecycle outputs, and expose a `--tooltip-*` CSS custom property layer for per-app theming without forking the components.

- **`atom-segment-control` + `atom-segment`** — tab-like toggle groups (HU-017). Five sizes (`xs`–`xl`), two modes: `label` and `icon`. Full keyboard navigation (←/→, RTL, skip-disabled), `ControlValueAccessor` for Reactive and Template-driven Forms, and Light/Dark mode out of the box. Icon mode requires an `ariaLabel` per segment (dev-mode warning if omitted).

- **`atom-text-field`** — standalone text input field. Five sizes (`xs`–`xl`), nine visual states driven by CSS pseudo-classes — no state inputs needed on the component API. Includes a character counter, support message slot, and error/success validation slots. Works with Reactive and Template-driven Forms; independent of `MatFormField`. Supported input types: `text`, `url`, `tel`, `number`, `email`, `password`, `hidden`, `search`.
  - **Text Area mode** — project `<textarea atomTextFieldInput>` instead of `<input>` for multi-line entry with the same API and states. Auto-resizes from 3 to 20 rows, then locks and scrolls. The optional `counterSuffix` input adds a label to the counter (e.g. `0/200 words`). Supported sizes: `m` and `xl`.

- **`atom-search-input`** — standalone search field (HU-020). Two modes:
  - **Search Field** (default) — always visible with a leading search icon.
  - **Expandable** — collapses to an icon button; expands on click, Tab, or the global `⌘K` / `Ctrl+K` shortcut. Filled fields never auto-collapse.
  - Debounced `valueChange` (300 ms by default), immediate `search` on Enter, clear button while the field has a value. All strings (placeholder, aria-labels, shortcut key) are configurable via injection tokens for localization. Sizes: `s`, `m`, `l`.

- **`atom-list-item`** — three-zone row (Leading · Content · Trailing) for interactive lists. The entire row is a single interactive target — click or press Enter / Space to activate. Optional selection mode (checkbox or radio style), optional disclosure chevron (`[disclosure]=true`). Four interaction states: enabled, hovered, selected, disabled. Full Light/Dark mode support.

- **`atom-dropdown-menu`** — floating contextual action menu (HU-023) via CDK Overlay. Projects `atom-list-item` rows as menu items with WAI-ARIA keyboard navigation (↑/↓ with wrap, Escape, Tab to close). Optional scrollable variant via `[maxHeight]`, optional title slot. Use with `[atomDropdownTriggerFor]`.

- **`atom-select-panel`** — data-selection panel (HU-023) for multi-select, filter, and picker flows. Supports:
  - Optional search — apply `[atomSelectSearch]` on the panel and project `<atom-search-input>`; the directive owns the debounced filter and the empty-state.
  - Virtual scroll for large lists via `[virtualScrollItemSize]` + `[virtualScrollItems]` and an item template.
  - Configurable empty state (`[isEmpty]=true`) and footer action button — both customizable via `ATOM_SELECT_PANEL_CONFIG`.

- **`[atomDropdownTriggerFor]`** — attaches any element to an `atom-dropdown-menu` or `atom-select-panel` via CDK Overlay. Handles ARIA attributes (`aria-haspopup`, `aria-expanded`, `aria-controls`), four auto-flip positions, scroll repositioning, and focus restoration on close automatically. Outputs: `dropdownOpened`, `dropdownClosed`. Public API: `open()`, `close()`, `toggle()`.

### Fixed (0.4.0)

- **Solid-button box-model** — `atom-button` and `atom-icon-button` strokes now use `box-shadow: inset` instead of `border`, so they no longer inflate the rendered box size. All solid buttons now match their Figma dimensions exactly (e.g. `atom-icon-button size="l"` renders 48 × 48 instead of 48 × 50). `atom-link-button` is unaffected.

### Changed (0.4.0)

- **Tooltip motion delays** are now read at runtime from `--motion-tooltip-*-duration` CSS custom properties (sourced from `@atomchat-io/ui-tokens`), making design tokens the single source of truth. Previously they were hardcoded numbers in the directive. `ATOM_TOOLTIP_MOTION_OVERRIDES` remains available for test-only overrides.
- **`--motion-tooltip-rich-grace-duration`** — raised from 100 ms to 150 ms for a more forgiving trigger-to-panel cursor transit window.

## [0.3.1] - 2026-05-21

### Fixed (0.3.1)

- **Dialog shell layout** — adjusted `min-height` and `height` properties for `atom-dialog-shell` container to fix dialog sizing regressions in narrow layouts.

## [0.3.0] - 2026-05-13

### Added (0.3.0)

- **`AtomBadgeDirective`** — new `[atomBadge]` directive for overlaying notification counts on any element. Inputs under the `atomBadge*` namespace: `atomBadge` (value), `atomBadgeType` (`neutral` | `inbox`), `atomBadgeState` (`enabled` | `focused` | `subtle`), `atomBadgeMax` (default 99, renders as `+N` when exceeded), `atomBadgeHidden`, `atomBadgeDescription` (accessible label), `atomBadgeOverlap`, and `atomBadgePosition`. Value 0 hides the badge automatically. Re-exports `AtomBadgePosition`.
- **Scrollbar styles** — custom scrollbar styles applied globally. Supports Chromium/WebKit and Firefox. Colors are theme-aware and driven by `--scrollbar-track-bg`, `--scrollbar-thumb-bg`, and `--scrollbar-thumb-bg-hover` tokens.
- **`AtomEmptyStateComponent`** — new `atom-empty-state` component for representing the absence of content in tables, filters, and other container contexts. Supports `small` and `medium` size variants. Each section (visual, heading, supporting text, result text, action) accepts both a slot directive and an input fallback; projected content always takes precedence. Sections not provided are omitted from the DOM entirely.
  - Slot directives: `[atomEmptyStateVisual]`, `[atomEmptyStateHeading]`, `[atomEmptyStateSupportingText]`, `[atomEmptyStateResultText]`, `[atomEmptyStateAction]`.
  - `icon` input (`AtomIconSpec | null`) — fallback icon when no visual is projected.
  - `actionLabel` input (`string`) — renders an internal secondary button when no action slot is projected.
  - `actionClick` output — emitted when the internal action button is clicked.
- **`AtomSpinnerComponent`** — new `atom-spinner` indeterminate progress indicator. Five sizes: `xs` (12 px), `s` (16 px), `m` (20 px, default), `l` (24 px), `xl` (32 px). Color is inherited from the parent foreground via `currentColor` — no color prop needed. Configurable `aria-label` (default `'Loading'`). Respects `prefers-reduced-motion`.
- **`AtomTagComponent`** — new `span[atomTag]` non-interactive pill for semantic content classification. Inputs: `variant` (`ghost` | `filled` | `outlined`, default `ghost`), `size` (`xs` | `s` | `m`, default `s`), `intent` (`success` | `warning` | `danger` | `info` | `neutral` | `brand` | `ai` | `disabled`, default `neutral`), `leading` (`none` | `dot` | `icon`, default `none`), `label` (string input, falls back to projected content), and `icon` (`AtomIconSpec`, used when `leading="icon"`). Supports `--atom-tag-max-width` for label truncation. Exported types: `AtomTagVariant`, `AtomTagSize`, `AtomTagIntent`, `AtomTagLeading`.
- **`AtomAvatarComponent`** — new `atom-avatar` component with `image`, `image-border`, `outname`, and `icon` display types, `circle` / `square` shapes, four sizes (`xs`, `s`, `m`, `l`), and an integrated status dot (`online` / `offline` / `none` / `image`). Slot directives: `[atomAvatarIcon]`, `[atomAvatarImage]`, `[atomAvatarOutname]`, and `[atomAvatarStatus]`. `[atomAvatarStatus]` projects custom content (e.g. a brand icon) inside the `image` status dot. The `size` input defaults to `'m'` for standalone usage; when nested inside `atom-avatar-label-group`, the wrapper's size always takes precedence — use `effectiveSize()` to read the resolved value.
- **`AtomAvatarLabelGroupComponent`** — new `atom-avatar-label-group` component composing `atom-avatar` with label and description typography. Supports sizes `s`, `m`, and `l`. The avatar is projected as content rather than configured via inputs, giving consumers full control over avatar type, slots, and status:

  ```html
  <atom-avatar-label-group size="m" label="…" description="…">
    <atom-avatar type="image" src="…" status="image" ariaLabel="…">
      <img atomAvatarStatus src="…" alt="" />
    </atom-avatar>
  </atom-avatar-label-group>
  ```

- **`AtomChipComponent`** — new `atom-chip` component with 6 sizes (`xxs` / `xs` / `s` / `m` / `l` / `xl`), 2 types (`outlined` / `filled`), and 6 visual states (enabled, hovered, focused, pressed, error, disabled). Includes a leading-icon slot via `[atomChipIcon]` / `[atomIcon]`, an optional removable mode that emits `(removed)`, and `--atom-chip-max-width` for label truncation. Label supports both the `[label]` input and direct content projection.
- **Cross-component host directives** — `AtomLabelHostDirective`, `AtomLeadingIconSlotHostDirective`, and the abstract `AtomIconSlotMarkerDirective` now exported from `lib/host-directives/`. Reusable by any component that needs a label fallback or a leading-icon slot.

### Deprecated (0.3.0)

- `AtomButtonLabelHostDirective` — alias of `AtomLabelHostDirective`. Kept for transition; existing button / link-button consumers continue to compile unchanged.
- `AtomSingleIconSlotHostDirective` — alias of `AtomLeadingIconSlotHostDirective`. Kept for transition; existing icon-button consumers continue to compile unchanged.

### Refactored (0.3.0)

- **Button family spinner** — loading spinners inside `atom-button`, `atom-link-button`, and `atom-icon-button` now render `<atom-spinner>` internally, making `atom-spinner` the single source of truth for loading indicators across the design system. No changes to public APIs.

### Fixed (0.3.0)

- **Button border in disabled state** — `secondary` and `danger secondary` button variants now correctly apply `--border-disabled` when disabled. The border token was missing, causing those variants to render without a visible border in the disabled state.

## [0.2.1] - 2026-04-22

### Changed (0.2.1)

- Bumped peer dependency `@atomchat-io/ui-tokens` from `^0.2.0` to `^0.2.1` to align with the latest tokens patch.

## [0.2.0] - 2026-04-14

### Added (0.2.0)

- **`AtomToggleComponent`** — new toggle/switch component with full state coverage (enabled, hovered, focused, pressed, disabled, loading, error), size modifiers (`s`, `m`), and Storybook examples. Implemented following the same selection-control pattern as checkbox and radio.
- **Effects domain** — new `effects/` SCSS domain exposing CSS custom properties for shadows, focus rings, and blur from `@atomchat-io/ui-tokens` effects semantic tokens.
- **Elevation utility classes** — `.elevation-card`, `.elevation-popover`, `.elevation-modal` applying `box-shadow` via `--effects-shadows-*` custom properties.
- **Blur utility classes** — `.blur-surface-subtle`, `.blur-surface-medium`, `.blur-surface-strong` applying `backdrop-filter` + `background-color` (overlay) via `--effects-blur-*` custom properties. Theme-aware: overlay adapts to light/dark mode.
- **Checkbox and radio focus ring** — `--checkbox-focus-ring` and `--radio-focus-ring` component tokens added, both wired to `--effects-focus-rings-base`. Checkbox selector updated to `:has(.mdc-checkbox__native-control:focus), :has(.mdc-checkbox__native-control:focus-visible)` to reliably trigger in all focus modalities (keyboard and programmatic). Radio selector updated equivalently.
- **Storybook stories** — `atom-card.stories.ts` covering Playground (all inputs), Anatomy (shell, header, body, media, footer sub-stories), and content projection examples.
- **`AtomCardComponent`** — new card shell component (`atom-card`) with `ViewEncapsulation.None` and semantic card tokens. Accepts optional `[media]`, `[header]`, `[body]`, and `[footer]` slots via content projection. Supports `elevation-card` shadow by default.
- **`AtomCardTextDirective`** — shared text-content directive (`[atomCardText]`) injected by header and body sub-components to read `headline`, `subhead`, and `text` inputs without coupling them to the shell.
- **`AtomCardHeaderComponent`** — card header sub-component (`atom-card-header`) with a `__text` slot containing headline + subhead, and an optional `[atomCardHeaderText]` projection override for custom header content.
- **`AtomCardBodyComponent`** — card body sub-component (`atom-card-body`) with styled `__head-group` (headline + subhead, bold, primary color) and `__text` (label size, secondary color). Correctly uses `flex: 1 1 auto` so auto-height cards expand to fit content without collapsing.
- **`AtomCardMediaComponent`** — card media sub-component (`atom-card-media`) projecting arbitrary image/media content above the header.
- **`AtomCardFooterComponent`** — card footer sub-component (`atom-card-footer`) with two variants:
  - `ctas` (default) — renders a primary button and an optional secondary button; configurable via `primaryActionText`, `primaryActionColor`, `primaryActionDisabled`, `secondaryActionText`, `secondaryActionColor`, `secondaryActionDisabled`, `buttonSize`, and `buttonsFill` inputs. For any other button style, project `button[atom-button]` elements directly — this overrides all CTA inputs.
  - `dynamic-content` — projects freeform content via `[atomCardFooterDynamic]`.
  - `buttonsFill` input (`boolean`, default `false`) makes all CTAs stretch to fill available width equally.
- **`AtomCardFooterDynamicDirective`** — marker directive (`[atomCardFooterDynamic]`) for projecting freeform content into `dynamic-content` variant.
- **Card semantic tokens** — new `_card.scss` token file under `styles/scss/theme/components/` exposing `--card-bg`, `--card-fg-primary`, `--card-fg-secondary`, `--card-border`, and dark-mode overrides. All card sub-components consume these tokens.
- **`AtomDividerComponent`** — new divider component (`hr[atom-divider]`) implemented as a host-element directive on the native `<hr>` element, with no template file. Supports `horizontal` (default) and `vertical` orientations via the `atom-divider` attribute alias. Applies `role="separator"` and `aria-orientation` for accessibility. Color is driven by `--divider-border-default` (→ `--border-secondary`) and thickness by `--divider-border-width` (→ `--stroke-xs`). Vertical orientation uses `box-sizing: content-box` + `align-self: stretch` so the 1 px border renders correctly inside flex containers without a fixed parent height.
- **Divider semantic tokens** — new `_divider.scss` component token partial under `styles/scss/theme/components/` exposing `--divider-border-default` and `--divider-border-width`. Forwarded from `_components.scss` barrel.
- **`AtomDialogShellComponent`** — new dialog shell component (`atom-dialog-shell`) with `ViewEncapsulation.None` and semantic dialog tokens (`--dialog-bg-default`, `--dialog-fg-primary`, `--dialog-fg-secondary`, `--dialog-border-default`). Orchestrates header / body / footer sub-components in a flex column; body grows and scrolls internally while header and footer stay fixed (AC2).
- **`AtomDialogHeaderComponent`** — header sub-component (`atom-dialog-header`) with dual alignment: `left` (single row: cta + title + close) and `center` (flex-col: icon + title + subtitle, with absolutely-positioned close and back buttons). Implements API dual with slot precedence over inputs for all zones (`atomDialogHeaderCta`, `atomDialogHeaderIcon`, `atomDialogHeaderTitle`, `atomDialogHeaderSubtitle`, `atomDialogHeaderTitleRow`). Close button always standard X icon (not customizable via slot). CTA button hidden by default, shown when `showCtaButton=true`, defaults to fa-chevron-left icon. Emits `ctaClick` output for back/navigation actions.
- **`AtomDialogBodyComponent`** — body sub-component (`atom-dialog-body`) providing a scrollable free-projection region. Grows to fill available height via `flex: 1 1 auto` set by the shell.
- **`AtomDialogFooterComponent`** — footer sub-component (`atom-dialog-footer`) with `hug` (right-aligned, content-sized CTAs) and `fill` (equal-width CTAs) modes. Auto-detects projected `button[atom-button]` via contentChildren + computed pattern (same as AtomCard). Supports `atomDialogFooterStart` slot for left-side auxiliary content (e.g. selection counter). Wires buttons to `[atomDialogClose]` with `reason='primary-action'` / `reason='secondary-action'` automatically.
- **`AtomDialogCloseDirective`** — declarative close directive (`[atomDialogClose]`) for any element inside a dialog. Accepts `[atomDialogClose]="value"` and `[reason]="closeReason"` inputs; calls `dialogRef.close(AtomDialogCloseEvent)` on click. Uses optional `DialogRef` injection to remain safe outside dialog context (e.g. Storybook).
- **`AtomDialogService`** — wrapper of `@angular/cdk/dialog` with normative defaults (`hasBackdrop`, `restoreFocus`, `panelClass`). Maps backdrop clicks and Escape key presses to typed `AtomDialogCloseEvent` payloads (`reason: 'backdrop'` / `reason: 'escape'`). Exposes `ATOM_DIALOG_DATA` injection token for passing data into the opened component.
- **Dialog token domain** — new `_dialog.scss` in `styles/scss/theme/components/` mapping `dialog/bg/default → bg/primary`, `dialog/fg/primary → fg/primary`, `dialog/fg/secondary → fg/tertiary`, `dialog/border/default → border/secondary`.

### Changed (0.2.0)

- Bumped peer dependency `@atomchat-io/ui-tokens` from `^0.1.x` to `^0.2.0` to consume new status tokens (`bg/status/neutral`, `fg/status/on-*`, `border/status/on-*`) and the new effects semantic token domain (shadows, focus rings, blur).
- **Button focus ring** — `--buttons-focus-ring-*` component tokens now reference `--effects-focus-rings-base` (base variants) and `--effects-focus-rings-error` (destructive variants) instead of raw color primitives. The `box-shadow` in the component mixin is now assembled by the effects token (full value), not by the component itself.

### Refactored (0.2.0)

- **`SelectionControlBaseDirective`** — extracted shared CVA logic (signals, computed properties, `ControlValueAccessor` implementation, `onControlChange` handler) from `CheckboxComponent` and `AtomToggleComponent` into a generic abstract `@Directive()` base class. The `change` output is typed via `TChange extends { checked: boolean }`, removing all duplication between the two components.
- **`AtomSelectionControlSize`** — `AtomCheckboxSize` and `AtomToggleSize` are now type aliases of `AtomSelectionControlSize` (defined in the base directive). The original names are preserved as backward-compatible aliases. `AtomSelectionControlSize` is exported from the library root.
- **Stories** — replaced `@Input()` decorators with signal `input()` in the Storybook catalog helper components for toggle and checkbox, aligning with the signals-first pattern used in the library components.
- **Toggle track shape** — extracted `--toggle-track-shape` component variable in `toggle.component.scss`; both size variants now reference it instead of repeating `var(--spacing-m)` inline in `--mat-slide-toggle-track-shape`.
- **Stories** — replaced direct property access with reactive `input()` signal calls in the Storybook catalog helper components for checkbox and toggle, aligning with the signals-first pattern used by the library components.

### Fixed (0.2.0)

- **Link button mixed-decls warning** — moved plain declarations (`min-width`, `@include _atom-link-button-state`) before the `atom-interactive-link-button-host-shell` mixin include to comply with upcoming Sass mixed-declarations behavior.
- **Build dependency** — `design-system-docs:build` now depends on `ui-tokens:build` instead of `ui-tokens:generate-tokens`, ensuring `package.json` is present in `dist/libs/ui-tokens` for Sass package resolution.
- **Checkbox disabled+checked checkmark size** — replaced `border: none` with `border-color: transparent` in the disabled+checked/indeterminate background override. Removing the border collapsed the box model, causing the checkmark SVG to render visually larger than in the enabled state. Keeping the border transparent preserves the 2 px inset and the correct checkmark size across all states.

| Commit    | Detail                                                                                                    |
| --------- | --------------------------------------------------------------------------------------------------------- |
| `1feeb34` | Added `effects/_variables.scss`, `_custom-properties.scss`; wired into `_tokens.scss`.                    |
| `e84783f` | Imported effects custom properties in `atom-theme.scss` and `atom-theme-m3.scss`.                         |
| `cf316d4` | Wired `--buttons-focus-ring-*` to effects tokens; mixin now uses full box-shadow value.                   |
| `ca8289f` | Added `effects/_classes.scss` and `utilities.scss`; switched theme entry points to use `utilities`.       |
| `347beca` | Fixed link-button mixed-decls Sass deprecation warning.                                                   |
| `0140386` | Fixed build dependency: `design-system-docs` now depends on `ui-tokens:build`.                            |
| `8a73fc9` | Updated `--buttons-focus-ring-*` to reference renamed effects tokens (`-base`, `-error`).                 |
| `7677984` | Added `--checkbox-focus-ring` token; initial wiring via `.cdk-focused` (superseded by `193898f`).         |
| `193898f` | Checkbox/radio: use `:has(:focus/:focus-visible)` for focus ring; added `--radio-focus-ring` token.       |
| `d6b65b6` | Added component token layer (`_toggle.scss`) for toggle states and error handling.                        |
| `c43eb0a` | Added centralized visual layer and Material overrides for toggle (`_am-toggle.scss`).                     |
| `742e524` | Implemented `AtomToggleComponent` with template, styles, and public API.                                  |
| `27f1e1a` | Added unit tests and Storybook stories for `AtomToggleComponent`.                                         |
| `3a6ec0f` | Refactored selection-control size/layout mixins shared by toggle, checkbox, and radio.                    |
| `f057ff3` | Extracted `SelectionControlBaseDirective`; checkbox and toggle now extend it.                             |
| `9c5ca0a` | Unified `onControlChange` handler and error icon across checkbox and toggle after base directive extract. |
| `56647b6` | Removed standalone `AtomToggleSize`; re-exported as alias of `AtomSelectionControlSize`.                  |
| `6ab191e` | Extracted `--toggle-track-shape`; both sizes now reference it via `--mat-slide-toggle-track-shape`.       |
| `c9ec40b` | Fixed checkbox disabled+checked checkmark size: `border: none` → `border-color: transparent`.             |
| `8453bf2` | Updated Storybook catalog helpers to use reactive `input()` functions for checkbox and toggle stories.    |
| `3c25324` | Added `_card.scss` component tokens; wired into theme entry points.                                       |
| `b4ebfc2` | Implemented `AtomCardTextDirective` for shared text-content inputs.                                       |
| `aa136be` | Implemented `AtomCardComponent` shell with slot-based content projection.                                 |
| `17bc883` | Implemented `AtomCardHeaderComponent` with custom-text projection slot.                                   |
| `6cf265c` | Implemented `AtomCardBodyComponent` with head-group and text layout.                                      |
| `ff095cf` | Implemented `AtomCardMediaComponent` for image/media projection.                                          |
| `1e49f6f` | Implemented `AtomCardFooterComponent` with CTA inputs, variants, buttonsFill.                             |
| `2a135ec` | Exported all card symbols from the library public API (`index.ts`).                                       |
| `62576ff` | Added Storybook stories: Playground, Anatomy, and projection examples.                                    |
| `8f50c86` | Implemented `AtomDividerComponent` (host-element on `hr`, orientation, a11y, token-based styles).         |
| `fb9a11e` | Added `_divider.scss` component token partial; forwarded from `_components.scss` barrel.                  |
| `a4a0d95` | Exported `AtomDividerComponent` and `AtomDividerOrientation` from the library public API (`index.ts`).    |
| `b7cf3f9` | Added Storybook stories: Playground, Orientation, Section separator, Toolbar with vertical dividers.      |

## [0.1.7] - 2026-04-07

### Fixed (0.1.7)

- Update selector in `radio-group` to improve styling consistency. Commit: `ea6d266`

## [0.1.6] - 2026-04-07

### Reverted (0.1.6)

- Revert "fix(button): update styles and encapsulation for button component". Commit: `f716aec`

## [0.1.5] - 2026-04-07

### Fixed (0.1.5)

- Update styles and encapsulation for `atom-button` component. Commit: `da3af65`

## [0.1.4] - 2026-04-07

### Changed / Fixed (0.1.4)

- Improved encapsulation in `atom-button` by scoping icon and spinner styles with `::ng-deep`. Commit: `fdeb2b0`

## [0.1.3] - 2026-04-06

### Added / Fixed (0.1.3)

- Implemented `change` event in `atom-radio-group` to correctly emit `AtomRadioChange` (transparent mapped to `MatRadioChange`), ensuring full compatibility with the `mat-radio-group` API.
- Re-exposed event propagation from `atom-radio-button` correctly when modified by user interaction.

## [0.1.2] - 2026-04-01

### Fixed (0.1.2)

- Resolved button icon projection and story binding issues.

| Commit    | Detail                                                           |
| --------- | ---------------------------------------------------------------- |
| `1d092a5` | Corrected `ng-content` selectors for icon positions.             |
| `8992b81` | Updated start/end icon projection selectors in button templates. |
| `0327c46` | Fixed button type binding syntax in stories.                     |

### Changed (0.1.2)

- Improved responsive sizing behavior in button and checkbox styles, and aligned package metadata.

| Commit    | Detail                                                    |
| --------- | --------------------------------------------------------- |
| `8460246` | Updated package version and peer dependencies.            |
| `5de2458` | Refined button width and max-width behavior.              |
| `0e9f63f` | Updated checkbox sizing to use `fit-content`/`max-width`. |
| `0442506` | Removed checkbox `max-width` to improve flexibility.      |
| `38a63c1` | Adjusted checkbox width for layout adaptability.          |
| `de79b2b` | Updated button-with-icons story title for clarity.        |

## [0.1.1] - 2026-03-27

### Changed (0.1.1)

- Released `0.1.1` with dependency/version alignment updates.

| Commit    | Detail                                                         |
| --------- | -------------------------------------------------------------- |
| `32402a1` | Bumped `ui-design-system` to `0.1.1` and updated dependencies. |

## [0.1.0] - 2026-03-27

### Added (0.1.0)

- **Theming:** opt-in Angular Material 3 theme entry (`atom-theme-m3.scss`), M3 palette helpers in theme base.
- **Checkbox:** centralized Material overrides (`_am-checkbox.scss`), theme/component SCSS split, and `change` output emitting `MatCheckboxChange` for Material compatibility.
- **Radio:** centralized Material overrides (`_am-radio.scss`), radio group orientation/layout styles, and `AtomRadioChange` type for `valueChange`.
- **Button:** `a[atom-button]` support with anchor-safe disabled/tabindex behavior and label truncation support.
- **Shared:** reusable text truncation mixins and truncation behavior on `atom-selection-control-label`.
- **Theming:** `$atom-dark-mode-class` and `atom-dark-mode-class-name()` in `styles/scss/_config.scss` (default class: `#{$atom-prefix}dark-mode`), plus `ATOM_DARK_MODE_CLASS_DEFAULT` for TypeScript toggling.

### Fixed (0.1.0)

- Checkbox: deferred `NgControl` resolution, class bindings, and layout edge cases.
- Button: icon selector handling, `.mat-icon` styles, and related import paths.

### Changed (0.1.0)

- Checkbox and radio theme wiring (M2/M3 entry points) and radio token application in `:root` / configurable dark mode class.
- Internal package references aligned with `@atomchat-io/*` where applicable.
