# Atom Design System - Theme Architecture

This directory contains the theming layer of the Atom Design System, split into two layers:

## Framework-Agnostic Layer (CDN-safe)

These files have **no dependency** on `@angular/material` and can be consumed by any project:

| File | Purpose |
| :--- | :--- |
| `_typography-vars.scss` | Pure SCSS variables for font families, weights, and sizes extracted from design tokens |
| `_fonts.scss` | `@font-face` declarations for the Inter font family (configurable path via `$font-base-path`) |
| `_semantic.scss` | CSS custom properties for semantic tokens (`:root` for light, configurable dark-mode class for dark — see `scss/_config.scss`) |
| `_semantic-classes.scss` | Utility classes derived from semantic token keys (`.atom-bg-*`, `.atom-fg-*`, `.atom-border-*`) |
| `_index.scss` | Barrel that forwards only the framework-agnostic files |

## Angular Material Layer

These files depend on `@angular/material` and are only needed by Angular Material consumers:

| File | Purpose |
| :--- | :--- |
| `_mat-typography.scss` | Angular Material typography configuration (`mat.m2-define-typography-config`) |
| `_mat-base.scss` | Palette definitions, `mat.core()`, and `$atom-theme` |
| `_mat-index.scss` | Barrel that forwards both agnostic and Angular Material files |
