# Atom Design System — CDN bundle

Static **compiled CSS** and Inter font files published to Firebase Hosting for consumers who need tokens and utilities **without** installing npm packages. For **Sass sources**, overrides (`$font-base-path`, `config`), and Angular Material themes, use **`@atomchat-io/ui-design-system`** and **`@atomchat-io/ui-tokens`** from the npm registry.

CSS entry points match the library’s **`_tokens.scss`** and **`_index.scss`** outputs (not `atom-theme.scss`, which includes Angular Material).

## URLs

After deploy, replace `{version}` with the published semver (from this release) and your CDN base (for example `https://design-cdn.atomchat.io`):

| Asset       | Versioned URL                  | Latest alias               |
| ----------- | ------------------------------ | -------------------------- |
| Tokens only | `{base}/v{version}/tokens.css` | `{base}/latest/tokens.css` |
| Full utils  | `{base}/v{version}/index.css`  | `{base}/latest/index.css`  |

Example:

```html
<link rel="stylesheet" href="https://design-cdn.atomchat.io/latest/index.css" />
```

Use **`latest/`** for convenience; pin **`v{major}.{minor}.{patch}/`** when you need a fixed snapshot (same layout as npm semver).

## Entry points

| File         | Contents                                                                                                                                                 |
| ------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `tokens.css` | CSS custom properties (primitives + semantic + component aliases `--buttons-*`, `--radio-*`, `--checkbox-*`) and Inter `@font-face`. No utility classes. |
| `index.css`  | Everything in `tokens.css` plus utility classes (color, typography, spacing, radius, stroke, layout, semantic helpers).                                  |

`atom-theme.css` (Angular Material) is **not** published on the CDN.

## Fonts

Inter (Regular, Medium, Bold) is served next to the CSS. `@font-face` URLs are **relative** (`./fonts/inter/*.woff2`) so they resolve for any version path or domain.

## Naming

- **CSS variables:** `--color-*`, semantic tokens, spacing, radius, etc., as documented in the library `src/styles/README.md`.
- **Utility classes:** default prefix `atom-` (e.g. `.atom-color-neutral-500`). Dark mode class defaults to `atom-dark-mode` on the root unless overridden in SCSS when building from source.

## Cache behavior

- Versioned paths under `v*/*` are served with long-lived immutable cache headers.
- `latest/*` uses a short TTL so updates propagate within minutes.

For reproducible builds or Sass, use the **same semver** from `@atomchat-io/ui-design-system` on npm when available.

## Deploy (maintainers)

1. Create a Firebase Hosting site for this CDN if it does not exist, then link it: `firebase target:apply hosting design-system-cdn <site-id>` (see `.firebaserc` for the expected target name).
2. Map the custom domain (for example `design-cdn.atomchat.io`) in Firebase Hosting and DNS.
3. From the monorepo root:

```bash
nx run ui-design-system:build-cdn
firebase deploy --only hosting:design-system-cdn
```

The hosting `public` output is `dist/libs/design-system-cdn` (see `firebase.json`).
