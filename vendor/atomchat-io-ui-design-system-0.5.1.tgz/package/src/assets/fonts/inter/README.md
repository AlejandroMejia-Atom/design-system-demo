# Inter Font Files

This directory should contain the Inter font files for the Atom Design System.

## Required Files

Download the following files from [Google Fonts](https://fonts.google.com/specimen/Inter) or [rsms/inter](https://github.com/rsms/inter/releases):


### Static Fonts (Fallback)
- `Inter-Regular.woff2` - Weight 400
- `Inter-Medium.woff2` - Weight 500  
- `Inter-Bold.woff2` - Weight 700

## Installation

1. Download Inter from https://github.com/rsms/inter/releases
2. Extract the woff2 files to this directory
3. Ensure the filenames match exactly as listed above

## Usage

The fonts are automatically loaded via `@font-face` declarations in:
`libs/ui-design-system/src/lib/styles/scss/theme/_fonts.scss`
