'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'boombox';
var width = 576;
var height = 512;
var aliases = [128254];
var unicode = 'f8a5';
var svgPathData = 'M120 48l336 0c22.1 0 40 17.9 40 40l0 72-80 0c0-17.7-14.3-32-32-32s-32 14.3-32 32l-32 0c0-17.7-14.3-32-32-32s-32 14.3-32 32l-32 0c0-17.7-14.3-32-32-32s-32 14.3-32 32l-80 0 0-72c0-22.1 17.9-40 40-40zM544 168.6L544 88c0-48.6-39.4-88-88-88L120 0C71.4 0 32 39.4 32 88l0 80.6C12.9 179.6 0 200.3 0 224L0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-192c0-23.7-12.9-44.4-32-55.4zM208 320a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM64 320a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zm352 48a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm0-144a96 96 0 1 1 0 192 96 96 0 1 1 0-192z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoombox = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;