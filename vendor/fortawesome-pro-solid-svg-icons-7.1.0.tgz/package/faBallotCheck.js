'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'ballot-check';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'f733';
var svgPathData = 'M0 64C0 28.7 28.7 0 64 0L320 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zm64 64a32 32 0 1 0 64 0 32 32 0 1 0 -64 0zm0 256a32 32 0 1 0 64 0 32 32 0 1 0 -64 0zm136-24c-13.3 0-24 10.7-24 24s10.7 24 24 24l96 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-96 0zM176 128c0 13.3 10.7 24 24 24l96 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-96 0c-13.3 0-24 10.7-24 24zm56 104c-13.3 0-24 10.7-24 24s10.7 24 24 24l64 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-64 0zm-72.6-12.5c6.4-8.5 4.6-20.5-3.8-26.9s-20.5-4.6-26.9 3.8L96 240 87.4 228.5C81 220 69 218.3 60.5 224.6S50.3 243 56.6 251.5l24 32c3.6 4.8 9.3 7.7 15.4 7.7s11.7-2.8 15.4-7.7l48-64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBallotCheck = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;