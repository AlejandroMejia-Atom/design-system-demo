'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrows-repeat';
var width = 512;
var height = 512;
var aliases = ["repeat-alt"];
var unicode = 'f364';
var svgPathData = 'M470.6 118.6c6-6 9.4-14.1 9.4-22.6s-3.4-16.6-9.4-22.6l-80-80c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L370.7 64 192 64C86 64 0 150 0 256 0 273.7 14.3 288 32 288s32-14.3 32-32c0-70.7 57.3-128 128-128l178.7 0-25.4 25.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l80-80zM41.4 393.4c-6 6-9.4 14.1-9.4 22.6s3.4 16.6 9.4 22.6l80 80c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L141.3 448 320 448c106 0 192-86 192-192 0-17.7-14.3-32-32-32s-32 14.3-32 32c0 70.7-57.3 128-128 128l-178.7 0 25.4-25.4c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-80 80z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRepeat = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;