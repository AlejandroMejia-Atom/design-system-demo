'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'blinds';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f8fb';
var svgPathData = 'M32 32C14.3 32 0 46.3 0 64S14.3 96 32 96L3.8 146.7C1.3 151.2 0 156.3 0 161.5 0 178.3 13.7 192 30.5 192l33.5 0 0-96 48 0 0 216c0 13.3 10.7 24 24 24s24-10.7 24-24l0-216 48 0 0 96 209.5 0c16.8 0 30.5-13.7 30.5-30.5 0-5.2-1.3-10.3-3.8-14.8L416 96c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 32zm0 208L3.8 290.7C1.3 295.2 0 300.3 0 305.5 0 322.3 13.7 336 30.5 336l33.5 0 0-96-32 0zm385.5 96c16.8 0 30.5-13.7 30.5-30.5 0-5.2-1.3-10.3-3.8-14.8l-28.2-50.7-208 0 0 96 209.5 0zm0 144c16.8 0 30.5-13.7 30.5-30.5 0-5.2-1.3-10.3-3.8-14.8L416 384 32 384 3.8 434.7C1.3 439.2 0 444.3 0 449.5 0 466.3 13.7 480 30.5 480l387 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlinds = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;