'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bin-bottles-recycle';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e5f6';
var svgPathData = 'M96 64l0 32c-35.3 0-64 28.7-64 64l0 16 512 0 0-16c0-35.3-28.7-64-64-64l0-32c0-17.7-14.3-32-32-32l-64 0c-17.7 0-32 14.3-32 32l0 32c-35.3 0-64 28.7-64 64 0-35.3-28.7-64-64-64l0-32c0-17.7-14.3-32-32-32l-64 0c-17.7 0-32 14.3-32 32zM32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l4 0 21 167.9c4 32 31.2 56.1 63.5 56.1l335 0c32.3 0 59.5-24 63.5-56.1l21-167.9 4 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 224zm256 80c-2.4 0-4.7 1.1-6.1 3.1l-15.7 21.5c-7.4 10.1-21.4 12.8-32.1 6.2-11.8-7.4-14.9-23.3-6.6-34.5l15.7-21.5C253.7 264.4 270.3 256 288 256s34.3 8.4 44.8 22.7l15.7 21.5c8.3 11.3 5.2 27.1-6.6 34.5-10.7 6.7-24.6 4-32.1-6.2l-15.7-21.5c-1.4-1.9-3.7-3.1-6.1-3.1zm-80.7 61.2c11.8 7.4 14.9 23.3 6.6 34.5l-4.8 6.5c-.8 1.1-1.2 2.3-1.2 3.6 0 3.4 2.7 6.1 6.1 6.1l29.9 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-29.9 0c-29.9 0-54.1-24.2-54.1-54.1 0-11.5 3.7-22.7 10.5-32l4.8-6.5c7.4-10.1 21.4-12.8 32.1-6.2zM308 440c0-13.3 10.7-24 24-24l29.9 0c3.4 0 6.1-2.7 6.1-6.1 0-1.3-.4-2.6-1.2-3.6l-4.8-6.5c-8.3-11.3-5.2-27.1 6.6-34.5 10.7-6.7 24.6-4 32.1 6.2l4.8 6.5c6.8 9.3 10.5 20.5 10.5 32 0 29.9-24.2 54.1-54.1 54.1L332 464c-13.3 0-24-10.7-24-24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinBottlesRecycle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;