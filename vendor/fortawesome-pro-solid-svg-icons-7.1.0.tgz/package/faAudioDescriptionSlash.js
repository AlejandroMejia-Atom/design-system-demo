'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'audio-description-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0a8';
var svgPathData = 'M7-24.9c9.4-9.4 24.6-9.4 33.9 0L129.8 64 480 64c35.3 0 64 28.7 64 64l0 256c0 25.5-14.9 47.4-36.4 57.8L569 503.1c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0L7 9.1C-2.3-.3-2.3-15.5 7-24.9zM352 208l24 0c13.3 0 24 10.7 24 24l0 48c0 13.3-10.7 24-24 24l-6.2 0 39.7 39.7C432.4 331.7 448 307.6 448 280l0-48c0-39.8-32.2-72-72-72l-48 0c-13.3 0-24 10.7-24 24l0 54.2 48 48 0-78.2zM128 224l0 104c0 13.3 10.7 24 24 24s24-10.7 24-24l0-24 48 0 0 24c0 13.3 10.7 24 24 24 9.2 0 17.3-5.2 21.3-12.9L378.2 448 96 448c-35.3 0-64-28.7-64-64l0-256c0-7.8 1.4-15.3 4-22.2l96 96c-2.6 6.9-4 14.4-4 22.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAudioDescriptionSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;