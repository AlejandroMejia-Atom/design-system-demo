'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'atom-simple';
var width = 448;
var height = 512;
var aliases = ["atom-alt"];
var unicode = 'f5d3';
var svgPathData = 'M69.4 411.1c-1.3-1.3-12.4-16.8 3.3-64 3.5-10.4 8-21.4 13.6-32.9 11.6 14.2 24.3 28.3 38 41.9s27.7 26.4 41.9 38c-11.4 5.6-22.4 10.2-32.8 13.6-47.2 15.7-62.7 4.6-64 3.3zM122.2 256c13.5-18.3 29.3-36.8 47.4-54.9s36.6-33.9 54.9-47.4c18.3 13.5 36.8 29.3 54.9 47.4s33.9 36.6 47.4 54.9c-13.5 18.3-29.3 36.8-47.4 54.9s-36.6 33.9-54.9 47.4c-18.3-13.5-36.8-29.3-54.9-47.4s-33.9-36.6-47.4-54.9zm44.1-138.1c-14.2 11.6-28.3 24.3-41.9 38s-26.4 27.7-38 41.9c-5.6-11.4-10.2-22.4-13.6-32.8-15.7-47.2-4.6-62.7-3.3-64s16.8-12.4 64 3.3c10.4 3.5 21.4 8 32.8 13.6zm58.2-41.1C142.4 27.6 63.4 16.5 24.2 55.7S-3.9 173.9 45.3 256C-3.9 338.1-15 417.1 24.2 456.3s118.2 28.1 200.3-21.1c82.1 49.2 161.1 60.3 200.3 21.1S452.9 338.1 403.7 256C452.9 173.9 464 94.9 424.8 55.7S306.6 27.6 224.5 76.8zm58.2 41.1c11.4-5.6 22.4-10.2 32.9-13.6 47.2-15.7 62.7-4.6 64-3.3s12.4 16.8-3.3 64c-3.5 10.4-8 21.4-13.6 32.8-11.6-14.2-24.3-28.3-38-41.9s-27.7-26.4-41.9-38zm79.9 196.3c5.6 11.4 10.2 22.4 13.6 32.9 15.7 47.2 4.6 62.7 3.3 64s-16.8 12.4-64-3.3c-10.4-3.5-21.4-8-32.9-13.6 14.2-11.6 28.3-24.3 41.9-38s26.4-27.7 38-41.9zM256.5 256a32.5 32.5 0 1 0 -65 0 32.5 32.5 0 1 0 65 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAtomSimple = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;