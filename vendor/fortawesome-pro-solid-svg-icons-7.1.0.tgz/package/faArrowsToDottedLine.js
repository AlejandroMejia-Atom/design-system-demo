'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrows-to-dotted-line';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e0a6';
var svgPathData = 'M278.6 102.6l-64 64c-12.5 12.5-32.8 12.5-45.3 0l-64-64c-9.2-9.2-11.9-22.9-6.9-34.9S115.1 48 128 48l32 0 0-48c0-17.7 14.3-32 32-32s32 14.3 32 32l0 48 32 0c12.9 0 24.6 7.8 29.6 19.8s2.2 25.7-6.9 34.9zm0 306.7c9.2 9.2 11.9 22.9 6.9 34.9S268.9 464 256 464l-32 0 0 48c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-48-32 0c-12.9 0-24.6-7.8-29.6-19.8s-2.2-25.7 6.9-34.9l64-64c12.5-12.5 32.8-12.5 45.3 0l64 64zM64 256a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm74.7 32a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm138.7-32a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM352 288a32 32 0 1 1 0-64 32 32 0 1 1 0 64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsToDottedLine = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;