'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'ball-yarn';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6ce';
var svgPathData = 'M207 136L243.4 .3C150.7 4.8 71 58.6 29.8 136L207 136zM292.5 2.6l-35.8 133.4 66.6 0 31.2-116.4c-19.6-8.2-40.4-14-62-17.1zM117.2 471.2l25.5-95.2-112.9 0c20.6 38.7 50.8 71.5 87.4 95.2zM192.4 376L160.9 493.7c19.7 7.9 40.5 13.4 62.3 16.2L259 376 192.4 376zM482.2 136c-20-37.6-49-69.6-84.2-93.1L373 136 482.2 136zm0 240l-173.5 0-36.4 136 215.7 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-82.7 0c31.9-23 58.3-53.1 76.9-88zm19.5-48c4.5-15.4 7.6-31.5 9.2-48L1.1 280c1.5 16.5 4.6 32.6 9.2 48l491.5 0zm0-144L10.3 184c-4.5 15.4-7.6 31.5-9.2 48l509.8 0c-1.5-16.5-4.6-32.6-9.2-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBallYarn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;