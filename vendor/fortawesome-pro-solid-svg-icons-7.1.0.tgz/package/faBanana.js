'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'banana';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e2e5';
var svgPathData = 'M304 144c0 35.7-7.3 69.6-20.5 100.5 4.8 3 9.4 6.2 13.9 9.8L332.9 282.6 414 261c10.6-2.8 21.4-4.4 32.3-4.9 1.2-10.5 1.8-21.3 1.8-32.1 0-84.7-36.6-160.9-94.8-213.6-7.6-6.8-17.3-10.4-27-10.4-29.4 0-47.5 29.4-38 55 10.3 27.7 15.9 57.7 15.9 89zM277.4 279.2c-18.8-15-42.1-23.2-66.1-23.2-22.9 0-45.2 7.4-63.5 21.2l-42.2 31.6c-10.6 8-12.8 23-4.8 33.6s23 12.8 33.6 4.8l42.2-31.6c10-7.5 22.2-11.6 34.7-11.6 10.5 0 20.8 2.9 29.7 8.2-46.9 53.8-116 87.8-193 87.8-26.5 0-48 21.5-48 48l0 16c0 26.5 21.5 48 48 48l112 0c117.3 0 218.2-70.1 263.1-170.6l11.5-3.1c5.7-1.5 11.6-2.3 17.5-2.3 23.8 0 45.9 12.5 58.1 32.9l21.3 35.4c6.8 11.4 21.6 15 32.9 8.2s15-21.6 8.2-32.9l-21.3-35.4c-20.9-34.9-58.6-56.2-99.3-56.2-3.8 0-7.5 .2-11.3 .6-5.5 .5-10.9 1.5-16.3 2.8-.8 .2-1.5 .4-2.3 .6l-96.7 25.8-48.1-38.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanana = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;