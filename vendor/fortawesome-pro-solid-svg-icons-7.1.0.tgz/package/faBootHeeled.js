'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'boot-heeled';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e33f';
var svgPathData = 'M96 0L35.8 0C16.7 0 1.8 16.6 3.9 35.5l23 206.7c3.4 30.2 1.3 60.8-6.1 90.4l-17 68.1C1.3 410.9 0 421.3 0 431.8L0 480c0 17.7 14.3 32 32 32l64 0c17.7 0 32-14.3 32-32l112.7 28.2c10.2 2.5 20.6 3.8 31 3.8L416 512c17.7 0 32-14.3 32-32l0-43.2c0-22.8-12.1-43.8-31.8-55.3L292 309c-21.9-12.8-34.2-37.2-31.4-62.4L284.1 35.5C286.2 16.6 271.3 0 252.2 0L144 0 144 200c0 13.3-10.7 24-24 24s-24-10.7-24-24L96 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBootHeeled = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;