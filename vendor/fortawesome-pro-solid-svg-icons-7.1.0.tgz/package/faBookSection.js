'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'book-section';
var width = 448;
var height = 512;
var aliases = ["book-law"];
var unicode = 'e0c1';
var svgPathData = 'M96 512l320 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l0-66.7c18.6-6.6 32-24.4 32-45.3l0-288c0-26.5-21.5-48-48-48L96 0C43 0 0 43 0 96L0 416c0 53 43 96 96 96zM64 416c0-17.7 14.3-32 32-32l256 0 0 64-256 0c-17.7 0-32-14.3-32-32zM192 76l88 0c11 0 20 9 20 20s-9 20-20 20l-88 0c-6.6 0-12 5.4-12 12s5.4 12 12 12l64 0c28.7 0 52 23.3 52 52 0 12.1-4.1 23.2-11 32 6.9 8.8 11 19.9 11 32 0 28.7-23.3 52-52 52l-88 0c-11 0-20-9-20-20s9-20 20-20l88 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-64 0c-28.7 0-52-23.3-52-52 0-12.1 4.1-23.2 11-32-6.9-8.8-11-19.9-11-32 0-28.7 23.3-52 52-52zm64 128c6.6 0 12-5.4 12-12s-5.4-12-12-12l-64 0c-6.6 0-12 5.4-12 12s5.4 12 12 12l64 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookSection = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;