'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'book-open-cover';
var width = 576;
var height = 512;
var aliases = ["book-open-alt"];
var unicode = 'e0c0';
var svgPathData = 'M288 140c9.7-3.5 33.3-11.9 70.9-25.3 34.5-12.3 70.9-18.6 107.6-18.6l45.5 0 0 256-45.5 0c-51.4 0-102.3 8.8-150.7 26.1L288 388 288 140zm0-68L238.6 54.4C197.2 39.6 153.5 32 109.5 32L48 32C21.5 32 0 53.5 0 80L0 368c0 26.5 21.5 48 48 48l61.5 0c44 0 87.7 7.6 129.2 22.4l38.6 13.8c7 2.5 14.6 2.5 21.5 0l38.6-13.8c41.5-14.8 85.1-22.4 129.2-22.4l61.5 0c26.5 0 48-21.5 48-48l0-288c0-26.5-21.5-48-48-48l-61.5 0c-44 0-87.7 7.6-129.2 22.4L288 72zM0 488c0 13.3 10.7 24 24 24l85.5 0c41.3 0 82.2 7.1 121.1 21l38.6 13.8c12.2 4.3 25.5 4.3 37.7 0L345.4 533c38.9-13.9 79.8-21 121.1-21l85.5 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-85.5 0c-46.8 0-93.2 8-137.2 23.8l-38.6 13.8c-1.7 .6-3.6 .6-5.4 0l-38.6-13.8C202.7 472 156.3 464 109.5 464L24 464c-13.3 0-24 10.7-24 24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookOpenCover = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;