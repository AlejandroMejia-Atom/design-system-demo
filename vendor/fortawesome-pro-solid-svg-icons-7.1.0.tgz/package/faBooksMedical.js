'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'books-medical';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f7e8';
var svgPathData = 'M390.8 17c-17.1 4.6-27.2 22.1-22.6 39.2l12.4 46.4 123.6-33.1-12.4-46.4C487.3 6 469.7-4.1 452.7 .4L390.8 17zm125.9 98.8l-123.6 33.1 20.8 77.5c24.9-11.8 52.8-18.4 82.2-18.4 16.2 0 31.9 2 46.9 5.8l-26.3-98zM352 128c0-17.7-14.3-32-32-32l-48 0c-17.7 0-32 14.3-32 32l0 352c0 17.7 14.3 32 32 32l48 0c6.1 0 11.9-1.7 16.7-4.7-20.7-30.6-32.7-67.5-32.7-107.3 0-48.7 18.1-93.2 48-127l0-145zM64 32l0 48 128 0 0-48c0-17.7-14.3-32-32-32L96 0C78.3 0 64 14.3 64 32zm0 96l0 256 128 0 0-256-128 0zm0 304l0 48c0 17.7 14.3 32 32 32l64 0c17.7 0 32-14.3 32-32l0-48-128 0zM496 544a144 144 0 1 0 0-288 144 144 0 1 0 0 288zM485.3 320l21.3 0c8.8 0 16 7.2 16 16l0 37.3 37.3 0c8.8 0 16 7.2 16 16l0 21.3c0 8.8-7.2 16-16 16l-37.3 0 0 37.3c0 8.8-7.2 16-16 16l-21.3 0c-8.8 0-16-7.2-16-16l0-37.3-37.3 0c-8.8 0-16-7.2-16-16l0-21.3c0-8.8 7.2-16 16-16l37.3 0 0-37.3c0-8.8 7.2-16 16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBooksMedical = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;