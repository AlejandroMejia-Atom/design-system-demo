'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrow-u-turn-left-down';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e7e9';
var svgPathData = 'M180.7 504.8c-12.6 10.3-31.1 9.5-42.8-2.2l-112-112c-12.5-12.5-12.5-32.8 0-45.2s32.8-12.5 45.2 0l57.4 57.4 0-210.7C128.5 89.3 209.2 5.4 310.6 .3l9.9-.2c106 0 192 86 192 192l0 224-.2 3.3c-1.6 16.1-15.3 28.7-31.8 28.7s-30.2-12.6-31.8-28.7l-.2-3.3 0-224c0-70.7-57.3-128-128-128l-6.6 .2C246.3 67.6 192.5 123.5 192.5 192l0 210.7 57.4-57.4 2.4-2.2c12.6-10.2 31.1-9.5 42.8 2.2s12.4 30.2 2.2 42.8l-2.2 2.4-112 112-2.4 2.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnLeftDown = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;