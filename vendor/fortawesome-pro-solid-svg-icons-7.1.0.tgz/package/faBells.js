'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bells';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f77f';
var svgPathData = 'M23.9 263.3l205.8 56.3c-.6-3.3-1.4-6.7-2.2-10l-5.8-21.9c-26.6-101.2 33.7-205.6 134.6-233.1 2.7-.7 5.3-1.4 8-2-16.9-37.7-49.9-67.9-92.6-79.6-75.3-20.6-152.5 23.9-172.3 99.5L93.5 94.4C82.6 135.9 58.2 172.4 24 198l-11.3 8.5c-5.7 4.3-9.8 10.4-11.6 17.4-4.5 17.1 5.7 34.8 22.8 39.5zm104.4 78.3c2.9 32.7 30.3 58.3 63.8 58.3 12.1 0 23.4-3.4 33.1-9.2 2.3-7 4-14.1 5.1-21.3l-102-27.9zM296.1 478.9l320-87.5c17.1-4.7 27.3-22.4 22.8-39.5-1.8-7-5.9-13.1-11.6-17.4L616 326c-34.1-25.6-58.6-62.1-69.5-103.6l-5.8-21.9C520.9 125 443.8 80.4 368.4 101S248.1 199.6 267.9 275.1l5.8 21.9c10.9 41.5 7.6 85.6-9.4 125.2l-5.6 13.1c-2.8 6.6-3.4 14-1.6 21 4.5 17.1 22 27.2 39.1 22.6zm63.9 32.3c10.9 19.6 31.9 32.9 55.9 32.9 35.3 0 64-28.7 64-64 0-.6 0-1.1 0-1.7L360.1 511.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBells = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;