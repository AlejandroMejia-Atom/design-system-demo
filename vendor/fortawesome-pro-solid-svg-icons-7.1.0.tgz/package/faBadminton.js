'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'badminton';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33a';
var svgPathData = 'M480 380c28.2 0 52.4 20.1 57.6 47.8l18.1 96.5 .3 4c-.2 9.3-6.8 17.5-16.3 19.3-9.5 1.8-18.7-3.5-22.2-12.1l-1.2-3.9-6.7-35.7-9.7 0 0 32c0 11-9 20-20 20-11 0-20-9-20-20l0-32-9.7 0-6.7 35.7c-2 10.8-12.5 18-23.3 16-10.8-2-18-12.5-16-23.3l18.1-96.5 1.2-5.1c7-25 30-42.6 56.4-42.7zM405-15.8c40 1.7 78.8 16.6 108.5 46.3l5.8 6.1C547 67.4 560 106.9 560 147l-.3 10.2c-2.7 51-25.8 103-66.7 143.8-54.4 54.4-131.9 78.6-198.2 61.7-29.4-7.5-62.9-5.5-84.3 16L172.2 417c5.9 11.2 4.9 25.1-3.4 35.2l-2.2 2.4-64 64c-11.7 11.7-30.2 12.4-42.8 2.2l-2.4-2.2-32-32c-12.5-12.5-12.5-32.8 0-45.2l64-64 2.4-2.2c10.1-8.2 24-9.4 35.2-3.5l38.5-38.5c21.4-21.4 23.5-54.7 16-84-3-11.8-4.8-24-5.3-36.2l-.2-8c0-54.2 23.4-110.5 66.9-154S342.8-16 397-16l8 .2zM397 48c-36 0-76.4 15.8-108.8 48.2S240 168.9 240 205l.4 10.4c2.1 23.9 11.4 45 27.3 60.9 40.4 40.4 120.7 39 180.1-20.5 30.4-30.4 46.2-67.7 48-102l.2-6.8c0-28.2-9.6-53.2-27.7-71.3-15.9-15.9-37-25.2-60.9-27.3L397 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBadminton = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;