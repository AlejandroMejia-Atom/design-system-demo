'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'boot';
var width = 448;
var height = 512;
var aliases = [129406];
var unicode = 'f782';
var svgPathData = 'M0 32C0 14.3 14.3 0 32 0L288 0c17.7 0 32 14.3 32 32l0 48c0 17.7-14.3 32-32 32l-72 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l72 0 0 48-72 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l104 0c70.7 0 128 57.3 128 128L0 384 0 32zM0 432l448 0 0 28.7c0 12.4-4.5 24.4-12.7 33.8-9.7 11.1-23.8 17.5-38.6 17.5l-4.7 0c-17.8 0-34.7-7.7-46.4-21.1l-3.5-4c-3.2-3.6-8.9-3.6-12 0l-3.5 4C314.7 504.3 297.8 512 280 512s-34.7-7.7-46.4-21.1l-3.5-4c-3.2-3.6-8.9-3.6-12 0l-3.5 4C202.7 504.3 185.8 512 168 512s-34.7-7.7-46.4-21.1l-3.5-4c-3.2-3.6-8.9-3.6-12 0l-3.5 4C90.7 504.3 73.8 512 56 512l-4.7 0c-14.8 0-28.8-6.4-38.6-17.5-8.2-9.3-12.7-21.3-12.7-33.8L0 432z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoot = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;