'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bell-ring';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e62c';
var svgPathData = 'M112.6 41.4c9.6-9.1 10-24.3 .8-33.9S89-2.5 79.4 6.6C30.5 53.2 0 119.1 0 192 0 205.3 10.7 216 24 216s24-10.7 24-24c0-59.3 24.8-112.7 64.6-150.6zm320-34.8c-9.6-9.1-24.8-8.8-33.9 .8s-8.8 24.8 .8 33.9c39.8 37.9 64.6 91.4 64.6 150.6 0 13.3 10.7 24 24 24s24-10.7 24-24c0-72.9-30.5-138.8-79.4-185.4zM256 0c-17.7 0-32 14.3-32 32l0 3.2C151 50 96 114.6 96 192l0 21.7c0 48.1-16.4 94.8-46.4 132.4l-9.8 12.2c-5 6.3-7.8 14.1-7.8 22.2 0 19.6 15.9 35.5 35.5 35.5l376.9 0c19.6 0 35.5-15.9 35.5-35.5 0-8.1-2.7-15.9-7.8-22.2l-9.8-12.2C432.4 308.5 416 261.8 416 213.7l0-21.7c0-77.4-55-142-128-156.8l0-3.2c0-17.7-14.3-32-32-32zM194 464c7.1 27.6 32.2 48 62 48s54.9-20.4 62-48l-124 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellRing = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;