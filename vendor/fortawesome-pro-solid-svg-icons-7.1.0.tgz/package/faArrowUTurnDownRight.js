'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrow-u-turn-down-right';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e7e8';
var svgPathData = 'M505.3 363.8c10.3 12.6 9.5 31.1-2.2 42.8l-112 112c-12.5 12.5-32.8 12.5-45.2 0s-12.5-32.8 0-45.2l57.4-57.4-210.7 0C89.8 416 5.9 335.3 .8 233.9L.5 224c0-106 86-192 192-192l224 0 3.3 .2c16.1 1.6 28.7 15.3 28.7 31.8s-12.6 30.2-28.7 31.8l-3.3 .2-224 0c-70.7 0-128 57.3-128 128l.2 6.6C68.1 298.2 124 352 192.5 352l210.7 0-57.4-57.4-2.2-2.4c-10.2-12.6-9.5-31.1 2.2-42.8s30.2-12.4 42.8-2.2l2.4 2.2 112 112 2.2 2.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnDownRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;