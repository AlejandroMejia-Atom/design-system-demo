'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrows-rotate-reverse';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e630';
var svgPathData = 'M446.1 228.5c-13.3-93-93.4-164.5-190.1-164.5-53 0-101 21.5-135.8 56.2-.2 .2-.4 .4-.6 .6l-7.6 7.2 47.9 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 192c-17.7 0-32-14.3-32-32L0 32C0 14.3 14.3 0 32 0S64 14.3 64 32l0 53.4 11.3-10.7C121.5 28.6 185.5 0 256 0 385 0 491.7 95.4 509.4 219.5 511.9 237 499.8 253.2 482.3 255.7s-33.7-9.7-36.2-27.1zM2.6 292.5C.1 275 12.2 258.8 29.7 256.3s33.7 9.7 36.2 27.1c13.3 93 93.4 164.5 190.1 164.5 53 0 101-21.5 135.8-56.2 .2-.2 .4-.4 .6-.6l7.6-7.2-47.9 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l128 0c8.5 0 16.7 3.4 22.7 9.5s9.3 14.3 9.3 22.8l-1 127c-.1 17.7-14.6 31.9-32.3 31.7s-31.9-14.6-31.7-32.3l.4-51.5-10.7 10.1C390.5 483.4 326.5 512 256 512 127 512 20.3 416.6 2.6 292.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRotateReverse = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;