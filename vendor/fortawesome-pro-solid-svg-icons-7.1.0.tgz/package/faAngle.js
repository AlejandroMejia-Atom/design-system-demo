'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'angle';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e08c';
var svgPathData = 'M252.6 78.3c7.9-15.8 1.5-35-14.3-42.9s-35-1.5-42.9 14.3l-192 384c-5 9.9-4.4 21.7 1.4 31.1S20.9 480 32 480l384 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L83.8 416 252.6 78.3zm94.9 232.4c-5.6-12.8-21.3-17-33.2-9.7-10.7 6.6-14.4 20.3-9.5 31.9 4.8 11.3 8.9 23 12.3 35.1l49.6 0c-4.7-19.8-11.2-39-19.2-57.3zm-91.4-56c8.2 9.5 22.1 12.3 32.8 5.6 11.9-7.4 15.1-23.4 6.1-34.1-12.7-15.1-26.7-29-41.8-41.7L231 228.9c8.9 8.1 17.3 16.7 25.1 25.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAngle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;