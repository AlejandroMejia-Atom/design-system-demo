'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'banjo';
var width = 512;
var height = 512;
var aliases = [129685];
var unicode = 'f8a3';
var svgPathData = 'M465 7c-9.4-9.4-24.6-9.4-33.9 0L383 55c-2.4 2.4-4.3 5.3-5.5 8.5l-15.4 41-76.1 76.1c-20.6-13.9-44.3-23.4-70-27l0-1.7c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 1.7c-28.5 4.1-54.6 15.3-76.6 31.7l-1.2-1.2c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l1.2 1.2C41 241.4 29.8 267.5 25.7 296L24 296c-13.3 0-24 10.7-24 24s10.7 24 24 24l1.7 0c4.1 28.5 15.3 54.6 31.7 76.6l-1.2 1.2c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l1.2-1.2c22 16.5 48.2 27.7 76.6 31.7l0 1.7c0 13.3 10.7 24 24 24s24-10.7 24-24l0-1.7c28.5-4.1 54.6-15.3 76.6-31.7l1.2 1.2c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-1.2-1.2c16.5-22 27.7-48.2 31.7-76.6l1.7 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-1.7 0c-3.7-25.7-13.1-49.5-27-70l76.1-76.1 41-15.4c3.2-1.2 6.1-3.1 8.5-5.5l48-48c9.4-9.4 9.4-24.6 0-33.9L465 7zM192 208a112 112 0 1 1 0 224 112 112 0 1 1 0-224zm-31 95c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l48 48c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-48-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanjo = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;