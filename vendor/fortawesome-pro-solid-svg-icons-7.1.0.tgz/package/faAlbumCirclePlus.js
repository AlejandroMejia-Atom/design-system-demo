'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'album-circle-plus';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e48c';
var svgPathData = 'M32 96c0-35.3 28.7-64 64-64l320 0c35.3 0 64 28.7 64 64l0 118c-15.3-3.9-31.4-6-48-6-7.8 0-15.4 .5-22.9 1.4-20-65.6-81-113.4-153.1-113.4-88.4 0-160 71.6-160 160 0 83.2 63.5 151.5 144.6 159.3 1.8 23 7.6 44.8 16.8 64.7L96 480c-35.3 0-64-28.7-64-64L32 96zM256 224a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm176 32a144 144 0 1 1 0 288 144 144 0 1 1 0-288zm16 80c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 48-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l48 0 0 48c0 8.8 7.2 16 16 16s16-7.2 16-16l0-48 48 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-48 0 0-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlbumCirclePlus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;