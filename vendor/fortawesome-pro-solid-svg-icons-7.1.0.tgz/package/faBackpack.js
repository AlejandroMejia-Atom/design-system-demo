'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'backpack';
var width = 448;
var height = 512;
var aliases = [127890];
var unicode = 'f5d4';
var svgPathData = 'M184 48l80 0c4.4 0 8 3.6 8 8l0 40-96 0 0-40c0-4.4 3.6-8 8-8zm-56 8l0 40C57.3 96 0 153.3 0 224L0 448c0 35.3 28.7 64 64 64l16 0 0-136c0-39.8 32.2-72 72-72l144 0c39.8 0 72 32.2 72 72l0 136 16 0c35.3 0 64-28.7 64-64l0-224c0-70.7-57.3-128-128-128l0-40c0-30.9-25.1-56-56-56L184 0c-30.9 0-56 25.1-56 56zM320 512l0-136c0-13.3-10.7-24-24-24l-144 0c-13.3 0-24 10.7-24 24l0 136 192 0zM152 176l144 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-144 0c-13.3 0-24-10.7-24-24s10.7-24 24-24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBackpack = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;