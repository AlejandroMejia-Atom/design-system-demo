'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'beer-mug';
var width = 576;
var height = 512;
var aliases = ["beer-foam"];
var unicode = 'e0b3';
var svgPathData = 'M312.8 104.3C298.3 118.9 278.2 128 256 128s-42.3-9.1-56.8-23.7c-8.6-8.7-31.4-9.2-40.7-1.3-12.5 10.6-28.8 17-46.5 17-39.8 0-72-32.2-72-72s32.2-72 72-72c17.7 0 33.9 6.4 46.5 17 9.3 7.9 32.1 7.4 40.7-1.3 14.5-14.6 34.6-23.7 56.8-23.7s42.3 9.1 56.8 23.7c8.6 8.7 31.4 9.2 40.7 1.3 12.5-10.6 28.8-17 46.5-17 39.8 0 72 32.2 72 72s-32.2 72-72 72c-17.7 0-33.9-6.4-46.5-17-9.3-7.9-32.1-7.4-40.7 1.3zM64 416l0-258c14.7 6.4 30.9 10 48 10 24 0 46.4-7.1 65.1-19.2 21.7 17 49.1 27.2 78.9 27.2s57.2-10.2 78.9-27.2c18.8 12.1 41.2 19.2 65.1 19.2 35.5 0 67.5-15.4 89.4-40l22.6 0c35.3 0 64 28.7 64 64l0 108.2c0 24.2-13.7 46.4-35.4 57.2L448 403.8 448 416c0 53-43 96-96 96l-192 0c-53 0-96-43-96-96zm384-83.8l64-32 0-108.2-64 0 0 140.2zM192 248c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 144c0 13.3 10.7 24 24 24s24-10.7 24-24l0-144zm88 0c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 144c0 13.3 10.7 24 24 24s24-10.7 24-24l0-144zm88 0c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 144c0 13.3 10.7 24 24 24s24-10.7 24-24l0-144z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBeerMug = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;