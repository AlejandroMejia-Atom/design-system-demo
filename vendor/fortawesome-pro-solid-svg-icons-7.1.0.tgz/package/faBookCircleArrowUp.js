'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'book-circle-arrow-up';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0bd';
var svgPathData = 'M432 208c16.6 0 32.7 2.1 48 6l0-166c0-26.5-21.5-48-48-48L128 0C75 0 32 43 32 96l0 320c0 53 43 96 96 96l148 0c-13.7-19-24-40.7-30-64l-118 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l112.7 0c8.1-98.6 90.7-176 191.3-176zm-1.5 48a144 144 0 1 0 3 288 144 144 0 1 0 -3-288zM364.7 404c-6.3-6.2-6.4-16.3-.2-22.6l55.4-56.6c6.2-6.3 16.3-6.4 22.6-.2L499.1 380c6.3 6.2 6.4 16.3 .2 22.6s-16.3 6.4-22.6 .2l-29-28.4 .9 89.4c.1 8.8-7 16.1-15.8 16.2s-16.1-7-16.2-15.8l-.9-89.4-28.4 29c-6.2 6.3-16.3 6.4-22.6 .2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookCircleArrowUp = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;