'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrow-u-turn-down-left';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e7e7';
var svgPathData = 'M7.7 363.8c-10.3 12.6-9.5 31.1 2.2 42.8l112 112c12.5 12.5 32.8 12.5 45.2 0s12.5-32.8 0-45.2l-57.4-57.4 210.8 0c102.7 0 186.6-80.7 191.8-182.1l.2-9.9c0-106-86-192-192-192l-224 0-3.3 .2C77.1 33.8 64.5 47.4 64.5 64S77.1 94.2 93.2 95.8l3.3 .2 224 0c70.7 0 128 57.3 128 128l-.2 6.6C444.9 298.2 389 352 320.5 352l-210.8 0 57.4-57.4 2.2-2.4c10.2-12.6 9.5-31.1-2.2-42.8s-30.2-12.4-42.8-2.2l-2.4 2.2-112 112-2.2 2.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnDownLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;