'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bat';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f6b5';
var svgPathData = 'M235.4 49.9l36.8 21c9.8 5.6 21.9 5.6 31.8 0l36.8-21c2.2-1.3 4.7-1.9 7.2-1.9 7 0 13.1 5 14.4 11.9l18.6 99.3 71.8-34.2c16.2-7.7 35.5-3.6 47.1 10 49.2 57.4 76.3 130.6 76.3 206.2l0 37.6c0 9.7-10.2 16-18.9 11.7l-63.8-31.9c-7.5-3.7-16.6-1.1-20.9 6.1l-29.8 49.7c-5.4 8.9-17.7 10.4-25 3.1l-36.6-36.6c-6.8-6.8-18.1-6.1-24 1.6l-56.2 73.1c-6.4 8.3-19 8.3-25.4 0l-56.2-73.1c-5.9-7.7-17.2-8.4-24-1.6l-36.6 36.6c-7.4 7.4-19.7 5.8-25-3.1l-29.8-49.7c-4.3-7.2-13.4-9.8-20.9-6.1L18.9 390.5c-8.7 4.3-18.9-2-18.9-11.7l0-37.6c0-75.6 27.1-148.8 76.3-206.2 11.6-13.6 30.9-17.7 47.1-10l71.8 34.2 18.6-99.3c1.3-6.9 7.3-11.9 14.4-11.9 2.5 0 5 .7 7.2 1.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBat = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;