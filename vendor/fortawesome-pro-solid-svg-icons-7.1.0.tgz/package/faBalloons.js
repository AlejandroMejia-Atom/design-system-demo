'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'balloons';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e2e4';
var svgPathData = 'M320 160C320 71.6 248.4 0 160 0S0 71.6 0 160C0 272 128 368 128 368l-27.9 41.8c-2.7 4-4.1 8.8-4.1 13.6 0 13.6 11 24.6 24.6 24.6l78.9 0c13.6 0 24.6-11 24.6-24.6 0-4.8-1.4-9.6-4.1-13.6L192 368s128-96 128-208zM144 104c-22.1 0-40 17.9-40 40 0 13.3-10.7 24-24 24s-24-10.7-24-24c0-48.6 39.4-88 88-88 13.3 0 24 10.7 24 24s-10.7 24-24 24zM384 432l-27.9 41.8c-2.7 4-4.1 8.8-4.1 13.6 0 13.6 11 24.6 24.6 24.6l78.9 0c13.6 0 24.6-11 24.6-24.6 0-4.8-1.4-9.6-4.1-13.6L448 432s128-96 128-208c0-88.4-71.6-160-160-160-23.1 0-45.1 4.9-64.9 13.7 6.7 15.6 11.6 32.1 14.3 49.3 10.6-4.5 22.3-7.1 34.6-7.1 13.3 0 24 10.7 24 24s-10.7 24-24 24c-14.2 0-26.7 7.4-33.8 18.6-6.6 49.8-30.8 93.6-54.9 126.6-5.7 7.8-11.5 15.2-17.3 22.2 37.7 57.5 90 96.7 90 96.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBalloons = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;