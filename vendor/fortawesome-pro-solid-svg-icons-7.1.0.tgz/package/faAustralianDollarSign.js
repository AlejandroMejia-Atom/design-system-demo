'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'australian-dollar-sign';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6fe';
var svgPathData = 'M408 16c13.3 0 24 10.7 24 24l0 24 16 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-48.9 0c-26 0-47.1 21.1-47.1 47.1 0 22.5 15.9 41.8 37.9 46.2l32.8 6.6c51.9 10.4 89.3 56 89.3 109 0 50.6-33.8 93.3-80 106.7l0 28.4c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-24-48 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64.9 0c26 0 47.1-21.1 47.1-47.1 0-22.5-15.9-41.8-37.9-46.2l-32.8-6.6c-51.9-10.4-89.3-56-89.3-109 0-56.2 41.8-102.7 96-110.1l0-25c0-13.3 10.7-24 24-24zM128 184.1l-32.5 135.9 65 0-32.5-135.9zm64.9 271.3l-17.1-71.4-95.6 0-17.1 71.4c-4.1 17.2-21.4 27.8-38.6 23.7S-3.2 457.7 .9 440.6L87 80.3c4.5-19 21.5-32.3 41-32.3s36.4 13.4 41 32.3l86.1 360.2c4.1 17.2-6.5 34.5-23.7 38.6s-34.5-6.5-38.6-23.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAustralianDollarSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;