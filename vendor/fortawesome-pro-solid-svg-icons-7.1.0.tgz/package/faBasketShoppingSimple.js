'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'basket-shopping-simple';
var width = 576;
var height = 512;
var aliases = ["shopping-basket-alt"];
var unicode = 'e0af';
var svgPathData = 'M305.4 7.5C300.9 2.7 294.6 0 288 0s-12.9 2.7-17.4 7.5l-144 152-.5 .5-78.1 0c-17.7 0-32 14.3-32 32 0 14.5 9.6 26.7 22.8 30.7l46 207.2c6.5 29.3 32.5 50.1 62.5 50.1l281.3 0c30 0 56-20.8 62.5-50.1l46.1-207.2c13.2-3.9 22.8-16.2 22.8-30.7 0-17.7-14.3-32-32-32l-78.1 0-.5-.5-144-152zM383.8 160L192.2 160 288 58.9 383.8 160zM128 264a24 24 0 1 1 48 0 24 24 0 1 1 -48 0zm296-24a24 24 0 1 1 0 48 24 24 0 1 1 0-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBasketShoppingSimple = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;