'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'album-circle-user';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e48d';
var svgPathData = 'M32 96c0-35.3 28.7-64 64-64l320 0c35.3 0 64 28.7 64 64l0 118c-15.3-3.9-31.4-6-48-6-7.8 0-15.4 .5-22.9 1.4-20-65.6-81-113.4-153.1-113.4-88.4 0-160 71.6-160 160 0 83.2 63.5 151.5 144.6 159.3 1.8 23 7.6 44.8 16.8 64.7L96 480c-35.3 0-64-28.7-64-64L32 96zM256 224a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm32 176a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm221.7 80.7c-6.2-19-24-32.7-45.1-32.7l-65.2 0c-21 0-38.9 13.7-45.1 32.7 20.1 19.4 47.5 31.3 77.7 31.3s57.5-11.9 77.7-31.3zM480 368a48 48 0 1 0 -96 0 48 48 0 1 0 96 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlbumCircleUser = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;