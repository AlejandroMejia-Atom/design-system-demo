'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrow-rotate-left-10';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e836';
var svgPathData = 'M256 0C397.4 0 512 114.6 512 256S397.4 512 256 512c-87 0-163.9-43.4-210.1-109.7-10.1-14.5-6.6-34.5 7.9-44.6s34.5-6.6 44.6 7.9c34.7 49.8 92.4 82.3 157.6 82.3 106 0 192-86 192-192S362 64 256 64c-69.8 0-130.9 37.2-164.6 93.1l-.1 .2-.1 .2-32 51.4c-7.5 12.1-22.2 17.8-36 13.9S0 206.3 0 192L0 32C0 14.3 14.3 0 32 0S64 14.3 64 32l0 54.7C110.9 33.6 179.5 0 256 0zM173.3 162.5c7.4-3.7 16.3-3.3 23.3 1.1S208 175.7 208 184l0 144c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-105.4c-11.3 4-24-.9-29.5-11.8-5.9-11.9-1.1-26.3 10.8-32.2l32-16zM312 160c30.9 0 56 25.1 56 56l0 80c0 30.9-25.1 56-56 56l-16 0c-30.9 0-56-25.1-56-56l0-80c0-30.9 25.1-56 56-56l16 0zm-16 48c-4.4 0-8 3.6-8 8l0 80c0 4.4 3.6 8 8 8l16 0c4.4 0 8-3.6 8-8l0-80c0-4.4-3.6-8-8-8l-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateLeft10 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;