'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'border-bottom';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f84d';
var svgPathData = 'M448 448c0 17.7-14.3 32-32 32L32 480c-17.7 0-32-14.3-32-32s14.3-32 32-32l384 0c17.7 0 32 14.3 32 32zM384 320a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM64 320a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM384 192a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM64 192a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM384 64a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM64 64A32 32 0 1 1 0 64 32 32 0 1 1 64 64zm192 0a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm-64 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBorderBottom = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;