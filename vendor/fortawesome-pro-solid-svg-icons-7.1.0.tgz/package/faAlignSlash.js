'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'align-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f846';
var svgPathData = 'M41-24.9c-9.4-9.4-24.6-9.4-33.9 0S-2.3-.3 7 9.1l528 528c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L417.8 352 480 352c17.7 0 32-14.3 32-32s-14.3-32-32-32l-126.2 0-64-64 190.2 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-254.2 0-64-64 318.2 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L97.8 32 41-24.9zM218.2 288L96 288c-17.7 0-32 14.3-32 32s14.3 32 32 32l186.2 0-64-64zM90.6 160.4C75.5 163 64 176.2 64 192 64 209.7 78.3 224 96 224l58.2 0-63.6-63.6zM346.2 416L96 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l314.2 0-64-64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlignSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;