'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bag-seedling';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e5f2';
var svgPathData = 'M32 64L6.6 38.6C2.4 34.4 0 28.6 0 22.6 0 10.1 10.1 0 22.6 0L425.4 0c12.5 0 22.6 10.1 22.6 22.6 0 6-2.4 11.8-6.6 16L416 64 434.6 138.5c8.9 35.5 13.4 72 13.4 108.7l0 17.7c0 36.6-4.5 73.1-13.4 108.7L416 448 441.4 473.4c4.2 4.2 6.6 10 6.6 16 0 12.5-10.1 22.6-22.6 22.6L22.6 512c-12.5 0-22.6-10.1-22.6-22.6 0-6 2.4-11.8 6.6-16L32 448 13.4 373.5C4.5 338 0 301.5 0 264.8l0-17.7C0 210.5 4.5 174 13.4 138.5L32 64zm80 96c-8.8 0-16 7.2-16 16 0 59.2 45.9 107.6 104 111.7l0 40.3c0 13.3 10.7 24 24 24s24-10.7 24-24l0-40.3c58.1-4.1 104-52.6 104-111.7 0-8.8-7.2-16-16-16l-2 0c-47.3 0-88.4 26-110 64.5-21.6-38.5-62.7-64.5-110-64.5l-2 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBagSeedling = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;