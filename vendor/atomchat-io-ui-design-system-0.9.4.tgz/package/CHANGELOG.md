# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.9.4] - 2026-06-22

### Fixed (0.9.4)

- **Select panel (`atom-select-panel`)** — setting `[multiple]="false"` on the panel no longer triggers a false-positive immutability warning in development mode. The `multiple` value is now frozen after the first render so the initial template binding is correctly treated as the starting value, not a runtime change.

## [0.9.3] - 2026-06-22

### Fixed (0.9.3)

- **Select panel (`atom-select-input`)** — opening the panel when a value is already selected now scrolls the list to the selected item and highlights it. Previously this worked only when options were projected directly; grouped and data-driven option lists now behave the same way.
- **Rich text variable chip** — clicking a `{{variable}}` chip to swap it now opens the picker with the current variable already highlighted and centered in the list.
- **Snackbar (`atom-snackbar`)** — showing a toast no longer throws a `HierarchyRequestError` in the console. The snackbar element carried an explicit `aria-live` attribute that Angular Material's internal announce logic mistook for its own live region, causing it to try to move a node into its own descendant. The live-region semantics now come from `role="status"` / `role="alert"` instead, preserving screen-reader announcements without the conflict.

## [0.9.2] - 2026-06-22

### Fixed (0.9.2)

- **Filter chips (`atom-filter-chip`)** — chip colors are now applied correctly when the library is used alongside an app that has its own Angular Material theme. Previously, the app's primary palette could override the chip's background, text and × button colors; the theme override now targets the chip element directly with higher specificity so it always wins.

## [0.9.1] - 2026-06-22

### Fixed (0.9.1)

- **Filter chips (`atom-filter-chip`)** — chip background, label and × button colors now render correctly when the library is installed in a project that has its own Angular Material theme. The consumer app's primary palette was overriding our color tokens; the theme integration now uses sufficiently specific selectors to always win regardless of the host application's theme setup.

## [0.9.0] - 2026-06-22

### Added (0.9.0)

- **Alerts (`atom-alert`)** — new notification component that stays on screen until manually dismissed. Available in five types (info, success, warning, error, AI) and two layouts: inline (embedded in the page with a border) and wide (full-width banner shown programmatically via a service). Includes optional slots for icon, title, description and action buttons. The dismiss label can be localized.
- **Rich text editor (`atom-rich-text`)** — new formatted text field with bold, italic and strikethrough support. Works with Angular reactive forms and integrates with `atom-form-field`. Available in two sizes. Single-line mode disables Enter and hides the action bar. Full undo/redo support via Ctrl+Z / Ctrl+Y — typing a space creates a word-level checkpoint so each undo step undoes one word.
- **Variables in rich text** — insert `{{variable}}` chips in the editor via the action button or by typing `/`. Click an existing chip to swap its value; click × to remove it. Supports grouped option lists.
- **Time picker (`atom-time-picker`)** — new time input that opens a dropdown with preset options. Supports 12h/24h formats, configurable preset intervals and min/max constraints. The input enforces a live mask so only valid time characters can be typed. Labels are localizable.
- **Grouped options in selects** — `atom-select-panel` and `atom-select-input` now support grouped option lists via a `groups` input. Groups collapse and expand on click; search automatically opens groups with matching results and restores the previous state when the filter clears.
- **Collapsible option groups (`atom-select-group`)** — standalone collapsible group header for use inside a select panel. Groups don't render their options until first opened, keeping large lists performant. Groups hide automatically when search returns no matches.
- **Custom select trigger** — replace `atom-select-input`'s default field with any element (e.g. a chip) by marking it with `[atomSelectTrigger]`.
- **Open panel at position** — `atom-select-input` and any dropdown trigger now support `.openAt(position)` to anchor the panel at an arbitrary location, useful for caret-positioned pickers inside a rich text editor.

### Changed (0.9.0)

- **`atom-select-panel`** — row visibility during search is now reactive, enabling grouped containers to correctly show and hide empty groups.

### Fixed (0.9.0)

- **Select panel** — fixed an error that occurred when option rows created with `@for` were projected before their bindings had finished initializing.
- **Filter chips (`atom-filter-chip`)** — applied filter chips now show the correct brand colors (peach background, orange text and × button) across all states. The Material theme integration has been restructured so normal, focused and disabled states all render as designed.
- **Filter panel** — opening a category that has no selections now correctly highlights it so it is clear which category is being viewed.

## [0.8.4] - 2026-06-22

### Fixed (0.8.4)

- **`atom-filter-chip`** — label color now applies correctly in both states. Material targets the inner text-label element directly via `--mat-chip-label-text-color` (not applied) and `--mat-chip-selected-label-text-color` (applied), bypassing inherited color. Both tokens are now declared at the chip level so Material's own rules resolve to the design tokens for each state.
- **`atom-select-panel`** — `setSelection` now seeds the store with label-value pairs from `items[]` before applying the selection, so `selectedLabels` returns correct values immediately without waiting for `wireDirectiveSync` to run after the first render.

## [0.8.3] - 2026-06-22

### Fixed (0.8.3)

- **`atom-filter-panel`** — filter chips now show the correct human-readable labels for initial CVA values without requiring the user to open the panel first. The fix has three layers: `selectedLabels` on `atom-select-panel` is now reactive to `items()` so labels resolve as soon as the items array is bound; `atom-filter-panel` creates a hidden embedded view for categories with initial values when the right-column portal outlets aren't available yet (overlay closed), so `atom-select-panel` can register and populate labels immediately; and `resolveLabelsSync` is available as a synchronous fallback on `FilterPanelRegisteredPanel` for custom panel implementations.
- **`atom-filter-chip`** — foreground color of applied filter chips is now correctly enforced, fixing cases where the chip label rendered in the wrong color when driven by the Material theme.

## [0.8.2] - 2026-06-19

### Added (0.8.2)

- **`AtomListItemLeadingDirective` / `AtomListItemTrailingDirective`** — Angular directives (`[atomListItemLeading]`, `[atomListItemTrailing]`) for projecting content into `atom-list-item` slots. Both work alongside the existing plain attribute form (`[leading]` / `[trailing]`). Each directive adds the corresponding slot attribute and BEM class to the projected element, making IDE autocomplete and explicit Angular bindings available. Icon sizing via the icon-slot mixin covers both direct use on a `fa-icon` / `mat-icon` element and use on a wrapper that contains one. Exported from the public API.

### Changed (0.8.2)

- **`atom-dropdown-menu`** — the items container is now always scrollable and capped at a sensible default height (`--dropdown-menu-max-height`, ≈ 300 px). Previously the menu grew without limit unless the consumer passed `[maxHeight]`. The input still works as a per-instance override.

### Fixed (0.8.2)

- **`atom-filter-panel`** — opening a category that has no selections applied now correctly highlights it with the neutral grey background. The background was being reset to white by an internal `atom-select-panel--multiple` rule; the fix overrides the relevant tokens at the left-column scope so the active state is always visible.
- **`atom-dropdown-menu`** — clicking a menu item now closes the overlay automatically. Items that use checkbox selection keep the menu open so users can pick multiple values before dismissing.
- **`atom-dropdown-menu`** — a long title no longer leaks a clipped line of text below the ellipsis. The fix switches to single-line truncation so only the visible line is ever rendered.
- **`atom-filter-chip`** — selected filter chips now render with the correct background and stroke when driven by the Material theme.
- **`atom-tag`** — icon-only and dot-only tags no longer carry a phantom trailing gap caused by an empty label span remaining in the flex layout.
- **`atom-button`** — when a button enters the loading state, icons on both the leading and trailing slots are hidden so they do not create unexpected whitespace next to the spinner.
- **`atom-tag` icon slot** — `fa-icon` and `mat-icon` projected into the icon slot were not sized or aligned correctly. Applying the shared `icon-slot` mixin fixes the layout so both icon types render at the right dimensions across all tag sizes.

## [0.8.1] - 2026-06-18

### Fixed (0.8.1)

- **`atom-table` sort header** — idle sort icon is hidden (`visibility: hidden`) until the pointer hovers the header cell (or the cell receives focus within), preserving the button footprint so the column does not shift; the icon stays visible while the column is actively sorted. Coarse-pointer / touch devices keep the icon rendered because `:hover` is unreliable there.
- **`atom-search-input` — implements `ControlValueAccessor`**: bind `formControlName` / `[formControl]` on the host without manual `[value]` + `(valueChange)` wiring. The bound `FormControl` and the `valueChange` output share the same debounced commit path (`debounce` input, 300 ms default; synchronous when `debounce <= 0`); Enter and clear commit immediately. `FormControl.disable()` propagates to the native input via `setDisabledState`.
- **`atom-dropdown-menu` (IV-1249)** — a long projected title no longer leaks a clipped overflow line below the ellipsis. The title combined `-webkit-line-clamp: 1` with `padding` on the same element, so `overflow: hidden` clipped at the padding box and a wrapped line bled into the bottom padding. Switched to single-line truncation via the `text-truncate-single-line` mixin (`white-space: nowrap`) and added `user-select: none` so a double-click word-select no longer scrolls the truncated overflow into view.

## [0.8.0] - 2026-06-12

### Added (0.8.0)

- **`AtomTextTruncateDirective`** (`[atomTextTruncate]`) — migrated from `@atomchat-io/ui-utils`. Applies single-line truncation via the `text-truncate-single-line` SCSS mixin and shows a plain DS tooltip only when the text is actually clipped. Replaces the `MatTooltip` dependency with the DS tooltip system. Accepts `atomTruncateTooltip` (explicit label), `atomTruncateTooltipDisabled`, and `tooltipPosition` (forwarded from `AtomTooltipTriggerDirective`).

### Fixed (0.8.0)

- **NG3001 — internal host-directive classes not exported** — `0.7.0` was published with broken partial compilation: `AtomFormFieldMessageIconHostDirective`, `AtomSelectPanelFacadeInitDirective`, `AtomSelectPanelSelectionHostDirective`, `AtomSelectPanelFocusHostDirective`, `AtomSelectPanelDevGuardsHostDirective`, and `AtomSelectPanelFilterCategoryHostDirective` were missing from the library entrypoint. All six are now re-exported with `@internal`.
- **Package version** — `0.7.0` → `0.8.0`.

## [0.7.0] - 2026-06-12

> ⚠️ This release was yanked — it fails to build in partial compilation mode due to NG3001 errors on internal host-directive classes. Upgrade to **0.8.0**.

### Added (0.7.0)

- **`atom-date-picker` / `atom-date-range-picker`** (HU-037) — self-contained date controls that
  encapsulate Angular Material's datepicker behind `atom-*` wrappers (no `mat-*` selector in
  consumer code). Both implement the `AtomFormFieldControl` contract for `atom-form-field`,
  `ControlValueAccessor` (`Date | null` single / `DateRange<Date>` range) and `Validator`
  (Atom-namespaced `atomDatepickerParse`, `atomDatepickerMin`, `atomDatepickerMax`,
  `atomEndDateInvalid` surface on the consumer control). Inputs: `size`, `disabled`, `min`, `max`; output: `dateChange`
  (committed value). The dropdown panel anchors to the field's left edge, drills up
  Days → Months → Years from the period button, marks today with a dot indicator, paints range
  selections as connected blocks, and commits only through the Aplicar/Cancelar footer.
- **`AtomDatepickerIntl`** — single i18n surface (extends `MatDatepickerIntl`, bridged internally)
  with English defaults plus `cancelLabel`, `applyLabel` and `dateFormatPlaceholder` (derived from
  the active date formats, never hardcoded).
- **`ATOM_DATE_FORMATS` / `ATOM_DATE_FORMATS_DEFAULT`** — date-format token (alias of Material's)
  with a NativeDateAdapter-based default; the pickers are self-sufficient without global
  providers, and a consumer-provided global `DateAdapter`/format always wins.
- **`doubleCalendar` on `atom-date-range-picker`** — opt-in dual-month panel: two calendars in
  lockstep (right = left + 1) so ranges can be picked across month boundaries without navigating.
  Outer chevrons move both months (`<`/`>` ±1 month, `<<`/`>>` ±1 year), month/year captions are
  static (no drill-up in the double view), and CVA value, validation and the Aplicar/Cancelar
  commit semantics are identical to the single panel.
- **Advanced wrappers exported**: `AtomDatePickerPanelComponent`,
  `AtomDateRangePickerPanelComponent`, `AtomDateRangeDoubleCalendarPanelComponent`,
  `AtomDatePickerInputDirective`,
  `AtomDateRangeInputComponent`, `AtomDateRangeStartDirective`, `AtomDateRangeEndDirective`,
  `AtomDatepickerActionsComponent`, `AtomDatePickerApplyDirective`,
  `AtomDatePickerCancelDirective`, `ATOM_DATE_PICKER_PANEL`.
- **`--picker-*` component token layer** (`theme/components/_picker.scss`) mapping the Figma
  `picker/*` collection to semantic tokens, plus `_am-datepicker.scss` Material overrides scoped
  under the Atom panel marker class.
- **`AtomSelectPanelVirtualValueRegistry`** — internal registry that lets `atom-select-panel` track `atomSelectValue` directives rendered inside virtual-scroll rows. `AtomSelectValueDirective` auto-registers with it when projected into a virtual context, so selection state stays in sync even when rows are recycled by the CDK viewport.
- **`tryReadAtomSelectValue`** — safe read util for `atomSelectValue` that defers until required inputs have bound, preventing `NG0950` errors when projected `@for` rows mount in the same change-detection pass as the panel.
- **`atom-form-field` — built-in default message icons** — support and validation slots now render a DS icon automatically when the consumer does not project a `fa-icon` or `mat-icon`. The icon is sized via CSS and shared through a new `AtomFormFieldMessageIconHostDirective` host directive. Introduces four internal helpers:
  - `AtomFormFieldMessageIconHostDirective` — host directive applied to support and validation components to detect projected icons and apply the default when none is present.
  - `AtomFormFieldMessageTemplate` — shared inline template that renders the default icon inside the message slot.
  - `formFieldMessageId` — stable ID utility for `aria-describedby` wiring on message elements.
  - `formFieldMessageProjectedIcon` — helper that queries the slot for a projected icon and returns it or `null`.

### Changed (0.7.0)

- **`AtomFormFieldSupportComponent`** (formerly `AtomFormFieldSupportDirective`) — class and file renamed to reflect that this is an Angular `@Component`, not a `@Directive`. Moved from `directives/` to `components/` inside the `form-field` package. The old name is re-exported as a deprecated alias for backward compatibility.
- **`AtomFormFieldValidationComponent`** (formerly `AtomFormFieldValidationDirective`) — same rename and relocation as above.
- **Peer dependency** — `@atomchat-io/ui-utils` bumped to `0.3.0` (adds `resolveObjectPath`).
- **Package version** — `0.6.0` → `0.7.0`.

### Fixed (0.7.0)

- **`atom-select-panel` — selection sync and single-close** — guarded `atomSelectValue` reads so they defer until required inputs bind (prevents `NG0950`); seeds the selection store from both array and virtual data on open; always wires `itemClick` regardless of render mode; emits `closed` on single-select when the panel is not inline.

## [0.6.0] - 2026-06-09

### Added (0.6.0)

- **`atom-table-builder`** — high-level declarative table component for common data-display flows. Accepts a `columns` configuration array and a `dataSource` instead of requiring manual CDK column-def boilerplate.

  Key inputs:
  - `[columns]` (`AtomTableColumn<T>[]`, required) — column configuration array. Each entry describes the column id, header label, value accessor, optional formatter (`text` | `number` | `currency` | `date` | `custom`), sort, sticky pinning, and width.
  - `[dataSource]` (`AtomTableDataSource<T> | T[]`, required) — plain arrays are wrapped in `AtomTableDataSource` automatically.
  - `[atomTrackBy]` (`TrackByFunction<T>`, required) — forwarded to CDK's `trackBy` for stable DOM recycling across sort, filter and pagination cycles.
  - `[selectable]` — enables row-selection styling and pointer cursor.
  - `[multiple]` — when `true` (default), activates multi-row checkbox selection via `atom-table-selection-column`.
  - `[maxSelection]` — caps the number of simultaneously selected rows.

  Column configuration (`AtomTableColumn<T>`):
  - `columnType` — automatic cell formatter and alignment (`text` → start, `number`/`currency` → end).
  - `sortable` — renders an `[atomSortHeader]` on the header cell; sort is handled internally.
  - `defaultSort: 'asc' | 'desc'` — sets this column as the initial active sort. Only one column should define this.
  - `cellTpl` — full `TemplateRef<AtomCellContext<T>>` override for custom cell rendering.
  - `headerTpl` — `TemplateRef<void>` override for the header cell.
  - `sticky` / `stickyEnd` — pins the column to the left or right edge.
  - `width` — CSS width hint (e.g. `'120px'`, `'15%'`).
  - Per-column format overrides: `numberFormat`, `currencyCode`, `currencyDisplay`, `dateFormat`, `locale`.

  Outputs: `rowClick` (emits the clicked row object), `selectionChange` (emits the current selection array).

  Pipe utilities exported from the public API: `AtomTableCellRenderPipe`, `AtomTableAlignPipe`, `AtomTableCellValuePipe`.

- **`AtomTableColumn<T>` and `AtomCellContext<T>`** — type interfaces for column configuration and cell template context, exported from the design-system public API.
- **`atom-form-field`** — structural wrapper for label + control + support/validation/counter. Projects any control that implements the `AtomFormFieldControl` contract (`controlId`, `size`, `disabled`, `hasValue`, `hasError`, `touched`, `pristine`, `valueLength`, `maxLength`, `setDescribedByIds`). Includes `AtomFormFieldRootDirective` (message visibility algorithm), `AtomFormFieldLabelDirective`, `AtomFormFieldSupportDirective`, `AtomFormFieldValidationDirective`, and `AtomFormFieldCounterComponent`. Size is inherited from the projected control; structure typography escalates only at `xl` per Figma.
- **`AtomFormFieldControl`** — abstract DI token exported from the public API so custom controls can integrate with `atom-form-field`.
- **`AtomTextFieldTrailingDirective`** — trailing enhancer slot for `atom-text-field` (symmetric with leading).
- **Form-field theme tokens** — `_form-field.scss` with label, support, validation, and counter aliases; shared **`_form-control.mixins.scss`** and **`_text-field-container.mixins.scss`** for control-shell sizing.
- **`atom-select-panel[atomSelectSearch]` — `managePanelEmptyState` input** — when `false`, the search directive stops driving the panel empty branch so hosts that filter projected options themselves (e.g. `atom-select-input`) do not flash a false “no results” state.
- **Select-input loading tokens** (Figma 5913:13990) — `--select-input-loading-panel-height` (256px), spinner color, caption typography (`labelSmall`), and gap between spinner and caption.

### Changed (0.6.0)

- **`atom-table` — `atomTrackBy` input** — new `[atomTrackBy]` signal input (`TrackByFunction<T>`) forwarded to CDK table's `trackBy` setter via an `effect`. The alias avoids property collision with CDK's own `trackBy` setter; consumers of `atom-table` should migrate from `[trackBy]` to `[atomTrackBy]`.

- **`atom-data-layout` — auto-detects `atom-table-builder` column count for skeleton rows** — `atom-data-layout` now queries `atom-table-builder` as a `contentChild`. When the layout is in `loading` state and no manual CDK column defs are projected, it reads `builder.columns().length` to generate the correct number of skeleton columns. A dev-mode warning is emitted when both a manual `atom-table` and an `atom-table-builder` are projected simultaneously, as they are mutually exclusive.

- **`atom-text-field`** — reduced to a pure input control. Label, support, validation, and counter now live in `atom-form-field`. Default size is `m` (was `xs`). Implements `AtomFormFieldControl` and coordinates `aria-describedby` with the wrapper.
- **`atom-text-area`** — multiline variant on the shared `atom-text-field` host; same `atom-form-field` composition and `AtomFormFieldControl` contract as single-line text-field. Visual-state previews use `text-field-visual-state` helpers.
- **`atom-select-input`** — implements `AtomFormFieldControl`; trigger shell is an `atom-button="secondary"` with BEM host modifiers (`--opened`, `--error-*`, size variants) instead of `data-state` / `data-size`. Loading panel applies `atom-select-input__panel--loading` on the CDK overlay and lifts body `max-height` while fetching.
- **`atom-select-input` public types** — `AtomSelectInputSize` and `AtomSelectInputState` removed; size is `AtomFormFieldSize`. Preview matrices use `ATOM_SELECT_INPUT_STATES` + `atomSelectInputPreviewClasses`.
- **`AtomSelectLoadingCaptionDirective`** — colocated in `atom-select-value.directive.ts` (barrel re-exports unchanged).
- **Peer dependency** — `@atomchat-io/ui-tokens` bumped to `^0.2.5`.
- **Package version** — `0.5.1` → `0.6.0`.

> **Breaking — text-field / text-area composition**
>
> Remove `AtomTextFieldRootDirective`, `AtomTextFieldLabelDirective`, `AtomTextFieldSupportDirective`, and `AtomTextFieldValidationDirective` from imports. Wrap controls in `atom-form-field` and move slots to `atomFormFieldLabel` / `atomFormFieldSupport` / `atomFormFieldValidation`. Applies to both `atom-text-field` and `atom-text-area`.
>
> **Breaking — select-input composition**
>
> Same wrapper pattern as text-field. Drop direct label/support projection on the select; use `atom-form-field` slots. Replace any reliance on `AtomSelectInputSize` / `AtomSelectInputState` with `AtomFormFieldSize` and BEM preview helpers.

### Fixed (0.6.0)

- **`atom-select-input` reactive forms** — `syncWithNgControl()` pulls invalid/touched/pristine on init before subscribing to `statusChanges`, so controls that start invalid/touched (e.g. `markAllAsTouched()` before render) show error styling immediately.
- **`atom-select-input` search** — filtering works again inside the combobox panel (`managePanelEmptyState="false"` + host-owned `isEmpty`).
- **`atom-select-input` loading** — panel matches design: fixed 256px height, centered XL (32px) spinner with `fg-primary`, `labelSmall` caption in `fg-tertiary`, 8px gap (IV-1071 / Figma 5913:13990).
- **`atom-select-panel`** — body stays mounted across search-driven empty transitions (`[hidden]` instead of unmounting projected items).

### Refactored (0.6.0)

- **Form-field layout** — removed monolithic `_form-field-layout.mixins.scss`; split into `_form-control.mixins.scss`, `_text-field-container.mixins.scss`, and component-scoped form-field styles aligned to Figma structure tokens.
- **`atom-text-field` styles** — flattened host shell; visual-state preview via `text-field-visual-state` helpers (consistent with select-input).
- **`atom-select-input` styles** — trigger appearance driven by BEM host classes + `atom-button` secondary shell; panel modifiers (`--multiple`, `--loading`) on the CDK overlay pane.

## [0.5.1] - 2026-06-09

### Fixed (0.5.1)

- **Public API — table** — export `AtomSortDirective`, `AtomTableSelectionColumnComponent`, and related selection helpers (`AtomTableSelectionController`, `ATOM_TABLE_SELECTION`, `ATOM_TABLE_SELECTION_COLUMN`, `prependAtomTableSelectionColumn`, `AtomTableSelectionMode`) from `@atomchat-io/ui-design-system`. `ATOM_TABLE_IMPORTS` already referenced these symbols in the compiled bundle, but they were missing from the package entry-point `export { … }`, which caused Angular NG3004 in downstream apps (`Unable to import directive AtomSortDirective` / `component AtomTableSelectionColumnComponent`). Consumers can remove `postinstall` patches that manually edited `index.d.ts` or FESM.

## [0.5.0] - 2026-06-08

### Added (0.5.0)

- **`atom-filter-panel`** — two-column selection panel for filter flows. The left column lists filter categories; the right shows the matching `atom-select-panel` for the active one. Add `atomFilterCategory` to each `atom-list-item` and the panel auto-registers them — no manual wiring. Exposes `activateCategory()`, `clear()`, and `clearAll()` methods, plus `selectedCount` and `totalCount` signals. Keyboard navigable, fully ARIA-labelled, and localizable via `AtomFilterPanelIntl`. Works out of the box with `[atomDropdownTriggerFor]`.

- **`atom-filter`** — top-level filtering organism that orchestrates `atom-filter-row` and `atom-filter-panel`. Place a `button[atom-filter-trigger]` inside it: the organism handles open/close, generates applied-filter chips per category, and emits `opened`, `closed`, `allCleared`, and `categoryCleared`. Set `[showChips]="false"` for a compact trigger-and-badge layout. **Categories must be declared statically** — `@for` / `@if` in the panel slot is not supported.

- **Filter Chips (`atom-filter-row`, `atom-filter-chip`, `AtomFilterChipLabelsDirective`)** — display and manage applied filters in a horizontal scrollable chip list. Each chip shows up to 3 selected values inline; more appear as a `+N` badge. Includes a trigger button with auto-badge and an optional "Clear all" button. Arrow-key navigation between chips, 5 sizes (`xs`–`xl`), and localizable via `ATOM_FILTER_ROW_CLEAR_LABEL` / `ATOM_FILTER_ROW_ARIA_LABEL`.

- **`atom-snackbar`** — programmatic toast notifications via `AtomSnackbarService`. Four semantic variants (`info`, `success`, `warning`, `error`) with an optional action button. Toasts stack from the bottom; rapid calls stagger to avoid visual jumps. Includes enter/exit animations that respect `prefers-reduced-motion`. The headline and body use `<h6>` / `<p>` for correct accessibility semantics.

- **`atom-toolbar`** — horizontal action bar with `primary`, `secondary`, and `tertiary` button slots. Inherits size automatically from a parent `atom-data-layout`; defaults to `s` when used standalone. Only `secondary` and `tertiary` buttons are permitted in the `nested-actions` slot.

- **`atom-data-layout`** — full-page data management organism that composes a toolbar, table, and paginator into a single container. Declare `[atomDataLayoutState]` to switch between `loading`, `empty`, `no-data`, `error`, and `populated` body states — no `@if` chains required. The table header is always sticky inside this container.

- **`atom-table`** — production-ready CDK data table:
  - **Row selection** — checkbox column with master-toggle, per-row disable support, and an `atomSelectionChange` output.
  - **Sorting** — `[atomSortHeader]` column directive; re-clicking cycles through ascending, descending, and unsorted.
  - **Data source** — `AtomTableDataSource<T>` bridges to Angular Material's paginator and keeps page state in sync automatically.
  - **Cells** — `AtomCellComponent` handles text overflow with line clamping, and aligns rows that mix text, buttons, and inputs.
  - Always sticky inside `atom-data-layout`.

- **`atom-pagination`** — navigation bar with previous/next buttons, a page-range selector, and an optional page-size picker. All controls are disabled when `length = 0`. Warns in dev mode if `pageSize` is not listed in `pageSizeOptions`. Fully localizable via `AtomPaginationIntl`.

- **`atom-section-heading`** — page-section title bar with an optional back button. Title truncates at 2 lines on mobile; description at 3. Both accept slot directives (`[atomSectionHeadingTitle]`, `[atomSectionHeadingDescription]`) or plain string inputs. The back button is a real `<button>` element and emits `backClick`.

- **`atom-bulk-action-bar`** — contextual action bar for row-selection flows. Shows a selected-item count (localizable via `AtomBulkActionBarIntl`) and an action slot for batch operation buttons. Announced to screen readers via an ARIA live region.

- **`atom-skeleton`** — loading placeholder primitives:
  - `atom-skeleton` — standalone shimmer block, configurable in width, height, and shape.
  - `[atomSkeleton]` directive — overlays a shimmer on any host element while `[atomSkeleton]="true"`, without collapsing the layout.

### Changed (0.5.0)

- **`atom-select-panel` — takes ownership of selection state (HU-029B)** — the panel now manages selection internally, removing the need for external state in filter flows. It auto-registers with `atom-filter-panel` and exposes `selectedCount`, `selectedLabels`, `totalCount`, and `getSelectedValues()` for chip labels and counters.

  New capabilities added to the panel:
  - **Array mode** — bind `[items]`, `labelKey`, and `valueKey` to render a list declaratively. Replacing the array preserves existing selections for matching value keys.
  - **`atomSelectSearch` host directive** — adds filtering. In array mode it filters the rendered list; in projection mode it shows/hides projected items. 175 ms debounce with a per-keystroke `searchValueChange` event.
  - **`atomSelectAll` host directive** — exposes `allSelected` / `indeterminate` signals and a `toggle()` method. Applies batch selection in a single operation regardless of list size.
  - `ATOM_SELECT_PANEL_CONFIG` gains `selectAllLabel` (default `'Select all'`).

  > **Breaking change:** The `searchChange` output is removed. Replace any `(searchChange)` listener with `atom-select-panel[atomSelectSearch]` — the directive now owns the filter logic. (IV-979)

- **`atom-list-item` — `selectedBrand` input** — set `[selectedBrand]="true"` to show a leading check icon and apply brand-tint styling to the row. Designed for items that represent an active filter category or an applied selection. Powered by new `--list-item-selected-brand-*` CSS custom properties.

- **`AtomDropdownTriggerDirective` — `atomDropdownPreserveContent` input** — set to `true` to keep the panel's embedded view alive across open/close cycles, preserving any internal state (e.g. selections). Default is `false`; all existing consumers are unaffected. `AtomDropdownPanelRole` now accepts `'dialog'`.

### Fixed (0.5.0)

- **`atom-select-panel`** — the "Clear selection" footer is now hidden when no items are selected; replacing the items array no longer drops valid selections; overlay z-index overlap in Docs mode resolved.
- **`atom-select-input`** — the chevron stays vertically centered in both open and closed states; the default panel footer is correctly hidden when `[hideClearFooter]="true"`; a gap is now applied between the trigger and the floating panel.
- **`atom-tooltip`** — the Rich tooltip no longer closes when the pointer moves from the trigger into the panel.

## [0.4.1] - 2026-05-28

### Changed (0.4.1)

- **Dialog theme tokens** — `atom-dialog` backdrop and panel styles now align with semantic tokens from `@atomchat-io/ui-tokens`:
  - `--dialog-backdrop-bg` maps to `--bg-overlay-primary` (replaces compiled dark blur `surface-subtle-bg`).
  - `--dialog-backdrop-blur` uses `calc(var(--effects-blur-surface-subtle) * 0.5)` for the Figma→CSS blur conversion at consumption time.
  - `--dialog-shadow` maps to `--effects-shadows-elevation-modal`; applied on `.atom-dialog-panel` via `box-shadow`.

| Commit    | Detail                                                                                 |
| --------- | -------------------------------------------------------------------------------------- |
| `37f1989` | Updated dialog backdrop, blur, and elevation shadow to semantic CSS custom properties. |

## [0.4.0] - 2026-05-25

### Added (0.4.0)

- **Plain & Rich Tooltip** — two new directives for contextual help:
  - `[atomTooltip]` — simple 1-to-6-line label on hover or keyboard focus. Supports four placements (`top | end | bottom | start`, default `top`) with automatic viewport-collision flipping.
  - `[atomRichTooltip]` — richer popover with subhead, supporting text, and an optional action button. The cursor can move freely from trigger into the panel without the tooltip closing. The action button emits `actionClick` and closes the tooltip on activation. Supports a custom `extraContent` template slot for fully bespoke content.
  - Both dismiss on blur or Escape, enforce one visible tooltip at a time, emit `opened` / `closed` lifecycle outputs, and expose a `--tooltip-*` CSS custom property layer for per-app theming without forking the components.

- **`atom-segment-control` + `atom-segment`** — tab-like toggle groups (HU-017). Five sizes (`xs`–`xl`), two modes: `label` and `icon`. Full keyboard navigation (←/→, RTL, skip-disabled), `ControlValueAccessor` for Reactive and Template-driven Forms, and Light/Dark mode out of the box. Icon mode requires an `ariaLabel` per segment (dev-mode warning if omitted).

- **`atom-text-field`** — standalone text input field. Five sizes (`xs`–`xl`), nine visual states driven by CSS pseudo-classes — no state inputs needed on the component API. Includes a character counter, support message slot, and error/success validation slots. Works with Reactive and Template-driven Forms; independent of `MatFormField`. Supported input types: `text`, `url`, `tel`, `number`, `email`, `password`, `hidden`, `search`.
  - **Text Area mode** — project `<textarea atomTextFieldInput>` instead of `<input>` for multi-line entry with the same API and states. Auto-resizes from 3 to 20 rows, then locks and scrolls. The optional `counterSuffix` input adds a label to the counter (e.g. `0/200 words`). Supported sizes: `m` and `xl`.

- **`atom-search-input`** — standalone search field (HU-020). Two modes:
  - **Search Field** (default) — always visible with a leading search icon.
  - **Expandable** — collapses to an icon button; expands on click, Tab, or the global `⌘K` / `Ctrl+K` shortcut. Filled fields never auto-collapse.
  - Debounced `valueChange` (300 ms by default), immediate `search` on Enter, clear button while the field has a value. All strings (placeholder, aria-labels, shortcut key) are configurable via injection tokens for localization. Sizes: `s`, `m`, `l`.

- **`atom-list-item`** — three-zone row (Leading · Content · Trailing) for interactive lists. The entire row is a single interactive target — click or press Enter / Space to activate. Optional selection mode (checkbox or radio style), optional disclosure chevron (`[disclosure]=true`). Four interaction states: enabled, hovered, selected, disabled. Full Light/Dark mode support.

- **`atom-dropdown-menu`** — floating contextual action menu (HU-023) via CDK Overlay. Projects `atom-list-item` rows as menu items with WAI-ARIA keyboard navigation (↑/↓ with wrap, Escape, Tab to close). Optional scrollable variant via `[maxHeight]`, optional title slot. Use with `[atomDropdownTriggerFor]`.

- **`atom-select-panel`** — data-selection panel (HU-023) for multi-select, filter, and picker flows. Supports:
  - Optional search — apply `[atomSelectSearch]` on the panel and project `<atom-search-input>`; the directive owns the debounced filter and the empty-state.
  - Virtual scroll for large lists via `[virtualScrollItemSize]` + `[virtualScrollItems]` and an item template.
  - Configurable empty state (`[isEmpty]=true`) and footer action button — both customizable via `ATOM_SELECT_PANEL_CONFIG`.

- **`[atomDropdownTriggerFor]`** — attaches any element to an `atom-dropdown-menu` or `atom-select-panel` via CDK Overlay. Handles ARIA attributes (`aria-haspopup`, `aria-expanded`, `aria-controls`), four auto-flip positions, scroll repositioning, and focus restoration on close automatically. Outputs: `dropdownOpened`, `dropdownClosed`. Public API: `open()`, `close()`, `toggle()`.

### Fixed (0.4.0)

- **Solid-button box-model** — `atom-button` and `atom-icon-button` strokes now use `box-shadow: inset` instead of `border`, so they no longer inflate the rendered box size. All solid buttons now match their Figma dimensions exactly (e.g. `atom-icon-button size="l"` renders 48 × 48 instead of 48 × 50). `atom-link-button` is unaffected.

### Changed (0.4.0)

- **Tooltip motion delays** are now read at runtime from `--motion-tooltip-*-duration` CSS custom properties (sourced from `@atomchat-io/ui-tokens`), making design tokens the single source of truth. Previously they were hardcoded numbers in the directive. `ATOM_TOOLTIP_MOTION_OVERRIDES` remains available for test-only overrides.
- **`--motion-tooltip-rich-grace-duration`** — raised from 100 ms to 150 ms for a more forgiving trigger-to-panel cursor transit window.

## [0.3.1] - 2026-05-21

### Fixed (0.3.1)

- **Dialog shell layout** — adjusted `min-height` and `height` properties for `atom-dialog-shell` container to fix dialog sizing regressions in narrow layouts.

## [0.3.0] - 2026-05-13

### Added (0.3.0)

- **`AtomBadgeDirective`** — new `[atomBadge]` directive for overlaying notification counts on any element. Inputs under the `atomBadge*` namespace: `atomBadge` (value), `atomBadgeType` (`neutral` | `inbox`), `atomBadgeState` (`enabled` | `focused` | `subtle`), `atomBadgeMax` (default 99, renders as `+N` when exceeded), `atomBadgeHidden`, `atomBadgeDescription` (accessible label), `atomBadgeOverlap`, and `atomBadgePosition`. Value 0 hides the badge automatically. Re-exports `AtomBadgePosition`.
- **Scrollbar styles** — custom scrollbar styles applied globally. Supports Chromium/WebKit and Firefox. Colors are theme-aware and driven by `--scrollbar-track-bg`, `--scrollbar-thumb-bg`, and `--scrollbar-thumb-bg-hover` tokens.
- **`AtomEmptyStateComponent`** — new `atom-empty-state` component for representing the absence of content in tables, filters, and other container contexts. Supports `small` and `medium` size variants. Each section (visual, heading, supporting text, result text, action) accepts both a slot directive and an input fallback; projected content always takes precedence. Sections not provided are omitted from the DOM entirely.
  - Slot directives: `[atomEmptyStateVisual]`, `[atomEmptyStateHeading]`, `[atomEmptyStateSupportingText]`, `[atomEmptyStateResultText]`, `[atomEmptyStateAction]`.
  - `icon` input (`AtomIconSpec | null`) — fallback icon when no visual is projected.
  - `actionLabel` input (`string`) — renders an internal secondary button when no action slot is projected.
  - `actionClick` output — emitted when the internal action button is clicked.
- **`AtomSpinnerComponent`** — new `atom-spinner` indeterminate progress indicator. Five sizes: `xs` (12 px), `s` (16 px), `m` (20 px, default), `l` (24 px), `xl` (32 px). Color is inherited from the parent foreground via `currentColor` — no color prop needed. Configurable `aria-label` (default `'Loading'`). Respects `prefers-reduced-motion`.
- **`AtomTagComponent`** — new `span[atomTag]` non-interactive pill for semantic content classification. Inputs: `variant` (`ghost` | `filled` | `outlined`, default `ghost`), `size` (`xs` | `s` | `m`, default `s`), `intent` (`success` | `warning` | `danger` | `info` | `neutral` | `brand` | `ai` | `disabled`, default `neutral`), `leading` (`none` | `dot` | `icon`, default `none`), `label` (string input, falls back to projected content), and `icon` (`AtomIconSpec`, used when `leading="icon"`). Supports `--atom-tag-max-width` for label truncation. Exported types: `AtomTagVariant`, `AtomTagSize`, `AtomTagIntent`, `AtomTagLeading`.
- **`AtomAvatarComponent`** — new `atom-avatar` component with `image`, `image-border`, `outname`, and `icon` display types, `circle` / `square` shapes, four sizes (`xs`, `s`, `m`, `l`), and an integrated status dot (`online` / `offline` / `none` / `image`). Slot directives: `[atomAvatarIcon]`, `[atomAvatarImage]`, `[atomAvatarOutname]`, and `[atomAvatarStatus]`. `[atomAvatarStatus]` projects custom content (e.g. a brand icon) inside the `image` status dot. The `size` input defaults to `'m'` for standalone usage; when nested inside `atom-avatar-label-group`, the wrapper's size always takes precedence — use `effectiveSize()` to read the resolved value.
- **`AtomAvatarLabelGroupComponent`** — new `atom-avatar-label-group` component composing `atom-avatar` with label and description typography. Supports sizes `s`, `m`, and `l`. The avatar is projected as content rather than configured via inputs, giving consumers full control over avatar type, slots, and status:

  ```html
  <atom-avatar-label-group size="m" label="…" description="…">
    <atom-avatar type="image" src="…" status="image" ariaLabel="…">
      <img atomAvatarStatus src="…" alt="" />
    </atom-avatar>
  </atom-avatar-label-group>
  ```

- **`AtomChipComponent`** — new `atom-chip` component with 6 sizes (`xxs` / `xs` / `s` / `m` / `l` / `xl`), 2 types (`outlined` / `filled`), and 6 visual states (enabled, hovered, focused, pressed, error, disabled). Includes a leading-icon slot via `[atomChipIcon]` / `[atomIcon]`, an optional removable mode that emits `(removed)`, and `--atom-chip-max-width` for label truncation. Label supports both the `[label]` input and direct content projection.
- **Cross-component host directives** — `AtomLabelHostDirective`, `AtomLeadingIconSlotHostDirective`, and the abstract `AtomIconSlotMarkerDirective` now exported from `lib/host-directives/`. Reusable by any component that needs a label fallback or a leading-icon slot.

### Deprecated (0.3.0)

- `AtomButtonLabelHostDirective` — alias of `AtomLabelHostDirective`. Kept for transition; existing button / link-button consumers continue to compile unchanged.
- `AtomSingleIconSlotHostDirective` — alias of `AtomLeadingIconSlotHostDirective`. Kept for transition; existing icon-button consumers continue to compile unchanged.

### Refactored (0.3.0)

- **Button family spinner** — loading spinners inside `atom-button`, `atom-link-button`, and `atom-icon-button` now render `<atom-spinner>` internally, making `atom-spinner` the single source of truth for loading indicators across the design system. No changes to public APIs.

### Fixed (0.3.0)

- **Button border in disabled state** — `secondary` and `danger secondary` button variants now correctly apply `--border-disabled` when disabled. The border token was missing, causing those variants to render without a visible border in the disabled state.

## [0.2.1] - 2026-04-22

### Changed (0.2.1)

- Bumped peer dependency `@atomchat-io/ui-tokens` from `^0.2.0` to `^0.2.1` to align with the latest tokens patch.

## [0.2.0] - 2026-04-14

### Added (0.2.0)

- **`AtomToggleComponent`** — new toggle/switch component with full state coverage (enabled, hovered, focused, pressed, disabled, loading, error), size modifiers (`s`, `m`), and Storybook examples. Implemented following the same selection-control pattern as checkbox and radio.
- **Effects domain** — new `effects/` SCSS domain exposing CSS custom properties for shadows, focus rings, and blur from `@atomchat-io/ui-tokens` effects semantic tokens.
- **Elevation utility classes** — `.elevation-card`, `.elevation-popover`, `.elevation-modal` applying `box-shadow` via `--effects-shadows-*` custom properties.
- **Blur utility classes** — `.blur-surface-subtle`, `.blur-surface-medium`, `.blur-surface-strong` applying `backdrop-filter` + `background-color` (overlay) via `--effects-blur-*` custom properties. Theme-aware: overlay adapts to light/dark mode.
- **Checkbox and radio focus ring** — `--checkbox-focus-ring` and `--radio-focus-ring` component tokens added, both wired to `--effects-focus-rings-base`. Checkbox selector updated to `:has(.mdc-checkbox__native-control:focus), :has(.mdc-checkbox__native-control:focus-visible)` to reliably trigger in all focus modalities (keyboard and programmatic). Radio selector updated equivalently.
- **Storybook stories** — `atom-card.stories.ts` covering Playground (all inputs), Anatomy (shell, header, body, media, footer sub-stories), and content projection examples.
- **`AtomCardComponent`** — new card shell component (`atom-card`) with `ViewEncapsulation.None` and semantic card tokens. Accepts optional `[media]`, `[header]`, `[body]`, and `[footer]` slots via content projection. Supports `elevation-card` shadow by default.
- **`AtomCardTextDirective`** — shared text-content directive (`[atomCardText]`) injected by header and body sub-components to read `headline`, `subhead`, and `text` inputs without coupling them to the shell.
- **`AtomCardHeaderComponent`** — card header sub-component (`atom-card-header`) with a `__text` slot containing headline + subhead, and an optional `[atomCardHeaderText]` projection override for custom header content.
- **`AtomCardBodyComponent`** — card body sub-component (`atom-card-body`) with styled `__head-group` (headline + subhead, bold, primary color) and `__text` (label size, secondary color). Correctly uses `flex: 1 1 auto` so auto-height cards expand to fit content without collapsing.
- **`AtomCardMediaComponent`** — card media sub-component (`atom-card-media`) projecting arbitrary image/media content above the header.
- **`AtomCardFooterComponent`** — card footer sub-component (`atom-card-footer`) with two variants:
  - `ctas` (default) — renders a primary button and an optional secondary button; configurable via `primaryActionText`, `primaryActionColor`, `primaryActionDisabled`, `secondaryActionText`, `secondaryActionColor`, `secondaryActionDisabled`, `buttonSize`, and `buttonsFill` inputs. For any other button style, project `button[atom-button]` elements directly — this overrides all CTA inputs.
  - `dynamic-content` — projects freeform content via `[atomCardFooterDynamic]`.
  - `buttonsFill` input (`boolean`, default `false`) makes all CTAs stretch to fill available width equally.
- **`AtomCardFooterDynamicDirective`** — marker directive (`[atomCardFooterDynamic]`) for projecting freeform content into `dynamic-content` variant.
- **Card semantic tokens** — new `_card.scss` token file under `styles/scss/theme/components/` exposing `--card-bg`, `--card-fg-primary`, `--card-fg-secondary`, `--card-border`, and dark-mode overrides. All card sub-components consume these tokens.
- **`AtomDividerComponent`** — new divider component (`hr[atom-divider]`) implemented as a host-element directive on the native `<hr>` element, with no template file. Supports `horizontal` (default) and `vertical` orientations via the `atom-divider` attribute alias. Applies `role="separator"` and `aria-orientation` for accessibility. Color is driven by `--divider-border-default` (→ `--border-secondary`) and thickness by `--divider-border-width` (→ `--stroke-xs`). Vertical orientation uses `box-sizing: content-box` + `align-self: stretch` so the 1 px border renders correctly inside flex containers without a fixed parent height.
- **Divider semantic tokens** — new `_divider.scss` component token partial under `styles/scss/theme/components/` exposing `--divider-border-default` and `--divider-border-width`. Forwarded from `_components.scss` barrel.
- **`AtomDialogShellComponent`** — new dialog shell component (`atom-dialog-shell`) with `ViewEncapsulation.None` and semantic dialog tokens (`--dialog-bg-default`, `--dialog-fg-primary`, `--dialog-fg-secondary`, `--dialog-border-default`). Orchestrates header / body / footer sub-components in a flex column; body grows and scrolls internally while header and footer stay fixed (AC2).
- **`AtomDialogHeaderComponent`** — header sub-component (`atom-dialog-header`) with dual alignment: `left` (single row: cta + title + close) and `center` (flex-col: icon + title + subtitle, with absolutely-positioned close and back buttons). Implements API dual with slot precedence over inputs for all zones (`atomDialogHeaderCta`, `atomDialogHeaderIcon`, `atomDialogHeaderTitle`, `atomDialogHeaderSubtitle`, `atomDialogHeaderTitleRow`). Close button always standard X icon (not customizable via slot). CTA button hidden by default, shown when `showCtaButton=true`, defaults to fa-chevron-left icon. Emits `ctaClick` output for back/navigation actions.
- **`AtomDialogBodyComponent`** — body sub-component (`atom-dialog-body`) providing a scrollable free-projection region. Grows to fill available height via `flex: 1 1 auto` set by the shell.
- **`AtomDialogFooterComponent`** — footer sub-component (`atom-dialog-footer`) with `hug` (right-aligned, content-sized CTAs) and `fill` (equal-width CTAs) modes. Auto-detects projected `button[atom-button]` via contentChildren + computed pattern (same as AtomCard). Supports `atomDialogFooterStart` slot for left-side auxiliary content (e.g. selection counter). Wires buttons to `[atomDialogClose]` with `reason='primary-action'` / `reason='secondary-action'` automatically.
- **`AtomDialogCloseDirective`** — declarative close directive (`[atomDialogClose]`) for any element inside a dialog. Accepts `[atomDialogClose]="value"` and `[reason]="closeReason"` inputs; calls `dialogRef.close(AtomDialogCloseEvent)` on click. Uses optional `DialogRef` injection to remain safe outside dialog context (e.g. Storybook).
- **`AtomDialogService`** — wrapper of `@angular/cdk/dialog` with normative defaults (`hasBackdrop`, `restoreFocus`, `panelClass`). Maps backdrop clicks and Escape key presses to typed `AtomDialogCloseEvent` payloads (`reason: 'backdrop'` / `reason: 'escape'`). Exposes `ATOM_DIALOG_DATA` injection token for passing data into the opened component.
- **Dialog token domain** — new `_dialog.scss` in `styles/scss/theme/components/` mapping `dialog/bg/default → bg/primary`, `dialog/fg/primary → fg/primary`, `dialog/fg/secondary → fg/tertiary`, `dialog/border/default → border/secondary`.

### Changed (0.2.0)

- Bumped peer dependency `@atomchat-io/ui-tokens` from `^0.1.x` to `^0.2.0` to consume new status tokens (`bg/status/neutral`, `fg/status/on-*`, `border/status/on-*`) and the new effects semantic token domain (shadows, focus rings, blur).
- **Button focus ring** — `--buttons-focus-ring-*` component tokens now reference `--effects-focus-rings-base` (base variants) and `--effects-focus-rings-error` (destructive variants) instead of raw color primitives. The `box-shadow` in the component mixin is now assembled by the effects token (full value), not by the component itself.

### Refactored (0.2.0)

- **`SelectionControlBaseDirective`** — extracted shared CVA logic (signals, computed properties, `ControlValueAccessor` implementation, `onControlChange` handler) from `CheckboxComponent` and `AtomToggleComponent` into a generic abstract `@Directive()` base class. The `change` output is typed via `TChange extends { checked: boolean }`, removing all duplication between the two components.
- **`AtomSelectionControlSize`** — `AtomCheckboxSize` and `AtomToggleSize` are now type aliases of `AtomSelectionControlSize` (defined in the base directive). The original names are preserved as backward-compatible aliases. `AtomSelectionControlSize` is exported from the library root.
- **Stories** — replaced `@Input()` decorators with signal `input()` in the Storybook catalog helper components for toggle and checkbox, aligning with the signals-first pattern used in the library components.
- **Toggle track shape** — extracted `--toggle-track-shape` component variable in `toggle.component.scss`; both size variants now reference it instead of repeating `var(--spacing-m)` inline in `--mat-slide-toggle-track-shape`.
- **Stories** — replaced direct property access with reactive `input()` signal calls in the Storybook catalog helper components for checkbox and toggle, aligning with the signals-first pattern used by the library components.

### Fixed (0.2.0)

- **Link button mixed-decls warning** — moved plain declarations (`min-width`, `@include _atom-link-button-state`) before the `atom-interactive-link-button-host-shell` mixin include to comply with upcoming Sass mixed-declarations behavior.
- **Build dependency** — `design-system-docs:build` now depends on `ui-tokens:build` instead of `ui-tokens:generate-tokens`, ensuring `package.json` is present in `dist/libs/ui-tokens` for Sass package resolution.
- **Checkbox disabled+checked checkmark size** — replaced `border: none` with `border-color: transparent` in the disabled+checked/indeterminate background override. Removing the border collapsed the box model, causing the checkmark SVG to render visually larger than in the enabled state. Keeping the border transparent preserves the 2 px inset and the correct checkmark size across all states.

| Commit    | Detail                                                                                                    |
| --------- | --------------------------------------------------------------------------------------------------------- |
| `1feeb34` | Added `effects/_variables.scss`, `_custom-properties.scss`; wired into `_tokens.scss`.                    |
| `e84783f` | Imported effects custom properties in `atom-theme.scss` and `atom-theme-m3.scss`.                         |
| `cf316d4` | Wired `--buttons-focus-ring-*` to effects tokens; mixin now uses full box-shadow value.                   |
| `ca8289f` | Added `effects/_classes.scss` and `utilities.scss`; switched theme entry points to use `utilities`.       |
| `347beca` | Fixed link-button mixed-decls Sass deprecation warning.                                                   |
| `0140386` | Fixed build dependency: `design-system-docs` now depends on `ui-tokens:build`.                            |
| `8a73fc9` | Updated `--buttons-focus-ring-*` to reference renamed effects tokens (`-base`, `-error`).                 |
| `7677984` | Added `--checkbox-focus-ring` token; initial wiring via `.cdk-focused` (superseded by `193898f`).         |
| `193898f` | Checkbox/radio: use `:has(:focus/:focus-visible)` for focus ring; added `--radio-focus-ring` token.       |
| `d6b65b6` | Added component token layer (`_toggle.scss`) for toggle states and error handling.                        |
| `c43eb0a` | Added centralized visual layer and Material overrides for toggle (`_am-toggle.scss`).                     |
| `742e524` | Implemented `AtomToggleComponent` with template, styles, and public API.                                  |
| `27f1e1a` | Added unit tests and Storybook stories for `AtomToggleComponent`.                                         |
| `3a6ec0f` | Refactored selection-control size/layout mixins shared by toggle, checkbox, and radio.                    |
| `f057ff3` | Extracted `SelectionControlBaseDirective`; checkbox and toggle now extend it.                             |
| `9c5ca0a` | Unified `onControlChange` handler and error icon across checkbox and toggle after base directive extract. |
| `56647b6` | Removed standalone `AtomToggleSize`; re-exported as alias of `AtomSelectionControlSize`.                  |
| `6ab191e` | Extracted `--toggle-track-shape`; both sizes now reference it via `--mat-slide-toggle-track-shape`.       |
| `c9ec40b` | Fixed checkbox disabled+checked checkmark size: `border: none` → `border-color: transparent`.             |
| `8453bf2` | Updated Storybook catalog helpers to use reactive `input()` functions for checkbox and toggle stories.    |
| `3c25324` | Added `_card.scss` component tokens; wired into theme entry points.                                       |
| `b4ebfc2` | Implemented `AtomCardTextDirective` for shared text-content inputs.                                       |
| `aa136be` | Implemented `AtomCardComponent` shell with slot-based content projection.                                 |
| `17bc883` | Implemented `AtomCardHeaderComponent` with custom-text projection slot.                                   |
| `6cf265c` | Implemented `AtomCardBodyComponent` with head-group and text layout.                                      |
| `ff095cf` | Implemented `AtomCardMediaComponent` for image/media projection.                                          |
| `1e49f6f` | Implemented `AtomCardFooterComponent` with CTA inputs, variants, buttonsFill.                             |
| `2a135ec` | Exported all card symbols from the library public API (`index.ts`).                                       |
| `62576ff` | Added Storybook stories: Playground, Anatomy, and projection examples.                                    |
| `8f50c86` | Implemented `AtomDividerComponent` (host-element on `hr`, orientation, a11y, token-based styles).         |
| `fb9a11e` | Added `_divider.scss` component token partial; forwarded from `_components.scss` barrel.                  |
| `a4a0d95` | Exported `AtomDividerComponent` and `AtomDividerOrientation` from the library public API (`index.ts`).    |
| `b7cf3f9` | Added Storybook stories: Playground, Orientation, Section separator, Toolbar with vertical dividers.      |

## [0.1.7] - 2026-04-07

### Fixed (0.1.7)

- Update selector in `radio-group` to improve styling consistency. Commit: `ea6d266`

## [0.1.6] - 2026-04-07

### Reverted (0.1.6)

- Revert "fix(button): update styles and encapsulation for button component". Commit: `f716aec`

## [0.1.5] - 2026-04-07

### Fixed (0.1.5)

- Update styles and encapsulation for `atom-button` component. Commit: `da3af65`

## [0.1.4] - 2026-04-07

### Changed / Fixed (0.1.4)

- Improved encapsulation in `atom-button` by scoping icon and spinner styles with `::ng-deep`. Commit: `fdeb2b0`

## [0.1.3] - 2026-04-06

### Added / Fixed (0.1.3)

- Implemented `change` event in `atom-radio-group` to correctly emit `AtomRadioChange` (transparent mapped to `MatRadioChange`), ensuring full compatibility with the `mat-radio-group` API.
- Re-exposed event propagation from `atom-radio-button` correctly when modified by user interaction.

## [0.1.2] - 2026-04-01

### Fixed (0.1.2)

- Resolved button icon projection and story binding issues.

| Commit    | Detail                                                           |
| --------- | ---------------------------------------------------------------- |
| `1d092a5` | Corrected `ng-content` selectors for icon positions.             |
| `8992b81` | Updated start/end icon projection selectors in button templates. |
| `0327c46` | Fixed button type binding syntax in stories.                     |

### Changed (0.1.2)

- Improved responsive sizing behavior in button and checkbox styles, and aligned package metadata.

| Commit    | Detail                                                    |
| --------- | --------------------------------------------------------- |
| `8460246` | Updated package version and peer dependencies.            |
| `5de2458` | Refined button width and max-width behavior.              |
| `0e9f63f` | Updated checkbox sizing to use `fit-content`/`max-width`. |
| `0442506` | Removed checkbox `max-width` to improve flexibility.      |
| `38a63c1` | Adjusted checkbox width for layout adaptability.          |
| `de79b2b` | Updated button-with-icons story title for clarity.        |

## [0.1.1] - 2026-03-27

### Changed (0.1.1)

- Released `0.1.1` with dependency/version alignment updates.

| Commit    | Detail                                                         |
| --------- | -------------------------------------------------------------- |
| `32402a1` | Bumped `ui-design-system` to `0.1.1` and updated dependencies. |

## [0.1.0] - 2026-03-27

### Added (0.1.0)

- **Theming:** opt-in Angular Material 3 theme entry (`atom-theme-m3.scss`), M3 palette helpers in theme base.
- **Checkbox:** centralized Material overrides (`_am-checkbox.scss`), theme/component SCSS split, and `change` output emitting `MatCheckboxChange` for Material compatibility.
- **Radio:** centralized Material overrides (`_am-radio.scss`), radio group orientation/layout styles, and `AtomRadioChange` type for `valueChange`.
- **Button:** `a[atom-button]` support with anchor-safe disabled/tabindex behavior and label truncation support.
- **Shared:** reusable text truncation mixins and truncation behavior on `atom-selection-control-label`.
- **Theming:** `$atom-dark-mode-class` and `atom-dark-mode-class-name()` in `styles/scss/_config.scss` (default class: `#{$atom-prefix}dark-mode`), plus `ATOM_DARK_MODE_CLASS_DEFAULT` for TypeScript toggling.

### Fixed (0.1.0)

- Checkbox: deferred `NgControl` resolution, class bindings, and layout edge cases.
- Button: icon selector handling, `.mat-icon` styles, and related import paths.

### Changed (0.1.0)

- Checkbox and radio theme wiring (M2/M3 entry points) and radio token application in `:root` / configurable dark mode class.
- Internal package references aligned with `@atomchat-io/*` where applicable.
