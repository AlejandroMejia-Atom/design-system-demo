/**
 * @deprecated Use `AtomTextTruncateDirective` from `@atomchat-io/ui-design-system`
 * instead. That version replaces `MatTooltip` with the DS plain tooltip
 * and applies truncation styles via the `text-truncate-single-line` SCSS mixin.
 * This class will be removed in a future major release of `@atomchat-io/ui-utils`.
 */
import { AfterViewInit } from '@angular/core';
import { TooltipPosition } from '@angular/material/tooltip';
import * as i0 from "@angular/core";
export declare class AtomTextTruncateDirective implements AfterViewInit {
    tooltipPosition: import("@angular/core").InputSignal<TooltipPosition>;
    tooltip: import("@angular/core").InputSignal<string>;
    tooltipDisabled: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    private readonly elementRef;
    private readonly renderer;
    private readonly matTooltip;
    constructor();
    ngAfterViewInit(): void;
    mouseover(): void;
    mouseleave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomTextTruncateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomTextTruncateDirective, "[atomTextTruncate]", never, { "tooltipPosition": { "alias": "atomTruncateTooltipPosition"; "required": false; "isSignal": true; }; "tooltip": { "alias": "atomTruncateTooltip"; "required": false; "isSignal": true; }; "tooltipDisabled": { "alias": "atomTruncateTooltipDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
