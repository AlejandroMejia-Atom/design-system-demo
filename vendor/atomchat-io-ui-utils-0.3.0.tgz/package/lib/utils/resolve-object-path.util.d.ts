/**
 * Reads a property from an object using dot-notation (e.g. `'contact.name'`).
 * Returns `undefined` when `item` is nullish or any segment along the path is
 * nullish.
 */
export declare function resolveObjectPath(item: unknown, path: string): unknown;
