# @atomchat-io/ui-utils

Small **Angular** library reserved for **shared utilities** used across Atom UI apps and packages (helpers, types, and lightweight building blocks that do not belong in `@atomchat-io/ui-design-system`).

## Current scope

The public API is intentionally minimal and may expand between minor versions. Inspect the package entry point (`index` / `public-api` in the built output) and **`CHANGELOG.md`** for the version you install to see exported symbols.

## Installation

```bash
npm install @atomchat-io/ui-utils
```

Configure `@atomchat-io` registry access the same way as other Atom scoped packages.

## Peer dependencies

There are no required peers today; future utilities may add Angular or RxJS peers as needed. Check `package.json` for the release you use.

## When to use this package

Prefer **`@atomchat-io/ui-design-system`** for user-facing components and **`@atomchat-io/ui-tokens`** for design tokens. Use **`@atomchat-io/ui-utils`** for cross-app code that is not a full component but should still ship as a versioned dependency.

## Changelog

See `CHANGELOG.md` in the published tarball.
