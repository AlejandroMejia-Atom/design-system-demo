# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2026-05-13

### Added (0.2.0)

- **`highlight` pipe** — XSS-safe text highlighting with diacritic-insensitive matching and flexible multi-token separator support via `flexibleSeparators` option. Exports `DIACRITIC_MAP` for reuse.
- **`sortArray` pipe** — sorts an array of objects by a field. Accepts an optional `direction: 'asc' | 'desc'` parameter (default `'asc'`).
- **`fileSizeFormatter` pipe** — formats a byte count into a human-readable string (e.g. `'1.00 KB'`).
- **`formatPhone` pipe** — formats phone strings to E.164 international format.
- **`searchInArray` pipe** — case-insensitive array filter with support for dot-notation property paths (e.g. `'contact.name'`) and nested object search.
- **`sanitizeHtml` pipe** — bypasses Angular's `DomSanitizer` for trusted HTML strings.
- **`atomAutofocus` directive** — focuses the host element on init. Accepts a boolean input to toggle the behavior.
- **`atomDisableCopyPaste` directive** — blocks `copy`, `paste`, and `cut` events on the host element.
- **`atomStopPropagation` directive** — stops click event propagation on the host element.
- **`atomGoBack` directive** — navigates back in browser history on click. Accepts a `fallbackUrl` input (default `'/'`) used when there is no navigation history.
- **`atomLoaded` directive** — emits `loaded` on `img[atomLoaded]` elements when the image finishes loading.
- **`atomNoEmojis` directive** — strips emoji characters from a form control value on `input` and `paste` events.
- **`atomOnVisible` directive** — emits `atomOnVisible` when the host element enters the viewport. Supports `atomThreshold` and `atomOnce` inputs.
- **`atomHasScrollbar` directive** — adds configurable CSS classes when the host has a vertical and/or horizontal scrollbar. Reacts to container size changes.
- **`atomScrollable` directive** — emits `scrollPosition` events (`'top' | 'bottom' | 'up' | 'down'`) and a `scrolledToTop` event as the user scrolls the host element.
- **`atomMaxLength` directive** — enforces a character limit (default `25`) on form control inputs.
- **`atomTruncateText` directive** — applies CSS text-overflow truncation and shows a `MatTooltip` when the text overflows. Accepts `tooltip`, `tooltipPosition`, and `tooltipDisabled` inputs.
- **`atomTextNormalizer` directive** — trims leading/trailing whitespace and collapses consecutive spaces in a form control value on `focusout`, `paste`, and `drop`.
- **`atomOnlyNumbers` directive** — restricts input to numeric characters. Configurable via `decimals`, `maxIntegers`, and `maxDigitsLength` inputs. Emits `validationError` on invalid paste.
- **`atomMaxRange` directive** — integrates with `mat-date-range-input` to cap the selectable date range. Accepts a numeric `atomMaxRange` input (number of days).
- **`atomDragDrop` directive** — handles file drag-and-drop on the host element. Emits `fileDropped` with the `FileList`. Supports a `disabled` input.
- **`atomAutoResize` directive** — measures child item widths against the container and hides overflowing items, replacing them with a `+N` counter. Reacts to container size changes.
- **`atomContentEditable` directive** — implements `ControlValueAccessor` on a `contenteditable` element. Supports HTML mode, multiline, disabled state, and placeholder.
- **`TrackingAdapter`** abstract class and **`TRACKING_ADAPTER`** injection token — contract for analytics adapters consumed by `atomTrackEvent`.
- **`atomTrackEvent` directive** — calls `TrackingAdapter.trackEvent` on click with a required event name, optional props map, and a `disabled` guard.
- **`CursorPositionHelper`** — static helper for preserving cursor position after programmatic value changes in `HTMLInputElement` and `contenteditable` elements.

### Changed (0.2.0)

- Switched test executor to Vitest for Angular 20 compatibility.
- **`sortArray` — ⚠️ Breaking** — default sort direction is now `'asc'` (was implicitly descending). Pass `direction: 'desc'` to restore the previous behaviour. The source array is no longer mutated — a sorted copy is returned instead.
- **`fileSizeFormatter` — ⚠️ Breaking** — output now includes a space before the unit suffix (e.g. `'1.00 KB'` instead of `'1.00KB'`). Update any string comparisons or snapshot tests that relied on the old format.

## [0.1.0] - 2026-03-27

### Added (0.1.0)

- Initial library structure and Nx configuration.
- Initial public exports (see `src/index.ts`).

### Changed (0.1.0)

- Project metadata tags for categorization.
- Removed unused imports.
