export declare class CursorPositionHelper {
    /**
     * Updates the value of the form control and preserves the cursor position.
     *
     * !This function doesn't update the value of the input, it only sets the selection range.
     * !The value should be updated on the `cbBeforePreserve` callback.
     * @param element The input element.
     * @param previousLength The length of the old text.
     * @param currentLength The length of the new text.
     * @param cbBeforePreserve The callback to be executed before preserving the cursor position.
     * @param cbAfterPreserve The callback to be executed after preserving the cursor position.
     */
    static preserveCursorPosition(element: HTMLElement, previousLength: number, currentLength: number, cbBeforePreserve: () => void, cbAfterPreserve?: () => void): void;
    static getInputSelectionRange(oldLength: number, newLength: number, target: HTMLInputElement): {
        start: number;
        end: number;
    };
    static getElementSelectionRange(oldLength: number, newLength: number): {
        start: number;
        end: number;
    };
    static calculateSelectionRange(oldLength: number, newLength: number, initialStart: number, initialEnd: number): {
        start: number;
        end: number;
    };
    static getSelectionRange(target: HTMLElement, oldLength: number, newLength: number): {
        start: number;
        end: number;
    };
    static setSelectionRange(target: HTMLElement, { start, end }: {
        start: number;
        end: number;
    }): void;
}
