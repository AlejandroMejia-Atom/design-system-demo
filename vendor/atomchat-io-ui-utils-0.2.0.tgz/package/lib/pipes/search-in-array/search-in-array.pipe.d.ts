import { PipeTransform } from "@angular/core";
import * as i0 from "@angular/core";
export declare class SearchInArrayPipe implements PipeTransform {
    transform<T>(array: T[], valueToSearch: string, propsToSearch?: (keyof T | string)[]): T[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchInArrayPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SearchInArrayPipe, "searchInArray", true>;
}
