import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FileSizeFormatterPipe implements PipeTransform {
    private readonly units;
    private readonly defaultPrecision;
    private readonly round;
    transform(value: number | string, precision?: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileSizeFormatterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FileSizeFormatterPipe, "fileSizeFormatter", true>;
}
