import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FormatPhonePipe implements PipeTransform {
    private readonly phoneUtil;
    transform(value: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatPhonePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormatPhonePipe, "formatPhone", true>;
}
