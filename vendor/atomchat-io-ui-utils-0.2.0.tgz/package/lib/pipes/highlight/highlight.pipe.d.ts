import { PipeTransform } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class HighlightPipe implements PipeTransform {
    private readonly sanitizer;
    private readonly baseRegex;
    transform(value: string, search: string, flexibleSeparators?: boolean, diacriticPattern?: boolean): SafeHtml;
    private escapeHtml;
    private buildDiacriticPattern;
    static ɵfac: i0.ɵɵFactoryDeclaration<HighlightPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<HighlightPipe, "highlight", true>;
}
