import * as i0 from "@angular/core";
export declare class AtomOnlyNumbersDirective {
    atomOnlyNumbers: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    decimals: import("@angular/core").InputSignalWithTransform<number, string | number>;
    maxIntegers: import("@angular/core").InputSignalWithTransform<number, string | number>;
    maxDigitsLength: import("@angular/core").InputSignalWithTransform<number, string | number>;
    validatePaste: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    validationError: import("@angular/core").OutputEmitterRef<string>;
    private readonly el;
    private readonly regex;
    private readonly specialKeys;
    onKeyDown(e: KeyboardEvent): void;
    onPaste(event: ClipboardEvent): void;
    onDrop(event: DragEvent): void;
    private validateValue;
    private insertText;
    private isInvalid;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomOnlyNumbersDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomOnlyNumbersDirective, "[atomOnlyNumbers]", never, { "atomOnlyNumbers": { "alias": "atomOnlyNumbers"; "required": false; "isSignal": true; }; "decimals": { "alias": "atomDecimals"; "required": false; "isSignal": true; }; "maxIntegers": { "alias": "atomMaxIntegers"; "required": false; "isSignal": true; }; "maxDigitsLength": { "alias": "atomMaxDigitsLength"; "required": false; "isSignal": true; }; "validatePaste": { "alias": "atomValidatePaste"; "required": false; "isSignal": true; }; }, { "validationError": "atomValidationError"; }, never, never, true, never>;
}
