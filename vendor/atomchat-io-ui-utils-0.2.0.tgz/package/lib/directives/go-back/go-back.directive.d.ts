import * as i0 from "@angular/core";
export declare class AtomGoBackDirective {
    fallbackUrl: import("@angular/core").InputSignal<string>;
    private readonly router;
    private readonly location;
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomGoBackDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomGoBackDirective, "[atomGoBack]", never, { "fallbackUrl": { "alias": "atomGoBackFallback"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
