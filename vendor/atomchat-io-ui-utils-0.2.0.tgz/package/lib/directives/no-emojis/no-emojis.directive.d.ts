import * as i0 from "@angular/core";
export declare class AtomNoEmojisDirective {
    private readonly emojiRegex;
    private readonly control;
    filterEmojis(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomNoEmojisDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomNoEmojisDirective, "[atomNoEmojis]", never, {}, {}, never, never, true, never>;
}
