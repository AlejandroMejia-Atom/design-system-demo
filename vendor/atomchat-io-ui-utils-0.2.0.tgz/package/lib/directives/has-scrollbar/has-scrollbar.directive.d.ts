import { AfterViewInit, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
declare enum Axis {
    vertical = "vertical",
    horizontal = "horizontal",
    both = "both"
}
export declare class AtomHasScrollbarDirective implements AfterViewInit, OnDestroy {
    scrollClass: import("@angular/core").InputSignal<string>;
    scrollClassX: import("@angular/core").InputSignal<string>;
    scrollClassY: import("@angular/core").InputSignal<string>;
    scrollAxis: import("@angular/core").InputSignal<Axis>;
    verticalScroll: boolean;
    horizontalScroll: boolean;
    private previousHeight;
    private previousWidth;
    private readonly resizeObserver;
    private readonly renderer;
    private readonly elementRef;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    runCheck(): void;
    private checkScroll;
    private removeClasses;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomHasScrollbarDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomHasScrollbarDirective, "[atomHasScrollbar]", ["atomHasScrollbar"], { "scrollClass": { "alias": "atomScrollClass"; "required": false; "isSignal": true; }; "scrollClassX": { "alias": "atomScrollClassX"; "required": false; "isSignal": true; }; "scrollClassY": { "alias": "atomScrollClassY"; "required": false; "isSignal": true; }; "scrollAxis": { "alias": "atomScrollAxis"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
export {};
