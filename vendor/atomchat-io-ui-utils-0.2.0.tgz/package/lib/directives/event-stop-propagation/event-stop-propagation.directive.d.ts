import * as i0 from "@angular/core";
export declare class AtomStopPropagationDirective {
    onClick(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomStopPropagationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomStopPropagationDirective, "[atomStopPropagation]", never, {}, {}, never, never, true, never>;
}
