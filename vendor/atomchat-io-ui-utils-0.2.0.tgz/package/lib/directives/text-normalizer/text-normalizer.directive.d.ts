import { AfterViewInit } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "../max-length/max-length.directive";
/**
 * A directive to normalize text: removes leading/trailing spaces and
 * collapses multiple consecutive spaces into one.
 * Composes `AtomMaxLengthDirective` to enforce a character limit.
 *
 * @example
 * <input formControlName="name" atomTextNormalizer truncateTextAt="100">
 */
export declare class AtomTextNormalizerDirective implements AfterViewInit {
    private textControl;
    private readonly ngControl;
    private readonly maxLengthDirective;
    ngAfterViewInit(): void;
    onInput(event: Event): void;
    onFocusOut(): void;
    onPaste(): void;
    onDrop(): void;
    private scheduleNormalization;
    private setOnControl;
    private updateControlValue;
    private textNormalizer;
    private handlerChanges;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomTextNormalizerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomTextNormalizerDirective, "[atomTextNormalizer]", never, {}, {}, never, never, true, [{ directive: typeof i1.AtomMaxLengthDirective; inputs: { "atomMaxLength": "atomMaxLength"; }; outputs: {}; }]>;
}
