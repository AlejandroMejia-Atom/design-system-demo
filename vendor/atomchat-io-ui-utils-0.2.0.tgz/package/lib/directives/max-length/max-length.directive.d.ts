import * as i0 from "@angular/core";
export declare class AtomMaxLengthDirective {
    readonly atomMaxLength: import("@angular/core").InputSignalWithTransform<number, string | number>;
    private readonly el;
    private readonly control;
    onKeyDown(event: KeyboardEvent): void;
    onInput(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomMaxLengthDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomMaxLengthDirective, "[atomMaxLength]", never, { "atomMaxLength": { "alias": "atomMaxLength"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
