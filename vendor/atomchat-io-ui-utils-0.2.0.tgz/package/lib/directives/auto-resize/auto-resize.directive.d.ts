import { AfterViewInit, ElementRef, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AtomAutoResizeDirective implements AfterViewInit, OnDestroy {
    itemLimit: import("@angular/core").InputSignal<number>;
    selectedItems: import("@angular/core").InputSignal<number>;
    visibleItemCount: import("@angular/core").OutputEmitterRef<number>;
    loadItems: import("@angular/core").OutputEmitterRef<void>;
    items: import("@angular/core").Signal<readonly ElementRef<any>[]>;
    private readonly _itemMeta;
    private resizeObserver;
    private _counterUnlisten;
    private readonly el;
    private readonly renderer;
    private readonly windowResize;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private calculateWidths;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomAutoResizeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomAutoResizeDirective, "[atomAutoResize]", never, { "itemLimit": { "alias": "atomItemLimit"; "required": false; "isSignal": true; }; "selectedItems": { "alias": "atomSelectedItems"; "required": false; "isSignal": true; }; }, { "visibleItemCount": "atomVisibleItemCount"; "loadItems": "atomLoadItems"; }, ["items"], never, true, never>;
}
