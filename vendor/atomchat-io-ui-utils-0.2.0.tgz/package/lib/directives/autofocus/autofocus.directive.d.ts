import * as i0 from "@angular/core";
export declare class AtomAutofocusDirective {
    atomAutofocus: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    private readonly el;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomAutofocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomAutofocusDirective, "[atomAutofocus]", never, { "atomAutofocus": { "alias": "atomAutofocus"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
