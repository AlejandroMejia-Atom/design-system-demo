import * as i0 from "@angular/core";
export declare class AtomDisableCopyPasteDirective {
    block(e: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomDisableCopyPasteDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomDisableCopyPasteDirective, "[atomDisableCopyPaste]", never, {}, {}, never, never, true, never>;
}
