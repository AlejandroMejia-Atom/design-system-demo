import { DateRange, MatDateRangeSelectionStrategy } from '@angular/material/datepicker';
import * as i0 from "@angular/core";
export declare class MaxRangeSelectionStrategy<D> implements MatDateRangeSelectionStrategy<D> {
    private readonly _dateAdapter;
    delta: number;
    selectionFinished(date: D, currentRange: DateRange<D>): DateRange<D>;
    createPreview(activeDate: D | null, currentRange: DateRange<D>): DateRange<D>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaxRangeSelectionStrategy<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MaxRangeSelectionStrategy<any>>;
}
export declare class AtomMaxRangeDirective {
    atomMaxRange: import("@angular/core").InputSignal<number | undefined>;
    private readonly maxRangeStrategy;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomMaxRangeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomMaxRangeDirective, "[atomMaxRange]", never, { "atomMaxRange": { "alias": "atomMaxRange"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
