import * as i0 from "@angular/core";
export declare class AtomDragDropDirective {
    private static readonly DEFAULT_STYLE;
    disabled: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    fileDropped: import("@angular/core").OutputEmitterRef<FileList>;
    protected readonly _background: import("@angular/core").WritableSignal<string>;
    protected readonly _zIndex: import("@angular/core").WritableSignal<string>;
    protected readonly _opacity: import("@angular/core").WritableSignal<string>;
    protected readonly _fileOver: import("@angular/core").WritableSignal<boolean>;
    onDragOver(evt: DragEvent): void;
    onDragLeave(evt: DragEvent): void;
    onDrop(evt: DragEvent): void;
    private guard;
    private resetStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomDragDropDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomDragDropDirective, "[atomDragDrop]", ["atomDragDrop"], { "disabled": { "alias": "atomDragDropDisabled"; "required": false; "isSignal": true; }; }, { "fileDropped": "atomFileDropped"; }, never, never, true, never>;
}
