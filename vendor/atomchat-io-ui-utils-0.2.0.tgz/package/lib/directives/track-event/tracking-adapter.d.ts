import { InjectionToken } from "@angular/core";
export interface TrackingAdapter {
    trackEvent(name: string, props: Record<string, unknown>): void;
}
export declare const TRACKING_ADAPTER: InjectionToken<TrackingAdapter>;
