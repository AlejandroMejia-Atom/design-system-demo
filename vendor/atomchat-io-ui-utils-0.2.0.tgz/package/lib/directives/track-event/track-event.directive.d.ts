import * as i0 from "@angular/core";
export declare class AtomTrackEventDirective {
    atomTrackEvent: import("@angular/core").InputSignal<string>;
    atomTrackEventProps: import("@angular/core").InputSignal<Record<string, string>>;
    atomTrackEventDisabled: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    private readonly trackingAdapter;
    private readonly errorHandler;
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomTrackEventDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomTrackEventDirective, "[atomTrackEvent]", ["atomTrackEvent"], { "atomTrackEvent": { "alias": "atomTrackEvent"; "required": true; "isSignal": true; }; "atomTrackEventProps": { "alias": "atomTrackEventProps"; "required": false; "isSignal": true; }; "atomTrackEventDisabled": { "alias": "atomTrackEventDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
