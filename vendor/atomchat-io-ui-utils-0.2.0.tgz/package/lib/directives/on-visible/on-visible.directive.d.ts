import { AfterViewInit, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AtomOnVisibleDirective implements AfterViewInit, OnDestroy {
    atomThreshold: import("@angular/core").InputSignal<number>;
    atomOnce: import("@angular/core").InputSignal<boolean>;
    atomOnVisible: import("@angular/core").OutputEmitterRef<void>;
    private _intersectionObserver?;
    private readonly _element;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private checkForIntersection;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomOnVisibleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomOnVisibleDirective, "[atomOnVisible]", never, { "atomThreshold": { "alias": "atomThreshold"; "required": false; "isSignal": true; }; "atomOnce": { "alias": "atomOnce"; "required": false; "isSignal": true; }; }, { "atomOnVisible": "atomOnVisible"; }, never, never, true, never>;
}
