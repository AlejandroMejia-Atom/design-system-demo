import * as i0 from "@angular/core";
export declare class AtomLoadedDirective {
    loaded: import("@angular/core").OutputEmitterRef<void>;
    private readonly elRef;
    constructor();
    onLoad(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomLoadedDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomLoadedDirective, "img[atomLoaded]", never, {}, { "loaded": "atomLoaded"; }, never, never, true, never>;
}
