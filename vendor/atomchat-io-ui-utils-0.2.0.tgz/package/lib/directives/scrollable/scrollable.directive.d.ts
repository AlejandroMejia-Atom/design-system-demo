import * as i0 from "@angular/core";
export declare class AtomScrollableDirective {
    scrollPosition: import("@angular/core").OutputEmitterRef<"top" | "bottom" | "up" | "down">;
    scrolledToTop: import("@angular/core").OutputEmitterRef<void>;
    private isAtBottom;
    private isAtTop;
    private lastScrollTop;
    private readonly SCROLL_THRESHOLD;
    private readonly el;
    onScroll(event: Event): void;
    resetScroll(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtomScrollableDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtomScrollableDirective, "[atomScrollable]", never, {}, { "scrollPosition": "atomScrollPosition"; "scrolledToTop": "atomScrolledToTop"; }, never, never, true, never>;
}
