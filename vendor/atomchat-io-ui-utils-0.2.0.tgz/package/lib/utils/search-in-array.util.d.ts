/**
 * Returns true if the given item contains the search value in any of the
 * specified properties. Supports dot-notation for nested access
 * (e.g. `'contact.name'`). If no properties are specified, searches across
 * all values of the item. Search is case-insensitive.
 */
export declare function searchInObject<T>(item: T, value: string, propsForSearch?: readonly (keyof T | string)[]): boolean;
/**
 * Filters an array of objects by a search string. Returns items where any of
 * the specified properties match the value (case-insensitive). Supports
 * dot-notation for nested properties. If no properties are specified, searches
 * across all values of each item. Returns the original array unchanged when
 * the search value is empty or the array is empty.
 */
export declare function searchInArray<T>(array: T[], value: string, propsForSearch?: (keyof T | string)[]): T[];
