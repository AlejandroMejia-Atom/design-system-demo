export declare const DIACRITIC_MAP: Record<string, string>;
