'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'blog';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f781';
var svgPathData = 'M224 24c0-13.3 10.7-24 24-24 145.8 0 264 118.2 264 264 0 13.3-10.7 24-24 24s-24-10.7-24-24c0-119.3-96.7-216-216-216-13.3 0-24-10.7-24-24zM56 96c13.3 0 24 10.7 24 24l0 248c0 53 43 96 96 96s96-43 96-96-43-96-96-96l-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l24 0c79.5 0 144 64.5 144 144S255.5 512 176 512 32 447.5 32 368l0-248c0-13.3 10.7-24 24-24zm192 0c92.8 0 168 75.2 168 168 0 13.3-10.7 24-24 24s-24-10.7-24-24c0-66.3-53.7-120-120-120-13.3 0-24-10.7-24-24s10.7-24 24-24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlog = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;