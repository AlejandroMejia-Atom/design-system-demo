'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bee';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e0b2';
var svgPathData = 'M311 7c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9L329.8 56.1c9 13.8 14.2 30.2 14.2 47.9l0 13.4C440.2 139.2 512 225.2 512 328l0 32-.1 2.5C510.6 374.6 500.4 384 488 384l-40 0c-21.4 0-42.1-3.2-61.7-9-28.9 59.7-95.3 115.6-116 132.1l-3.2 2.1c-3.4 1.8-7.2 2.7-11.1 2.7s-7.7-.9-11.1-2.7l-3.2-2.1c-20.7-16.5-87.2-72.4-116.1-132.1-19.5 5.8-40.2 9-61.7 9l-40 0c-12.4 0-22.6-9.4-23.9-21.5L0 360 0 328C0 225.2 71.8 139.2 168 117.4l0-13.4c0-17.7 5.2-34.1 14.2-47.9L167 41 165.4 39.2c-7.7-9.4-7.1-23.3 1.7-32.1s22.7-9.3 32.1-1.7L201 7 218.4 24.5C229.8 19.1 242.5 16 256 16s26.1 3.1 37.5 8.5L311 7zM217.6 420c13.8 14.5 27.6 27.1 38.4 36.5 10.8-9.4 24.6-21.9 38.4-36.5l-76.9 0zm-47.6-63.8c3.8 7.4 8.5 15.4 14.4 23.8l143.3 0c5.9-8.4 10.6-16.4 14.4-23.8-.1-.1-.2-.1-.3-.2l-171.4 0c-.1 .1-.3 .1-.4 .2zM216 160c-92.8 0-168 75.2-168 168l0 8 16 0c92.8 0 168-75.2 168-168l0-8-16 0zm64 8c0 92.8 75.2 168 168 168l16 0 0-8c0-92.8-75.2-168-168-168l-16 0 0 8zm-24 98.9c-9.3 18-21 34.5-34.8 49.1l69.5 0c-13.7-14.6-25.5-31.1-34.7-49.1zM256 64c-22.1 0-40 17.9-40 40l0 8 80 0 0-8c0-22.1-17.9-40-40-40z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBee = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;