'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-u-turn-up-left';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e7ed';
var svgPathData = 'M7.1 145c-9.4-9.4-9.4-24.6 0-33.9L127.1-9c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9L82 104 324 104c103.8 0 188 84.2 188 188S427.8 480 324 480l-236 0-2.5-.1C73.5 478.6 64 468.4 64 456s9.4-22.6 21.5-23.9l2.5-.1 236 0c77.3 0 140-62.7 140-140S401.3 152 324 152l-242.1 0 79 79 1.7 1.8c7.7 9.4 7.1 23.3-1.7 32.1s-22.7 9.3-32.1 1.7l-1.8-1.7-120-120z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnUpLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;