'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-down-right';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e093';
var svgPathData = 'M360 448c13.3 0 24-10.7 24-24l0-240c0-13.3-10.7-24-24-24s-24 10.7-24 24L336 366.1 41 71C31.6 61.7 16.4 61.7 7 71S-2.3 95.6 7 105l295 295-182.1 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l240 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;