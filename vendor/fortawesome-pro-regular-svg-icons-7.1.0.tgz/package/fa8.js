'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = '8';
var width = 320;
var height = 512;
var aliases = [];
var unicode = '38';
var svgPathData = 'M304 156c0-68.5-55.5-124-124-124l-40 0C71.5 32 16 87.5 16 156 16 193.7 32.8 227.4 59.3 250.2 23.7 272 0 311.2 0 356 0 424.5 55.5 480 124 480l72 0c68.5 0 124-55.5 124-124 0-44.8-23.7-84-59.3-105.8 26.5-22.7 43.3-56.5 43.3-94.2zM180.1 280l15.9 0c42 0 76 34 76 76s-34 76-76 76l-72 0c-42 0-76-34-76-76s34-76 76-76l56.1 0zm0-48L140 232c-42 0-76-34-76-76 0-42 34-76 76-76l40 0c42 0 76 34 76 76 0 42-34 76-76 76z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.fa8 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;