'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-sparkles';
var width = 448;
var height = 512;
var aliases = ["book-spells"];
var unicode = 'f6b8';
var svgPathData = 'M88 0C39.4 0 0 39.4 0 88L0 432c0 44.2 35.8 80 80 80l344 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-76.1C435.3 375 448 353 448 328l0-256c0-39.8-32.2-72-72-72L88 0zM368 400l0 64-288 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l288 0zM80 352c-11.4 0-22.2 2.4-32 6.7L48 88c0-22.1 17.9-40 40-40l288 0c13.3 0 24 10.7 24 24l0 256c0 13.3-10.7 24-24 24L80 352zM259.2 195.2l-46.6 20c-7.8 3.3-7.8 14.3 0 17.6l46.6 20 20 46.6c3.3 7.8 14.3 7.8 17.6 0l20-46.6 46.6-20c7.8-3.3 7.8-14.3 0-17.6l-46.6-20-20-46.6c-3.3-7.8-14.3-7.8-17.6 0l-20 46.6zM150.5 83.1l-11.8 23.6-23.6 11.8c-7.9 3.9-7.9 15.2 0 19.1l23.6 11.8 11.8 23.6c3.9 7.9 15.2 7.9 19.1 0l11.8-23.6 23.6-11.8c7.9-3.9 7.9-15.2 0-19.1l-23.6-11.8-11.8-23.6c-3.9-7.9-15.2-7.9-19.1 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookSparkles = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;