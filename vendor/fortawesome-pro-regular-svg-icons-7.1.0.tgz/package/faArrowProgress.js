'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-progress';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e5df';
var svgPathData = 'M230.8 33.8c9-3.7 19.3-1.7 26.2 5.2l40 40c9.4 9.4 9.4 24.6 0 33.9l-40 40c-6.9 6.9-17.2 8.9-26.2 5.2S216 145.7 216 136l0-16-112 0c-30.9 0-56 25.1-56 56s25.1 56 56 56l304 0c57.4 0 104 46.6 104 104 0 44.1-27.5 81.8-66.3 96.9-7.4 27.1-32.3 47.1-61.7 47.1-35.3 0-64-28.7-64-64s28.7-64 64-64c23.2 0 43.5 12.3 54.7 30.8 15.2-10 25.3-27.2 25.3-46.8 0-30.9-25.1-56-56-56l-304 0C46.6 280 0 233.4 0 176S46.6 72 104 72l112 0 0-16c0-9.7 5.8-18.5 14.8-22.2zM440 96a24 24 0 1 0 -48 0 24 24 0 1 0 48 0zm-88 0a64 64 0 1 1 128 0 64 64 0 1 1 -128 0zM96 440a24 24 0 1 0 0-48 24 24 0 1 0 0 48zm59.3 0c-9.5 23.5-32.5 40-59.3 40-35.3 0-64-28.7-64-64s28.7-64 64-64c26.9 0 49.9 16.5 59.3 40l28.7 0 0-16c0-9.7 5.8-18.5 14.8-22.2s19.3-1.7 26.2 5.2l40 40c9.4 9.4 9.4 24.6 0 33.9l-40 40c-6.9 6.9-17.2 8.9-26.2 5.2S184 465.7 184 456l0-16-28.7 0zM384 440a24 24 0 1 0 0-48 24 24 0 1 0 0 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowProgress = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;