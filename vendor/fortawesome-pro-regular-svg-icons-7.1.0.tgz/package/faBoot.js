'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'boot';
var width = 448;
var height = 512;
var aliases = [129406];
var unicode = 'f782';
var svgPathData = 'M272 48l0 48-224 0 0-48 224 0zM0 48L0 442.5c0 17 6.2 33.3 17.4 46 13.2 14.9 32.2 23.5 52.1 23.5l4.5 0c18.3 0 36-6.3 50-17.7 14 11.4 31.7 17.7 50 17.7s36-6.3 50-17.7c14 11.4 31.7 17.7 50 17.7s36-6.3 50-17.7c14 11.4 31.7 17.7 50 17.7l4.5 0c19.9 0 38.9-8.6 52.1-23.5 11.2-12.7 17.4-29.1 17.4-46l0-58.5c0-5.4-.3-10.8-1-16-7.9-63.1-61.7-112-127-112l-16 0 0-124.2c9.8-8.8 16-21.6 16-35.8l0-48c0-26.5-21.5-48-48-48L48 0C21.5 0 0 21.5 0 48zM400 416l0 26.5c0 5.3-1.9 10.3-5.4 14.2-4.1 4.6-10 7.3-16.1 7.3l-4.5 0c-9 0-17.6-3.9-23.6-10.6l-3.1-3.5c-12.4-14-34.3-14-46.7 0l-3.1 3.5c-6 6.8-14.6 10.6-23.6 10.6s-17.6-3.9-23.6-10.6l-3.1-3.5c-12.4-14-34.3-14-46.7 0l-3.1 3.5c-6 6.8-14.6 10.6-23.6 10.6s-17.6-3.9-23.6-10.6l-3.1-3.5c-12.4-14-34.3-14-46.7 0l-3.1 3.5C91.6 460.1 83 464 74 464l-4.5 0c-6.2 0-12-2.6-16.1-7.3-3.5-3.9-5.4-9-5.4-14.2l0-26.5 352 0zM48 144l208 0 0 32-40 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l40 0 0 32-40 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l104 0c38.7 0 71 27.5 78.4 64L48 368 48 144z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoot = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;