'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'axe';
var width = 640;
var height = 512;
var aliases = [129683];
var unicode = 'f6b2';
var svgPathData = 'M489 7l48 48c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0L455 41c-9.4-9.4-9.4-24.6 0-33.9S479.6-2.3 489 7zm2.7 184.6L352 51.9 275.9 128 415.6 267.7c10.5 10.5 16.4 24.7 16.4 39.6l0 60c84.4-7.6 151.7-74.8 159.3-159.3l-60 0c-14.9 0-29.1-5.9-39.6-16.4zM385.9 17.9L525.7 157.7c1.5 1.5 3.5 2.3 5.7 2.3l84.7 0c13.3 0 24 10.7 24 24l0 8c0 123.7-100.3 224-224 224l-8 0c-13.3 0-24-10.7-24-24l0-84.7c0-2.1-.8-4.2-2.3-5.7L361 281 153 489c-27 27-70.9 27-97.9 0S28 418.1 55 391l208-208-21.1-21.1c-18.7-18.7-18.7-49.1 0-67.9l76.1-76.1c18.7-18.7 49.1-18.7 67.9 0zM297 217L89 425c-8.3 8.3-8.3 21.8 0 30.1s21.8 8.3 30.1 0L327 247 297 217z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAxe = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;