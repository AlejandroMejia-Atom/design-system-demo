'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bar-progress-half';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6a7';
var svgPathData = 'M448 144c8.8 0 16 7.2 16 16l0 192c0 8.8-7.2 16-16 16l-176 0 0-224 176 0zm-246.1 0l22.1 0 0 70.1-153.9 153.9-6.1 0c-8.8 0-16-7.2-16-16L48 297.9 201.9 144zM134 144l-86 86 0-70c0-8.8 7.2-16 16-16l70 0zm3.9 224l86.1-86.1 0 86.1-86.1 0zM64 96C28.7 96 0 124.7 0 160L0 352c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-192c0-35.3-28.7-64-64-64L64 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarProgressHalf = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;