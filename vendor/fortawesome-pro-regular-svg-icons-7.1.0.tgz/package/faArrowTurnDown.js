'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-turn-down';
var width = 384;
var height = 512;
var aliases = ["level-down"];
var unicode = 'f149';
var svgPathData = 'M24 48C10.7 48 0 37.3 0 24S10.7 0 24 0l96 0c53 0 96 43 96 96l0 334.1 95-95c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9L209 505c-4.5 4.5-10.6 7-17 7s-12.5-2.5-17-7L39 369c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l95 95 0-334.1c0-26.5-21.5-48-48-48L24 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowTurnDown = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;