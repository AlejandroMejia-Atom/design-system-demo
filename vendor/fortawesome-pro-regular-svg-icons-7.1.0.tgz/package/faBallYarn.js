'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'ball-yarn';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6ce';
var svgPathData = 'M49.4 280l413.3 0c-1.9 16.7-5.8 32.8-11.4 48L60.8 328c-5.6-15.2-9.5-31.3-11.4-48zm124 167l19-71 66.6 0-23.3 87c-21.9-2.1-42.9-7.7-62.3-16.1zm-43-25.1c-17-12.9-32-28.4-44.4-45.8l56.6 0-12.3 45.8zM425.9 376c-32.3 45.6-82.4 77.6-140.2 85.9l23-85.9 117.2 0zm-20.6 88C469.9 417.5 512 341.7 512 256 512 114.6 397.4 0 256 0S0 114.6 0 256 114.6 512 256 512l232 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-82.7 0zm57.4-232L49.4 232c1.9-16.7 5.8-32.8 11.4-48l390.4 0c5.6 15.2 9.5 31.3 11.4 48zM230.2 49.6L207 136 86.1 136c33-46.6 84.7-79.1 144.1-86.4zm49.8-.2c21.9 2.5 42.7 8.4 62 17.2l-18.6 69.5-66.6 0 23.2-86.6zm146 86.6l-52.9 0 11.6-43.4c15.7 12.4 29.7 27.1 41.3 43.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBallYarn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;