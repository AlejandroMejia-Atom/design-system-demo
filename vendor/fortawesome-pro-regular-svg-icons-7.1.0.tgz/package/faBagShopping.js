'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bag-shopping';
var width = 448;
var height = 512;
var aliases = ["shopping-bag"];
var unicode = 'f290';
var svgPathData = 'M160 80l0 48 128 0 0-48c0-35.3-28.7-64-64-64s-64 28.7-64 64zm-48 96l-64 0 0 208c0 26.5 21.5 48 48 48l256 0c26.5 0 48-21.5 48-48l0-208-64 0 0 56c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-56-128 0 0 56c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-56zm0-48l0-48c0-61.9 50.1-112 112-112S336 18.1 336 80l0 48 64 0c26.5 0 48 21.5 48 48l0 208c0 53-43 96-96 96L96 480c-53 0-96-43-96-96L0 176c0-26.5 21.5-48 48-48l64 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBagShopping = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;