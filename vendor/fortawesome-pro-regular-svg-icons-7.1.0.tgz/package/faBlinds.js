'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'blinds';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f8fb';
var svgPathData = 'M24.2 32l400 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-264 0 0 248c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-248-88 0C10.9 80 .2 69.3 .2 56s10.7-24 24-24zM-1.6 196.1l15.5-68.1 49.2 0-14.6 64 15.6 0 0 62.2-14.4 49.8 14.4 0 0 68.8-15.1 59.2 347.9 0-18.8-80-170 0 0-48 188.2 0-17.1-64-171.1 0 0-48 189.3 0-13.5-64 49.1 0 14.4 68.3c.5 2.5 .8 5 .8 7.5 0 14.3-8.2 26.6-20.2 32.5l19 71.3c.8 3 1.2 6 1.2 9.1 0 14.6-8.8 27.1-21.4 32.5L447.2 436c.6 2.7 1 5.4 1 8.2 0 19.8-16 35.8-35.8 35.8L33 480c-19.6 0-35.5-15.9-35.5-35.5 0-3 .4-5.9 1.1-8.8l21.9-85.8c-13.4-4.9-23-17.8-23-32.9 0-3.3 .5-6.6 1.4-9.7L19.2 237c-12.7-5.5-21.7-18.2-21.7-33 0-2.7 .3-5.4 .9-8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlinds = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;