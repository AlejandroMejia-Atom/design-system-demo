'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'anchor-circle-exclamation';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4ab';
var svgPathData = 'M288 48a40 40 0 1 0 0 80 40 40 0 1 0 0-80zM200 88c0-48.6 39.4-88 88-88s88 39.4 88 88c0 40.3-27.1 74.2-64 84.7L312 345c-5.2 17.4-8 35.9-8 55 0 33.4 8.5 64.8 23.5 92.1-12.8 2.6-26 3.9-39.5 3.9-110.5 0-200-89.5-200-200l0-11.1-24.2 21.2c-10 8.7-25.1 7.7-33.9-2.3s-7.7-25.1 2.3-33.9l64-56c9-7.9 22.6-7.9 31.6 0l64 56c10 8.7 11 23.9 2.3 33.9s-23.9 11-33.9 2.3L136 284.9 136 296c0 75.8 55.5 138.6 128 150.1l0-273.4c-36.9-10.4-64-44.4-64-84.7zM496 256a144 144 0 1 1 0 288 144 144 0 1 1 0-288zm0 228a20 20 0 1 0 0-40 20 20 0 1 0 0 40zm0-180c-8.8 0-16 7.2-16 16l0 80c0 8.8 7.2 16 16 16s16-7.2 16-16l0-80c0-8.8-7.2-16-16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnchorCircleExclamation = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;