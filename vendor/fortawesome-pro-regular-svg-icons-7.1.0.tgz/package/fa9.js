'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = '9';
var width = 384;
var height = 512;
var aliases = [];
var unicode = '39';
var svgPathData = 'M208 320c36.9 0 70.5-13.9 96-36.7l0 52.7c0 53-43 96-96 96l-104 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l104 0c79.5 0 144-64.5 144-144l0-160.1C352 96.4 287.5 32 208 32l-48 0C80.5 32 16 96.5 16 176S80.5 320 160 320l48 0zm96-144c0 53-43 96-96 96l-48 0c-53 0-96-43-96-96s43-96 96-96l48 0c53 0 96 43 96 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.fa9 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;