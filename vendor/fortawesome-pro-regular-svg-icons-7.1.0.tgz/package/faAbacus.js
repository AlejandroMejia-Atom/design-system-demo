'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'abacus';
var width = 576;
var height = 512;
var aliases = [129518];
var unicode = 'f640';
var svgPathData = 'M512 80c8.8 0 16 7.2 16 16l0 112-80 0 0-32 8 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-48 64 0zm-96 48l-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l8 0 0 32-128 0 0-32 8 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-48 128 0 0 48zm-160 0l-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l8 0 0 32-96 0 0-32 8 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-48 96 0 0 48zm-128 0l-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l8 0 0 32-80 0 0-112c0-8.8 7.2-16 16-16l64 0 0 48zM48 416l0-176 80 0 0 24-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l8 0 0 24-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l8 0 0 48-64 0c-8.8 0-16-7.2-16-16zm112-32l8 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-24 8 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-24 96 0 0 24-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l8 0 0 24-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l8 0 0 48-96 0 0-48zm128-72l8 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-24 128 0 0 96-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l8 0 0 48-128 0 0-48 8 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-24zm160 72l8 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-96 80 0 0 176c0 8.8-7.2 16-16 16l-64 0 0-48zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAbacus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;