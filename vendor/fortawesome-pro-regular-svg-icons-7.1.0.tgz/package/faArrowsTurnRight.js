'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrows-turn-right';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e4c0';
var svgPathData = 'M319-9c9.4-9.4 24.6-9.4 33.9 0l88 88c9.4 9.4 9.4 24.6 0 33.9l-88 88c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l47-47-238.1 0c-44.2 0-80 35.8-80 80l0 32c0 13.3-10.7 24-24 24S0 245.3 0 232l0-32C0 129.3 57.3 72 128 72l238.1 0-47-47c-9.4-9.4-9.4-24.6 0-33.9zM231 255c9.4-9.4 24.6-9.4 33.9 0l80 80c9.4 9.4 9.4 24.6 0 33.9l-80 80c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l39-39-174.1 0c-26.5 0-48 21.5-48 48l0 32c0 13.3-10.7 24-24 24S0 469.3 0 456l0-32c0-53 43-96 96-96l174.1 0-39-39c-9.4-9.4-9.4-24.6 0-33.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsTurnRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;