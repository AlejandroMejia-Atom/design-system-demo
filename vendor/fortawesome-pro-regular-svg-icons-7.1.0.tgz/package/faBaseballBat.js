'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'baseball-bat';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e7e5';
var svgPathData = 'M445.5-14.9c31.4-25.6 77.8-23.8 107.1 5.5l38.3 38.9c23.9 29.3 23.9 71.7 0 101L409.3 312.6c-7 7-14.8 12.7-23.1 18L246.5 414.5c-5 3-9.7 6.7-13.8 10.8l-97.3 97.3c1.8 7.8-.2 16.3-6.3 22.3-8.8 8.8-22.7 9.3-32.1 1.7L29.4 479.2c-7.7-9.4-7.1-23.3 1.7-32.1 6.1-6.1 14.5-8.1 22.3-6.3l97.3-97.3c4-4.3 7.8-8.8 10.8-13.8l83.8-139.7c5-8.4 11.1-16.2 18-23.1L445.5-14.9zM89.9 472L104 486.1 182.1 408 168 393.9 89.9 472zM518.6 24.6c-12.5-12.5-32.8-12.5-45.2 0L297.3 200.6c-4.2 4.2-7.8 8.8-10.8 13.8-28.7 47.8-55.8 97.1-86.4 143.7l17.7 17.7c46.6-30.6 95.9-57.7 143.7-86.4 5-3.2 9.7-6.6 13.8-10.8L551.4 102.6c11.7-11.7 12.4-30.2 2.2-42.8l-35-35.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBaseballBat = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;