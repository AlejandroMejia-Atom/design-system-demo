'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-down-1-9';
var width = 512;
var height = 512;
var aliases = ["sort-numeric-asc","sort-numeric-down"];
var unicode = 'f162';
var svgPathData = 'M233.5 385l-88 88c-9.4 9.4-24.6 9.4-33.9 0l-88-88c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47 0-342.1c0-13.3 10.7-24 24-24s24 10.7 24 24l0 342.1 47-47c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9zm191-329l0 120 32 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-112 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l32 0 0-88.2-25.4 7.3c-12.7 3.6-26-3.7-29.7-16.5s3.7-26 16.5-29.7l56-16c7.2-2.1 15-.6 21 3.9s9.5 11.6 9.5 19.2zm8 280a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM373.1 441.9l19.1-26.3c-40.3-4.1-71.7-38.2-71.7-79.6 0-44.2 35.8-80 80-80s80 35.8 80 80c0 25.9-8.2 51.1-23.4 72l-45.2 62.1c-7.8 10.7-22.8 13.1-33.5 5.3s-13.1-22.8-5.3-33.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDown19 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;