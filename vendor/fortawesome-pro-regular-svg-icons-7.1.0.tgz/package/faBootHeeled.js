'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'boot-heeled';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e33f';
var svgPathData = 'M24 0C17.1 0 10.6 2.9 6 8.1S-.7 20.1 .2 26.9L30.4 276.6c.7 5.9 .1 11.8-1.8 17.5L7.8 356.7C2.6 372.2 0 388.4 0 404.8L0 488c0 13.3 10.7 24 24 24l112 0c13.3 0 24-10.7 24-24l0-29.6 53.3 32c23.6 14.2 50.7 21.7 78.2 21.7L424 512c13.3 0 24-10.7 24-24l0-49.2c0-32.8-18.2-62.9-47.3-78L288.9 302.4c-14.3-7.5-22.7-22.8-21.4-38.9L287.9 26c.6-6.7-1.7-13.3-6.2-18.3S270.7 0 264 0L24 0zM48 440l64 0 0 24-64 0 0-24zm88-48l-87.2 0c.8-6.8 2.4-13.6 4.5-20.1l20.9-62.6c4.1-12.4 5.4-25.5 3.9-38.4L51.1 48 112 48 112 200c0 13.3 10.7 24 24 24s24-10.7 24-24l0-152 77.9 0-18.1 211.5c-3 35.4 15.5 69.1 47 85.5l111.8 58.3c13.2 6.9 21.5 20.6 21.5 35.5l0 25.2-108.5 0c-18.8 0-37.3-5.1-53.5-14.8l-89.6-53.8c-3.7-2.2-8-3.4-12.3-3.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBootHeeled = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;