'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bell-on';
var width = 640;
var height = 512;
var aliases = [128365];
var unicode = 'f8fa';
var svgPathData = 'M606.1 14.5C600.8 2.4 586.7-3.3 574.5 1.9l-56 24c-12.2 5.2-17.8 19.3-12.6 31.5s19.3 17.8 31.5 12.6l56-24c12.2-5.2 17.8-19.3 12.6-31.5zM320 0c-13.3 0-24 10.7-24 24l0 9.7C214.6 45.3 152 115.4 152 200l0 14.5c0 37.7-10 74.7-29 107.3l-21.9 37.5c-3.4 5.8-5.1 12.3-5.1 19 0 20.9 16.9 37.8 37.8 37.8l372.4 0c20.9 0 37.8-16.9 37.8-37.8 0-6.7-1.8-13.3-5.1-19L517 321.7c-19-32.6-29-69.6-29-107.3l0-14.5c0-84.6-62.6-154.7-144-166.3l0-9.7c0-13.3-10.7-24-24-24zM488.4 368l-336.9 0 12.9-22.1C187.7 306 200 260.6 200 214.5l0-14.5c0-66.3 53.7-120 120-120s120 53.7 120 120l0 14.5c0 46.2 12.3 91.5 35.5 131.4L488.4 368zM252.1 464c9.9 28 36.6 48 67.9 48s58-20 67.9-48l-135.8 0zM0 184c0 13.3 10.7 24 24 24l64 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-64 0c-13.3 0-24 10.7-24 24zm552-24c-13.3 0-24 10.7-24 24s10.7 24 24 24l64 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-64 0zM46.5 46.1l56 24c12.2 5.2 26.3-.4 31.5-12.6s-.4-26.3-12.6-31.5l-56-24C53.3-3.3 39.2 2.4 33.9 14.5s.4 26.3 12.6 31.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellOn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;