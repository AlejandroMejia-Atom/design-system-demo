'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-down-z-a';
var width = 512;
var height = 512;
var aliases = ["sort-alpha-desc","sort-alpha-down-alt"];
var unicode = 'f881';
var svgPathData = 'M233.5 385l-88 88c-9.4 9.4-24.6 9.4-33.9 0l-88-88c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47 0-342.1c0-13.3 10.7-24 24-24s24 10.7 24 24l0 342.1 47-47c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9zm55-329c0-13.3 10.7-24 24-24l144 0c9.7 0 18.5 5.8 22.2 14.8s1.7 19.3-5.2 26.2l-103 103 86.1 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-144 0c-9.7 0-18.5-5.8-22.2-14.8s-1.7-19.3 5.2-26.2l103-103-86.1 0c-13.3 0-24-10.7-24-24zM406 285.3l80 160c5.9 11.9 1.1 26.3-10.7 32.2S449 478.6 443 466.7l-13.6-27.2c-1.6 .3-3.2 .5-4.9 .5l-85.2 0-13.4 26.7c-5.9 11.9-20.3 16.7-32.2 10.7s-16.7-20.3-10.7-32.2l80-160c4.1-8.1 12.4-13.3 21.5-13.3s17.4 5.1 21.5 13.3zm-21.5 64.4l-21.2 42.3 42.3 0-21.2-42.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownZA = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;