'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'backward-step';
var width = 384;
var height = 512;
var aliases = ["step-backward"];
var unicode = 'f048';
var svgPathData = 'M78.6 256L336 425.2 336 86.8 78.6 256zM363 475.2c-12.9 7-28.7 6.3-41-1.8L48 293.4 48 456c0 13.3-10.7 24-24 24S0 469.3 0 456L0 56C0 42.7 10.7 32 24 32S48 42.7 48 56L48 218.7 322 38.6c12.3-8.1 28-8.8 41-1.8S384 57.3 384 72l0 368c0 14.7-8.1 28.2-21 35.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBackwardStep = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;