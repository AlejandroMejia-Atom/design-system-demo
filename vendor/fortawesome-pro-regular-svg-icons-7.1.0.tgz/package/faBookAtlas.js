'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-atlas';
var width = 448;
var height = 512;
var aliases = ["atlas"];
var unicode = 'f558';
var svgPathData = 'M0 88C0 39.4 39.4 0 88 0L376 0c39.8 0 72 32.2 72 72l0 256c0 25-12.7 47-32 59.9l0 76.1 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L80 512c-44.2 0-80-35.8-80-80L0 88zM48 432c0 17.7 14.3 32 32 32l288 0 0-64-288 0c-17.7 0-32 14.3-32 32zm0-73.3c9.8-4.3 20.6-6.7 32-6.7l296 0c13.3 0 24-10.7 24-24l0-256c0-13.3-10.7-24-24-24L88 48C65.9 48 48 65.9 48 88l0 270.7zM302.4 216l-26.9 0c-1.3 19.7-5 37.7-10.4 52.7 18.9-11.4 32.8-30.3 37.3-52.7zm-156.8 0c4.5 22.3 18.4 41.3 37.3 52.7-5.4-15-9.1-33-10.4-52.7l-26.9 0zm70.7 49.7c3.2 6.9 5.9 10.6 7.7 12.6 1.8-1.9 4.5-5.6 7.7-12.6 5.6-12.1 10.1-29.3 11.6-49.7l-38.8 0c1.6 20.4 6 37.6 11.6 49.7zm0-131.4c-5.6 12.1-10.1 29.3-11.6 49.7l38.8 0c-1.6-20.4-6-37.6-11.6-49.7-3.2-6.9-5.9-10.6-7.7-12.6-1.8 1.9-4.5 5.6-7.7 12.6zM302.4 184c-4.5-22.3-18.4-41.3-37.3-52.7 5.4 15 9.1 33 10.4 52.7l26.9 0zm-129.9 0c1.3-19.7 5-37.7 10.4-52.7-18.9 11.4-32.8 30.3-37.3 52.7l26.9 0zM104 200a120 120 0 1 1 240 0 120 120 0 1 1 -240 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookAtlas = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;