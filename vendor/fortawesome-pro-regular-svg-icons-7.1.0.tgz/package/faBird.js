'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bird';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e469';
var svgPathData = 'M400 192l0-80c0-35.3-28.7-64-64-64s-64 28.7-64 64l0 16c0 44.2-35.8 80-80 80L48.8 208c8.1 89.7 83.4 160 175.2 160 97.2 0 176-78.8 176-176zM224 416c-1 0-2 0-3 0l32.2 60.8 1 2.2c4.6 11.3 0 24.4-11 30.2s-24.4 2.2-31.2-7.9l-1.2-2.1-48.6-91.9C68.5 380.5 0 294.3 0 192l0-3.6c0-14.7 11.2-26.8 25.5-28.3l2.9-.2 163.6 0c17.7 0 32-14.3 32-32l0-16c0-61.9 50.1-112 112-112 49.7 0 91.9 32.4 106.5 77.3l61.7 37c4.8 2.9 7.8 8.1 7.8 13.7s-3 10.8-7.8 13.7l-56.2 33.7 0 16.6-.3 11.5c-4.5 88.9-60.8 164.1-139.4 196l40.9 77.2 1 2.2c4.6 11.3 0 24.4-11 30.2s-24.4 2.2-31.2-7.9l-1.3-2.1-45.7-86.3C249 415 236.6 416 224 416zM336 96a24 24 0 1 1 0 48 24 24 0 1 1 0-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBird = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;