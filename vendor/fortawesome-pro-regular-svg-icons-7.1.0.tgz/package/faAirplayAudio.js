'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'airplay-audio';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e77b';
var svgPathData = 'M48 256c0 53.1 19.9 101.5 52.6 138.3L71.4 423.4C69.8 425.1 68.3 426.7 66.8 428.5 25.3 383 0 322.4 0 256 0 114.6 114.6 0 256 0S512 114.6 512 256c0 66.4-25.3 127-66.8 172.5-1.5-1.7-3-3.4-4.6-5l-29.2-29.2C444.1 357.5 464 309.1 464 256 464 141.1 370.9 48 256 48S48 141.1 48 256zm368 0c0 39.8-14.5 76.2-38.6 104.2l-34.1-34.1c15.4-19.2 24.7-43.6 24.7-70.2 0-61.9-50.1-112-112-112S144 194.1 144 256c0 26.6 9.2 51 24.7 70.2l-34.1 34.1C110.5 332.2 96 295.8 96 256 96 167.6 167.6 96 256 96s160 71.6 160 160zm-96 0c0 13.3-4.1 25.6-11 35.9L272 254.8c-.6-8.3-7.5-14.8-16-14.8s-15.4 6.5-16 14.8L203 291.9c-6.9-10.2-11-22.6-11-35.9 0-35.3 28.7-64 64-64s64 28.7 64 64zM256 374.6l-89.4 89.4 178.7 0-89.4-89.4zM128 512c-12.9 0-24.6-7.8-29.6-19.8s-2.2-25.7 6.9-34.9l128-128c12.5-12.5 32.8-12.5 45.3 0l128 128c9.2 9.2 11.9 22.9 6.9 34.9S396.9 512 384 512l-256 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAirplayAudio = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;