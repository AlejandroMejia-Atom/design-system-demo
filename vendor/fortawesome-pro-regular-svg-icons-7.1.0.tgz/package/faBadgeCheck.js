'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'badge-check';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f336';
var svgPathData = 'M256 0c35.9 0 67.8 17 88.1 43.4 33-4.3 67.6 6.2 93 31.6s35.9 60 31.6 93C495 188.2 512 220.1 512 256s-17 67.8-43.4 88.1c4.3 33-6.2 67.6-31.6 93s-60 35.9-93 31.6C323.8 495 291.9 512 256 512s-67.8-17-88.1-43.4c-33 4.3-67.6-6.2-93-31.6s-35.9-60-31.6-93C17 323.8 0 291.9 0 256s17-67.8 43.4-88.1c-4.3-33 6.2-67.6 31.6-93s60-35.9 93-31.6C188.2 17 220.1 0 256 0zm0 48c-24.1 0-45.1 13.6-55.7 33.6-5.4 10.2-17.3 15.1-28.2 11.7-21.6-6.6-46.1-1.4-63.1 15.7S86.6 150.4 93.2 172c3.4 11-1.5 22.9-11.7 28.2-20 10.6-33.6 31.6-33.6 55.7s13.6 45.1 33.6 55.7c10.2 5.4 15.1 17.3 11.7 28.2-6.6 21.6-1.4 46.1 15.7 63.1s41.5 22.3 63.1 15.7c11-3.4 22.9 1.5 28.2 11.7 10.6 20 31.6 33.6 55.7 33.6s45.1-13.6 55.7-33.6c5.4-10.2 17.3-15.1 28.2-11.7 21.6 6.6 46 1.4 63.1-15.7 17-17 22.3-41.5 15.7-63.1-3.4-11 1.5-22.9 11.7-28.2 20-10.6 33.6-31.6 33.6-55.7s-13.6-45.1-33.6-55.7c-10.2-5.4-15.1-17.3-11.7-28.2 6.6-21.6 1.4-46.1-15.7-63.1S361.6 86.6 340 93.2c-11 3.4-22.9-1.5-28.2-11.7-10.6-20-31.6-33.6-55.7-33.6zm57.4 121.9c7.8-10.7 22.8-13.1 33.5-5.3s13.1 22.8 5.3 33.5L249.8 338.9c-4.2 5.7-10.7 9.4-17.8 9.8s-14-2.2-18.9-7.3l-46.4-48c-9.2-9.5-9-24.7 .6-33.9s24.7-8.9 33.9 .6l26.5 27.4 85.6-117.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBadgeCheck = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;