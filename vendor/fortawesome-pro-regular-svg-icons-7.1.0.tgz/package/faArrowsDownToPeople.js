'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrows-down-to-people';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e4b9';
var svgPathData = 'M113 153l64-64c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-23 23 0-86.1c0-13.3-10.7-24-24-24S72-21.3 72-8l0 86.1-23-23c-9.4-9.4-24.6-9.4-33.9 0S5.7 79.6 15 89l64 64c9.4 9.4 24.6 9.4 33.9 0zm320 0l64-64c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-23 23 0-86.1c0-13.3-10.7-24-24-24S392-21.3 392-8l0 86.1-23-23c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l64 64c9.4 9.4 24.6 9.4 33.9 0zM256 304a56 56 0 1 0 0-112 56 56 0 1 0 0 112zm0 48c-61.9 0-112 50.1-112 112l0 24c0 13.3 10.7 24 24 24s24-10.7 24-24l0-24c0-35.3 28.7-64 64-64s64 28.7 64 64l0 24c0 13.3 10.7 24 24 24s24-10.7 24-24l0-24c0-61.9-50.1-112-112-112zM128 288a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm352 0a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM92 368c-50.8 0-92 41.2-92 92l0 28c0 13.3 10.7 24 24 24s24-10.7 24-24l0-28c0-24.3 19.7-44 44-44 3.8 0 7.4 .5 10.9 1.4 4.8-15.7 11.9-30.4 21-43.7-9.9-3.7-20.7-5.7-31.9-5.7zm317.1 49.4c3.5-.9 7.1-1.4 10.9-1.4 24.3 0 44 19.7 44 44l0 28c0 13.3 10.7 24 24 24s24-10.7 24-24l0-28c0-50.8-41.2-92-92-92-11.2 0-22 2-31.9 5.7 9.1 13.3 16.2 28 21 43.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsDownToPeople = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;