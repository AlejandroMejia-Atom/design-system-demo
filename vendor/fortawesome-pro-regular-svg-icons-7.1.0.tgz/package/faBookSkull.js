'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-skull';
var width = 448;
var height = 512;
var aliases = ["book-dead"];
var unicode = 'f6b7';
var svgPathData = 'M0 88C0 39.4 39.4 0 88 0L376 0c39.8 0 72 32.2 72 72l0 256c0 25-12.7 47-32 59.9l0 76.1 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L80 512c-44.2 0-80-35.8-80-80L0 88zM80 400c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0 0-64-288 0zM48 358.7c9.8-4.3 20.6-6.7 32-6.7l296 0c13.3 0 24-10.7 24-24l0-256c0-13.3-10.7-24-24-24L88 48C65.9 48 48 65.9 48 88l0 270.7zM272 195.2l0 4.8c0 8.8-7.2 16-16 16l-64 0c-8.8 0-16-7.2-16-16l0-4.8c-19.4-11.7-32-30.3-32-51.2 0-35.3 35.8-64 80-64s80 28.7 80 64c0 20.9-12.6 39.5-32 51.2zM208 144a16 16 0 1 0 -32 0 16 16 0 1 0 32 0zm48 16a16 16 0 1 0 0-32 16 16 0 1 0 0 32zm74.8 73.2c3.8 10.4-1.6 21.9-12 25.6l-36.3 13.2 36.3 13.2c10.4 3.8 15.7 15.3 12 25.6s-15.3 15.7-25.6 12l-81.2-29.5-81.2 29.5c-10.4 3.8-21.9-1.6-25.6-12s1.6-21.9 12-25.6l36.3-13.2-36.3-13.2c-10.4-3.8-15.7-15.3-12-25.6s15.2-15.7 25.6-12l81.2 29.5 81.2-29.5c10.4-3.8 21.9 1.6 25.6 12z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookSkull = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;