'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'anchor';
var width = 576;
var height = 512;
var aliases = [9875];
var unicode = 'f13d';
var svgPathData = 'M288 48a40 40 0 1 0 0 80 40 40 0 1 0 0-80zM200 88c0-48.6 39.4-88 88-88s88 39.4 88 88c0 40.3-27.1 74.2-64 84.7l0 273.4c72.5-11.5 128-74.3 128-150.1l0-11.1-24.2 21.2c-10 8.7-25.1 7.7-33.9-2.3s-7.7-25.1 2.3-33.9l64-56c9-7.9 22.6-7.9 31.6 0l64 56c10 8.7 11 23.9 2.3 33.9s-23.9 11-33.9 2.3L488 284.9 488 296c0 110.5-89.5 200-200 200S88 406.5 88 296l0-11.1-24.2 21.2c-10 8.7-25.1 7.7-33.9-2.3s-7.7-25.1 2.3-33.9l64-56c9-7.9 22.6-7.9 31.6 0l64 56c10 8.7 11 23.9 2.3 33.9s-23.9 11-33.9 2.3L136 284.9 136 296c0 75.8 55.5 138.6 128 150.1l0-273.4c-36.9-10.4-64-44.4-64-84.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnchor = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;