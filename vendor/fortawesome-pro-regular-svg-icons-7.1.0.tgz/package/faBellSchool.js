'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bell-school';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f5d5';
var svgPathData = 'M272 48a160 160 0 1 1 0 320 160 160 0 1 1 0-320zm0 368a208 208 0 1 0 0-416 208 208 0 1 0 0 416zm0-240a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm0 112a80 80 0 1 0 0-160 80 80 0 1 0 0 160zm280 64c0-22.1-17.9-40-40-40s-40 17.9-40 40c0 13.1 6.3 24.7 16 32l0 8c0 39.8-32.2 72-72 72l-2 0c1.3-5.1 2-10.5 2-16l0-33.1c-14.9 10.2-31 18.8-48 25.7l0 7.4c0 8.8-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16l0-7.4c-17-6.9-33.1-15.5-48-25.7l0 33.1c0 35.3 28.7 64 64 64l224 0c66.3 0 120-53.7 120-120l0-8c9.7-7.3 16-18.9 16-32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellSchool = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;