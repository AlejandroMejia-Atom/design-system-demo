'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'ankh';
var width = 320;
var height = 512;
var aliases = [9765];
var unicode = 'f644';
var svgPathData = 'M80 128c0 42.3 22.6 78.9 50.5 107.6 10.3 10.6 20.6 19.4 29.5 26.3 8.9-6.9 19.3-15.7 29.5-26.3 27.8-28.7 50.5-65.3 50.5-107.6 0-44.2-35.8-80-80-80S80 83.8 80 128zM98.9 272C66 238.9 32 189.8 32 128 32 57.3 89.3 0 160 0S288 57.3 288 128c0 61.8-34 110.9-67 144l75 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-112 0 0 168c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-168-112 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l74.9 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnkh = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;