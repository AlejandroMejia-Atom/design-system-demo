'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-section';
var width = 448;
var height = 512;
var aliases = ["book-law"];
var unicode = 'e0c1';
var svgPathData = 'M0 88C0 39.4 39.4 0 88 0L376 0c39.8 0 72 32.2 72 72l0 256c0 25-12.7 47-32 59.9l0 76.1 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L80 512c-44.2 0-80-35.8-80-80L0 88zM48 432c0 17.7 14.3 32 32 32l288 0 0-64-288 0c-17.7 0-32 14.3-32 32zm0-73.3c9.8-4.3 20.6-6.7 32-6.7l296 0c13.3 0 24-10.7 24-24l0-256c0-13.3-10.7-24-24-24L88 48C65.9 48 48 65.9 48 88l0 270.7zM192 84l88 0c11 0 20 9 20 20s-9 20-20 20l-88 0c-6.6 0-12 5.4-12 12s5.4 12 12 12l64 0c28.7 0 52 23.3 52 52 0 12.1-4.1 23.2-11 32 6.9 8.8 11 19.9 11 32 0 28.7-23.3 52-52 52l-88 0c-11 0-20-9-20-20s9-20 20-20l88 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-64 0c-28.7 0-52-23.3-52-52 0-12.1 4.1-23.2 11-32-6.9-8.8-11-19.9-11-32 0-28.7 23.3-52 52-52zm64 128c6.6 0 12-5.4 12-12s-5.4-12-12-12l-64 0c-6.6 0-12 5.4-12 12s5.4 12 12 12l64 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookSection = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;