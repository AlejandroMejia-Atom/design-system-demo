'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bezier-curve';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f55b';
var svgPathData = 'M352 80l0 64-64 0 0-64 64 0zM288 32c-26.5 0-48 21.5-48 48l0 8-116.7 0C113.9 64.5 90.9 48 64 48 28.7 48 0 76.7 0 112s28.7 64 64 64c26.9 0 49.9-16.5 59.3-40l79 0C138.2 173.8 93.9 241.5 88.5 320L80 320c-26.5 0-48 21.5-48 48l0 64c0 26.5 21.5 48 48 48l64 0c26.5 0 48-21.5 48-48l0-64c0-26.5-21.5-48-48-48l-7.3 0c5.9-68.4 49.2-126.1 109.4-152.6 8.2 14.7 23.9 24.6 41.9 24.6l64 0c18 0 33.7-9.9 41.9-24.6 60.2 26.4 103.5 84.1 109.4 152.6l-7.3 0c-26.5 0-48 21.5-48 48l0 64c0 26.5 21.5 48 48 48l64 0c26.5 0 48-21.5 48-48l0-64c0-26.5-21.5-48-48-48l-8.5 0c-5.3-78.5-49.7-146.2-113.8-184l79 0c9.5 23.5 32.5 40 59.3 40 35.3 0 64-28.7 64-64s-28.7-64-64-64c-26.9 0-49.9 16.5-59.3 40l-116.7 0 0-8c0-26.5-21.5-48-48-48l-64 0zM48 112a16 16 0 1 1 32 0 16 16 0 1 1 -32 0zm512 0a16 16 0 1 1 32 0 16 16 0 1 1 -32 0zM144 368l0 64-64 0 0-64 64 0zm352 0l64 0 0 64-64 0 0-64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBezierCurve = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;