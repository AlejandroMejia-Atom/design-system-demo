'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'battery-slash';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f377';
var svgPathData = 'M73-24.9c-9.4-9.4-24.6-9.4-33.9 0S29.7-.3 39 9.1l528 528c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-56.8-56.8c36.4-7.5 63.8-39.7 63.8-78.4l0-48c17.7 0 32-14.3 32-32l0-64c0-17.7-14.3-32-32-32l0-48c0-44.2-35.8-80-80-80L161.8 64 73-24.9zM209.8 112L528 112c17.7 0 32 14.3 32 32l0 224c0 17.7-14.3 32-32 32l-30.2 0-288-288zM362.2 400L112 400c-17.7 0-32-14.3-32-32l0-224c0-7.4 2.5-14.1 6.6-19.5L52.6 90.4C39.8 104.6 32 123.4 32 144l0 224c0 44.2 35.8 80 80 80l298.2 0-48-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBatterySlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;