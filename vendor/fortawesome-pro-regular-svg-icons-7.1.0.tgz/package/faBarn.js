'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'barn';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6c7';
var svgPathData = 'M253.6 50.7L88.8 112.5c-2.5 .9-4.4 3-5 5.6l-29 121.9 1.6 0c13.3 0 24 10.7 24 24l0 184c0 8.8 7.2 16 16 16l48 0 0-144c0-17.7 14.3-32 32-32l160 0c17.7 0 32 14.3 32 32l0 144 48 0c8.8 0 16-7.2 16-16l0-184c0-13.3 10.7-24 24-24l1.6 0-29-121.9c-.6-2.6-2.5-4.7-5-5.6L259.2 50.7c-1.8-.7-3.8-.7-5.6 0zM192.4 464l94.1 0-94.1-94.1 0 94.1zm-16 48l-80 0c-35.3 0-64-28.7-64-64l0-160.1c-19.6-1.3-33.6-19.9-29-39.3L37.1 107c4.3-18.1 17.4-32.9 34.8-39.5L236.7 5.7c12.7-4.8 26.6-4.8 39.3 0L440.9 67.5c17.4 6.5 30.5 21.3 34.8 39.5l33.7 141.6c4.6 19.4-9.4 38.1-29 39.3l0 160.1c0 35.3-28.7 64-64 64l-240 0zm56-384l48 0c13.3 0 24 10.7 24 24l0 48c0 13.3-10.7 24-24 24l-48 0c-13.3 0-24-10.7-24-24l0-48c0-13.3 10.7-24 24-24zm88 302.1l0-94.1-94.1 0 94.1 94.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;