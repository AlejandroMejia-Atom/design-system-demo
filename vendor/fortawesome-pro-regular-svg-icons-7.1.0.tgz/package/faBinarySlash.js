'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'binary-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33e';
var svgPathData = 'M7-24.9c9.4-9.4 24.6-9.4 33.9 0l61.3 61.3C112.6 14.9 134.5 0 160 0l64 0c35.3 0 64 28.7 64 64l0 96c0 17.2-6.8 32.8-17.8 44.3l83.7 83.7 62.2 0c35.3 0 64 28.7 64 64l0 62.2 89 89c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0L7 9.1C-2.3-.3-2.3-15.5 7-24.9zM236.2 170.4c2.4-2.8 3.8-6.4 3.8-10.4l0-96c0-8.8-7.2-16-16-16l-64 0c-8.8 0-16 7.2-16 16l0 14.2 92.2 92.2zM394.2 464l44 44c-6.9 2.6-14.4 4-22.2 4l-64 0c-35.3 0-64-28.7-64-64l0-90.2 48 48 0 42.2c0 8.8 7.2 16 16 16l42.2 0zM424 24l0 152 32 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-112 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l32 0 0-118.7-16.4 5.5C347 67 333.4 60.2 329.2 47.6s2.6-26.2 15.2-30.4l48-16C399.7-1.2 407.8 0 414 4.5S424 16.3 424 24zM200 312l0 152 32 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-112 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l32 0 0-118.7-16.4 5.5c-12.6 4.2-26.2-2.6-30.4-15.2s2.6-26.2 15.2-30.4l48-16c7.3-2.4 15.4-1.2 21.6 3.3s10 11.8 10 19.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinarySlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;