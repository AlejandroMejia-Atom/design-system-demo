'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-journal-whills';
var width = 448;
var height = 512;
var aliases = ["journal-whills"];
var unicode = 'f66a';
var svgPathData = 'M0 88C0 39.4 39.4 0 88 0L376 0c39.8 0 72 32.2 72 72l0 256c0 25-12.7 47-32 59.9l0 76.1 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L80 512c-44.2 0-80-35.8-80-80L0 88zM80 400c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0 0-64-288 0zM48 358.7c9.8-4.3 20.6-6.7 32-6.7l296 0c13.3 0 24-10.7 24-24l0-256c0-13.3-10.7-24-24-24L88 48C65.9 48 48 65.9 48 88l0 270.7zM274.1 99.2c2.6-2.6 6.7-3.1 9.9-1.1 32.1 20 53.4 55.6 53.4 96.2 0 62.6-50.7 113.3-113.3 113.3S110.7 256.9 110.7 194.3c0-40.6 21.4-76.2 53.4-96.2 3.1-2 7.2-1.5 9.9 1.1s3.1 6.7 1.2 9.8c-5.2 8.6-8.2 18.7-8.2 29.5 0 16.4 6.9 31.2 18 41.6 2.8 2.6 3.3 6.7 1.4 10-4 6.6-6.3 14.4-6.3 22.8 0 19.5 12.7 36 30.2 41.8L211 234c-7.1-4.4-11.8-12.2-11.8-21.1 0-9.6 5.5-18 13.5-22.1l3.3-81.8c.2-4.3 3.7-7.7 8-7.7s7.8 3.4 8 7.7l3.3 81.8c8 4.1 13.5 12.4 13.5 22.1 0 8.9-4.7 16.7-11.8 21.1l.8 20.7c17.5-5.8 30.2-22.3 30.2-41.8 0-8.3-2.3-16.1-6.3-22.8-2-3.2-1.4-7.4 1.4-10 11.1-10.4 18-25.2 18-41.6 0-10.8-3-20.9-8.2-29.5-1.9-3.2-1.4-7.2 1.2-9.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookJournalWhills = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;