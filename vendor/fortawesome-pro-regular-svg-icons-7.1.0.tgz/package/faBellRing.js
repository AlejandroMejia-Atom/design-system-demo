'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bell-ring';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e62c';
var svgPathData = 'M112.6 41.4C72.8 79.3 48 132.7 48 192 48 205.3 37.3 216 24 216S0 205.3 0 192C0 119.1 30.5 53.2 79.4 6.6 89-2.5 104.2-2.2 113.4 7.4s8.8 24.8-.8 33.9zm320-34.8c48.9 46.6 79.4 112.4 79.4 185.4 0 13.3-10.7 24-24 24s-24-10.7-24-24c0-59.3-24.8-112.7-64.6-150.6-9.6-9.1-10-24.3-.8-33.9s24.3-10 33.9-.8zM232 24c0-13.3 10.7-24 24-24s24 10.7 24 24l0 9.7C361.4 45.3 424 115.4 424 200l0 14.5c0 37.7 10 74.7 29 107.3l21.9 37.5c3.4 5.8 5.1 12.3 5.1 19 0 20.9-16.9 37.8-37.8 37.8L69.8 416c-20.9 0-37.8-16.9-37.8-37.8 0-6.7 1.8-13.3 5.1-19L59 321.7c19-32.6 29-69.6 29-107.3L88 200c0-84.6 62.6-154.7 144-166.3l0-9.7zM411.5 345.9C388.3 306 376 260.6 376 214.5l0-14.5c0-66.3-53.7-120-120-120S136 133.7 136 200l0 14.5c0 46.2-12.3 91.5-35.5 131.4l-12.9 22.1 336.9 0-12.9-22.1zM256 512c-31.3 0-58-20-67.9-48l135.8 0c-9.9 28-36.6 48-67.9 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellRing = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;