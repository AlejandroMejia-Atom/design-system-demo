'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-rotate-left';
var width = 512;
var height = 512;
var aliases = [8634,"arrow-left-rotate","arrow-rotate-back","arrow-rotate-backward","undo"];
var unicode = 'f0e2';
var svgPathData = 'M24 0C37.3 0 48 10.7 48 24L48 102.1 75.1 75c100-100 262.1-100 362 0s100 262.1 0 362-262.1 100-362 0c-14.9-14.9-27.6-31.2-38.1-48.5-6.9-11.3-3.2-26.1 8.1-33s26.1-3.2 33 8.1c8.5 14 18.8 27.3 31 39.4 81.2 81.2 212.9 81.2 294.2 0s81.2-212.9 0-294.2-212.9-81.2-294.2 0l-27.1 27.1 78.2 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L24 184c-13.3 0-24-10.7-24-24L0 24C0 10.7 10.7 0 24 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;