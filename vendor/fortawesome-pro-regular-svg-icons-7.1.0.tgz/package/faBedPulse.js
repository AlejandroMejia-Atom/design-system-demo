'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bed-pulse';
var width = 576;
var height = 512;
var aliases = ["procedures"];
var unicode = 'f487';
var svgPathData = 'M467.2-22.4L508 32 552 32c13.3 0 24 10.7 24 24s-10.7 24-24 24l-56 0c-7.6 0-14.7-3.6-19.2-9.6l-24.1-32.1-47 99.9c-3.7 7.8-11.3 13.1-19.9 13.7s-16.9-3.4-21.7-10.6L323.2 80 280 80c-13.3 0-24-10.7-24-24s10.7-24 24-24l56 0c8 0 15.5 4 20 10.7l24.4 36.6 45.9-97.5c3.6-7.6 10.9-12.8 19.3-13.7s16.6 2.7 21.6 9.5zM272 200c0-24.7 15.9-45.6 38.1-53.1l14 21c6.9 10.4 16.2 18.6 26.9 24.1l-23 0c-4.4 0-8 3.6-8 8l0 136 208 0 0-72c0-39.8-32.2-72-72-72l-39 0c13.9-7.2 25.3-18.7 32.2-33.3L456 144c66.3 0 120 53.7 120 120l0 192c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-72-480 0 0 72c0 13.3-10.7 24-24 24S0 469.3 0 456L0 56C0 42.7 10.7 32 24 32S48 42.7 48 56l0 280 224 0 0-136zm-80 24a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM80 224a80 80 0 1 1 160 0 80 80 0 1 1 -160 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBedPulse = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;