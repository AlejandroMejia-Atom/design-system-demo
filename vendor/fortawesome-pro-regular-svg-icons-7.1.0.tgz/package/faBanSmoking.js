'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'ban-smoking';
var width = 512;
var height = 512;
var aliases = [128685,"smoking-ban"];
var unicode = 'f54d';
var svgPathData = 'M92.9 126.9L385.1 419.1c-35.5 28.1-80.3 44.9-129.1 44.9-114.9 0-208-93.1-208-208 0-48.8 16.8-93.7 44.9-129.1zm165 97.1L126.9 92.9c35.5-28.1 80.3-44.9 129.1-44.9 114.9 0 208 93.1 208 208 0 48.8-16.8 93.7-44.9 129.1L353.9 320 400 320c8.8 0 16-7.2 16-16l0-64c0-8.8-7.2-16-16-16l-142.1 0zm32 32l94.1 0 0 32-62.1 0-32-32zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM272 96c-8.8 0-16 7.2-16 16 0 26.5 21.5 48 48 48l32 0c8.8 0 16 7.2 16 16s7.2 16 16 16 16-7.2 16-16c0-26.5-21.5-48-48-48l-32 0c-8.8 0-16-7.2-16-16s-7.2-16-16-16zM112 224c-8.8 0-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16l128.8 0-96-96-32.8 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanSmoking = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;