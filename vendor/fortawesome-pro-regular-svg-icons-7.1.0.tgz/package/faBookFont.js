'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-font';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e0bf';
var svgPathData = 'M0 88C0 39.4 39.4 0 88 0L376 0c39.8 0 72 32.2 72 72l0 256c0 25-12.7 47-32 59.9l0 76.1 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L80 512c-44.2 0-80-35.8-80-80L0 88zM48 432c0 17.7 14.3 32 32 32l288 0 0-64-288 0c-17.7 0-32 14.3-32 32zm0-73.3c9.8-4.3 20.6-6.7 32-6.7l296 0c13.3 0 24-10.7 24-24l0-256c0-13.3-10.7-24-24-24L88 48C65.9 48 48 65.9 48 88l0 270.7zM245.5 109.3l63.8 127.6c.2 .3 .3 .6 .4 .9l23.8 47.5c5.9 11.9 1.1 26.3-10.7 32.2s-26.3 1.1-32.2-10.7l-17.4-34.7-98.3 0-17.4 34.7c-5.9 11.9-20.3 16.7-32.2 10.7s-16.7-20.3-10.7-32.2l23.8-47.5c.1-.3 .3-.6 .4-.9l63.8-127.6C206.6 101.1 214.9 96 224 96s17.4 5.1 21.5 13.3zM224 173.7l-25.2 50.3 50.3 0-25.2-50.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookFont = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;