'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bell-school-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f5d6';
var svgPathData = 'M41-24.9c-9.4-9.4-24.6-9.4-33.9 0S-2.3-.3 7 9.1l528 528c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-49.8-49.8C529.9 435.4 536 414.4 536 392l0-8c9.7-7.3 16-18.9 16-32 0-22.1-17.9-40-40-40s-40 17.9-40 40c0 13.1 6.3 24.7 16 32l0 8c0 9-1.6 17.6-4.6 25.5L420 354.2C457.1 316.6 480 265 480 208 480 93.1 386.9 0 272 0 215 0 163.4 22.9 125.8 60L41-24.9zM159.8 93.9c28.9-28.4 68.5-45.9 112.2-45.9 88.4 0 160 71.6 160 160 0 43.7-17.5 83.3-45.9 112.2l-56.6-56.6c13.9-14.4 22.5-34 22.5-55.6 0-44.2-35.8-80-80-80-21.6 0-41.2 8.6-55.6 22.5L159.8 93.9zM295.5 229.7l-45.2-45.2c5.7-5.3 13.3-8.5 21.7-8.5 17.7 0 32 14.3 32 32 0 8.4-3.2 16-8.5 21.7zm144.3 280L394.2 464 192 464c-8.8 0-16-7.2-16-16l0-7.4c-17-6.9-33.1-15.5-48-25.7l0 33.1c0 35.3 28.7 64 64 64l224 0c8.2 0 16.1-.8 23.8-2.4zM296.3 366.2c-7.9 1.2-16.1 1.8-24.3 1.8-88.4 0-160-71.6-160-160 0-8.3 .6-16.4 1.8-24.3L74.1 143.9c-6.5 20.2-10.1 41.7-10.1 64.1 0 114.9 93.1 208 208 208 22.4 0 43.9-3.5 64.1-10.1l-39.8-39.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellSchoolSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;