'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrows-rotate-reverse';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e630';
var svgPathData = 'M403.2 108.9c-81.2-81.2-212.9-81.2-294.2 0l-27.1 27.1 78.2 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L24 184c-13.3 0-24-10.7-24-24L0 24C0 10.7 10.7 0 24 0S48 10.7 48 24L48 102.1 75.1 75c100-100 262.1-100 362 0 43.2 43.2 67.8 98.1 73.6 154.5 1.4 13.2-8.2 25-21.4 26.3s-25-8.2-26.3-21.4c-4.7-45.9-24.7-90.4-59.8-125.5zM1.5 282.5c-1.4-13.2 8.2-25 21.4-26.3s25 8.2 26.3 21.4c4.8 45.8 24.7 90.4 59.8 125.5 81.2 81.2 212.9 81.2 294.2 0l27.1-27.1-78.2 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l136.1 0c13.3 0 24 10.7 24 24l0 136c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-78.1-27.1 27.1c-100 100-262.1 100-362 0-43.2-43.2-67.8-98.1-73.6-154.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRotateReverse = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;