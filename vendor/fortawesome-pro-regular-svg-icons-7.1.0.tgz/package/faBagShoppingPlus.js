'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bag-shopping-plus';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e651';
var svgPathData = 'M160 80l0 48 128 0 0-48c0-35.3-28.7-64-64-64s-64 28.7-64 64zm176 96l-288 0 0 208c0 26.5 21.5 48 48 48l256 0c26.5 0 48-21.5 48-48l0-208-64 0zM112 128l0-48c0-61.9 50.1-112 112-112S336 18.1 336 80l0 48 64 0c26.5 0 48 21.5 48 48l0 208c0 53-43 96-96 96L96 480c-53 0-96-43-96-96L0 176c0-26.5 21.5-48 48-48l64 0zm112 84c11 0 20 9 20 20l0 52 52 0c11 0 20 9 20 20s-9 20-20 20l-52 0 0 52c0 11-9 20-20 20s-20-9-20-20l0-52-52 0c-11 0-20-9-20-20s9-20 20-20l52 0 0-52c0-11 9-20 20-20z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBagShoppingPlus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;