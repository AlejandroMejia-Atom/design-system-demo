'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bacon';
var width = 576;
var height = 512;
var aliases = [129363];
var unicode = 'f7e5';
var svgPathData = 'M308.4 26.1c-45.3 30.9-82 72.8-106.9 121.6l-23.3 45.8c-20.5 40.3-50.5 75.1-87.5 101.2l-59.3 42C4 356.1 .6 395.6 24.4 419.3L131 526c18.4 18.4 47.4 21.2 69 6.4l68.1-46.5c45.3-30.9 82-72.8 106.9-121.6l23.3-45.8c20.5-40.3 50.5-75.1 87.5-101.2l59.3-42c27.5-19.4 30.8-58.9 7-82.7L445.5-14c-18.5-18.4-47.4-21.2-69-6.4L308.4 26.1zM244.3 169.5c21.2-41.7 52.6-77.4 91.2-103.8l68.1-46.5c2.5-1.7 5.8-1.4 7.9 .7l37 37-69.9 44.9c-50.3 32.3-91.3 77.2-119 130.2l-24.1 46.2c-19.9 38.1-47.9 71.5-82 97.7l-59.2 45.5-36.1-36.1c-2.7-2.7-2.4-7.3 .8-9.5l59.3-42C161.8 303.3 197 262.6 221 215.3l23.3-45.8zM128.7 455.8l54.2-41.7c39.6-30.5 72.1-69.2 95.2-113.5l24.1-46.2c23.8-45.6 59.1-84.2 102.4-112.1l78.7-50.6 34.9 34.9c2.7 2.7 2.4 7.3-.8 9.5l-59.3 42c-43.3 30.6-78.5 71.3-102.5 118.6l-23.3 45.8C311 384.2 279.6 419.9 241 446.2l-68.1 46.5c-2.5 1.7-5.8 1.4-7.9-.7l-36.3-36.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBacon = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;