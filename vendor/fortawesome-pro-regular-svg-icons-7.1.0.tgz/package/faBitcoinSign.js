'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bitcoin-sign';
var width = 320;
var height = 512;
var aliases = [];
var unicode = 'e0b4';
var svgPathData = 'M64 24C64 10.7 74.7 0 88 0s24 10.7 24 24l0 40 32 0 0-40c0-13.3 10.7-24 24-24s24 10.7 24 24l0 40.7c54 6 96 51.8 96 107.3 0 27.5-10.3 52.6-27.2 71.6 35.1 17.8 59.2 54.3 59.2 96.4 0 59.6-48.4 108-108 108l-20 0 0 40c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-40-32 0 0 40c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-40-22.3 0C18.7 448 0 429.3 0 406.3L0 101.6C0 80.8 16.8 64 37.6 64L64 64 64 24zM48 232l132 0c33.1 0 60-26.9 60-60s-26.9-60-60-60l-132 0 0 120zm132 48l-132 0 0 120 164 0c33.1 0 60-26.9 60-60s-26.9-60-60-60l-32 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBitcoinSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;