'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'acorn';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f6ae';
var svgPathData = 'M228.8 9.6c8-10.6 23-12.7 33.6-4.8 10.6 8 12.7 23 4.8 33.6l-4.8 6.4c-4.4 5.9-7.8 12.4-10.2 19.2l99.8 0 4.9 .1C407.7 66.7 448 108.6 448 160l0 32-.2 3.3c-1.5 15-13.5 27-28.6 28.6l-3.3 .2-16 0-.4 15.1c-3.8 78.1-38.6 190-165.5 237.3l-5 1.4c-3.4 .6-6.9 .6-10.3 0l-5-1.4C87 429.1 52.2 317.3 48.4 239.1l-.4-15.1-16 0-3.3-.2c-15.1-1.5-27-13.5-28.6-28.6L0 192 0 160c0-51.4 40.3-93.3 91.1-95.9L96 64 202.5 64c3.5-17.3 10.8-33.7 21.5-48l4.8-6.4zM96.3 236.9C99.5 303 127.7 389.5 224 428.8 326.7 386.9 352 291.3 352 224l-256 0 .3 12.9zM96 112c-26.5 0-48 21.5-48 48l0 16 352 0 0-16c0-26.5-21.5-48-48-48L96 112z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAcorn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;