'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-down-up-lock';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e4b0';
var svgPathData = 'M457 95L369 7c-9.4-9.4-24.6-9.4-33.9 0L247 95c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 0 150.1-272 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l80 0 0 150.1-47-47c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l88 88c9.4 9.4 24.6 9.4 33.9 0l88-88c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-47 47 0-150.1 154.2 0c5.1-26.9 18.6-50.9 37.8-69l0-129.1 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9zM184 24c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 160 48 0 0-160zM496 304.1l0 47.9-64 0 0-47.9c0-17.7 14.3-32 32-32s32 14.3 32 32zM352 400l0 96c0 26.5 21.5 48 48 48l128 0c26.5 0 48-21.5 48-48l0-96c0-20.9-13.4-38.7-32-45.3l0-50.6c0-44.2-35.8-80-80-80s-80 35.8-80 80l0 50.6c-18.6 6.6-32 24.4-32 45.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownUpLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;