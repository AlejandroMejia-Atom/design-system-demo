'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'banana';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e2e5';
var svgPathData = 'M352 144c0 46.7-10.5 90.9-29.3 130.4l-25.3-20.2c-4.4-3.5-9.1-6.8-13.9-9.8 13.2-30.8 20.5-64.8 20.5-100.5 0-31.4-5.6-61.3-15.9-89-9.5-25.5 8.6-55 38-55 9.8 0 19.5 3.6 27 10.4 58.2 52.7 94.8 128.9 94.8 213.6 0 10.9-.6 21.6-1.8 32.1-10.9 .4-21.7 2.1-32.3 4.9l-17.6 4.7c2.4-13.5 3.6-27.5 3.6-41.7 0-59.5-21.7-114-57.6-156 6.2 24.3 9.6 49.7 9.6 76zM208.9 304c-15.5 0-30.4 5.5-42.2 15.6l-31.1 26.6c-10.1 8.6-25.2 7.5-33.8-2.6s-7.5-25.2 2.6-33.8l31.1-26.6c20.4-17.5 46.5-27.2 73.4-27.2 21.4 0 42.2 6.1 60.1 17.4l.1-.2c2.9 1.9 5.6 3.9 8.3 6l1.7 1.3 .2 .2 46.2 37 96.7-25.8c6.1-1.6 12.3-2.7 18.5-3.4l0 0c3.7-.4 7.5-.6 11.3-.6 40.7 0 78.4 21.3 99.3 56.2l21.3 35.4c6.8 11.4 3.1 26.1-8.2 32.9s-26.1 3.1-32.9-8.2l-21.3-35.4c-12.3-20.4-34.3-32.9-58.1-32.9-5.9 0-11.8 .8-17.5 2.3l-11.5 3.1C378.2 441.9 277.3 512 160 512L48 512c-26.5 0-48-21.5-48-48l0-16c0-26.5 21.5-48 48-48 76.9 0 145.9-33.9 192.8-87.6-9.7-5.5-20.7-8.4-31.9-8.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanana = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;