'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'backward-fast';
var width = 512;
var height = 512;
var aliases = [9198,"fast-backward"];
var unicode = 'f049';
var svgPathData = 'M240 102.6L240 409.4 86.6 256 240 102.6zm-6.6 368c9.2 9.2 22.9 11.9 34.9 6.9S288 460.9 288 448l0-146.7 169.4 169.4c9.2 9.2 22.9 11.9 34.9 6.9S512 460.9 512 448l0-384c0-12.9-7.8-24.6-19.8-29.6s-25.7-2.2-34.9 6.9L288 210.7 288 64c0-12.9-7.8-24.6-19.8-29.6s-25.7-2.2-34.9 6.9L48 226.7 48 56c0-13.3-10.7-24-24-24S0 42.7 0 56L0 456c0 13.3 10.7 24 24 24s24-10.7 24-24l0-170.7 185.4 185.4zM310.6 256L464 102.6 464 409.4 310.6 256z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBackwardFast = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;