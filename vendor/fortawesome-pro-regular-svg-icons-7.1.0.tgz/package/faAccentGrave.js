'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'accent-grave';
var width = 192;
var height = 512;
var aliases = [];
var unicode = '60';
var svgPathData = 'M80.2 65.3c0-9.6 7.8-17.3 17.3-17.3 8.4 0 15.6 6 17 14.3l18.2 102.1-49.7-84.4c-1.9-3.3-2.9-7-2.9-10.7l0-3.9zm-48 0l0 3.9c0 12.3 3.3 24.4 9.5 35.1l57.3 97.4c8.1 13.8 23 22.3 39 22.3 28.2 0 49.5-25.5 44.6-53.3L161.8 53.8C156.3 22.7 129.2 0 97.5 0 61.4 0 32.2 29.2 32.2 65.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAccentGrave = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;