'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'album-circle-plus';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e48c';
var svgPathData = 'M416 80L96 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l146.7 0c2.8 16.8 7.8 32.9 14.8 48L96 480c-35.3 0-64-28.7-64-64L32 96c0-35.3 28.7-64 64-64l320 0c35.3 0 64 28.7 64 64l0 118c-15.3-3.9-31.4-6-48-6l0-112c0-8.8-7.2-16-16-16zM256 112c64.2 0 118.5 42 137.1 99.9-16 3.3-31.2 8.5-45.4 15.5-12.2-39.1-48.6-67.5-91.7-67.5-53 0-96 43-96 96 0 49.7 37.8 90.6 86.2 95.5-4 15.2-6.1 31.2-6.2 47.6-72-8-128-69-128-143.1 0-79.5 64.5-144 144-144zM224 256a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm208 0a144 144 0 1 1 0 288 144 144 0 1 1 0-288zm16 80c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 48-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l48 0 0 48c0 8.8 7.2 16 16 16s16-7.2 16-16l0-48 48 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-48 0 0-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlbumCirclePlus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;