'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrows-retweet';
var width = 576;
var height = 512;
var aliases = ["retweet-alt"];
var unicode = 'f361';
var svgPathData = 'M463 473c9.4 9.4 24.6 9.4 33.9 0l72-72c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-31 31 0-270.1c0-53-43-96-96-96L280 32c-13.3 0-24 10.7-24 24s10.7 24 24 24l128 0c26.5 0 48 21.5 48 48l0 270.1-31-31c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l72 72zM113 39c-9.4-9.4-24.6-9.4-33.9 0L7 111c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l31-31 0 270.1c0 53 43 96 96 96l128 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-128 0c-26.5 0-48-21.5-48-48l0-270.1 31 31c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L113 39z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRetweet = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;