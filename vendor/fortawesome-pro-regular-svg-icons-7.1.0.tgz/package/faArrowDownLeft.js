'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-down-left';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e091';
var svgPathData = 'M24 448c-13.3 0-24-10.7-24-24L0 184c0-13.3 10.7-24 24-24s24 10.7 24 24L48 366.1 343 71c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9L81.9 400 264 400c13.3 0 24 10.7 24 24s-10.7 24-24 24L24 448z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;