'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-up-from-square';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e09c';
var svgPathData = 'M248 296l0-246.1 31 31c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L241-25c-9.4-9.4-24.6-9.4-33.9 0L135 47c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l31-31 0 246.1c0 13.3 10.7 24 24 24s24-10.7 24-24zM48 192c0-8.8 7.2-16 16-16l40 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-40 0c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64l-40 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l40 0c8.8 0 16 7.2 16 16l0 256c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16l0-256z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpFromSquare = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;