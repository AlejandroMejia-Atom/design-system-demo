'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-up-a-z';
var width = 512;
var height = 512;
var aliases = ["sort-alpha-up"];
var unicode = 'f15e';
var svgPathData = 'M406 45.3C401.9 37.1 393.6 32 384.5 32S367.1 37.1 363 45.3l-80 160c-5.9 11.9-1.1 26.3 10.7 32.2s26.3 1.1 32.2-10.7l13.4-26.7 85.2 0c1.7 0 3.3-.2 4.9-.5L443 226.7c5.9 11.9 20.3 16.7 32.2 10.7s16.7-20.3 10.7-32.2l-80-160zm-21.5 64.4l21.2 42.3-42.3 0 21.2-42.3zM288.5 312c0 13.3 10.7 24 24 24l86.1 0-103 103c-6.9 6.9-8.9 17.2-5.2 26.2S302.8 480 312.5 480l144 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-86.1 0 103-103c6.9-6.9 8.9-17.2 5.2-26.2S466.2 288 456.5 288l-144 0c-13.3 0-24 10.7-24 24zM145.5 39c-9.4-9.4-24.6-9.4-33.9 0l-88 88c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 0 342.1c0 13.3 10.7 24 24 24s24-10.7 24-24l0-342.1 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-88-88z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpAZ = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;