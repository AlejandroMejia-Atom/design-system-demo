'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bahai';
var width = 512;
var height = 512;
var aliases = ["haykal"];
var unicode = 'f666';
var svgPathData = 'M256.4 0c9.9 0 18.8 6.1 22.4 15.3l35.2 90.5 85.1-46.7c8.7-4.8 19.4-3.7 27 2.7s10.5 16.7 7.3 26.1l-31.2 92 95.2 19c9.7 1.9 17.2 9.6 18.9 19.4s-2.7 19.5-11.2 24.7l-83 50.4 60.7 75.7c6.2 7.7 7 18.4 2.1 27s-14.6 13.2-24.4 11.7l-96-14.7-2.2 97.1c-.2 9.9-6.5 18.6-15.8 22s-19.7 .7-26.2-6.7l-64-73-64 73c-6.5 7.4-16.9 10.1-26.2 6.7s-15.6-12.1-15.8-22l-2.2-97.1-96 14.7c-9.8 1.5-19.5-3.2-24.4-11.7s-4.1-19.3 2.1-27l60.7-75.7-83-50.4c-8.5-5.1-12.9-14.9-11.2-24.7s9.2-17.4 18.9-19.4l95.2-19-31.2-92c-3.2-9.4-.3-19.7 7.3-26.1s18.3-7.4 27-2.7l85.1 46.7 35.2-90.5C237.6 6.1 246.5 0 256.4 0zm0 90.2l-22.8 58.5c-2.5 6.4-7.7 11.5-14.2 13.8s-13.7 1.8-19.7-1.5l-55.1-30.2 20.2 59.5c2.2 6.5 1.5 13.7-1.9 19.7s-9.3 10.2-16.1 11.5l-61.6 12.3 53.7 32.6c5.9 3.6 10 9.5 11.2 16.3s-.6 13.8-4.9 19.2l-39.3 49 62.1-9.5c6.8-1 13.8 .9 19.1 5.3s8.4 10.9 8.6 17.9l1.4 62.8 41.4-47.2c4.6-5.2 11.1-8.2 18-8.2s13.5 3 18 8.2l41.4 47.2 1.4-62.8c.2-6.9 3.3-13.4 8.6-17.9s12.2-6.4 19.1-5.3l62.1 9.5-39.3-49c-4.3-5.4-6.1-12.4-4.9-19.2s5.3-12.8 11.2-16.3l53.7-32.6-61.6-12.3c-6.8-1.4-12.6-5.6-16.1-11.5s-4.2-13.2-1.9-19.7L368.1 130.8 313 161c-6.1 3.3-13.3 3.9-19.7 1.5s-11.6-7.4-14.2-13.8L256.4 90.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBahai = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;