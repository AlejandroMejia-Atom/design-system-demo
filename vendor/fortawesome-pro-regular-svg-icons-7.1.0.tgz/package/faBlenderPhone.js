'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'blender-phone';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f6b6';
var svgPathData = 'M151.4 13.2c10.2 5.8 14.5 18.4 10 29.3L138.2 98.8c-3.9 9.6-13.7 15.4-24 14.4l-20.2-2C78.7 152.9 78 198.9 91.9 241.1l22.4-2.2c10.3-1 20 4.8 24 14.4l23.2 56.3c4.5 10.9 .2 23.4-10 29.3l-2.9 1.6c-33.6 19.2-81.7 16.2-106.2-21.6-56.3-86.6-56.3-199.1 0-285.7 24.6-37.7 72.7-40.7 106.2-21.6l2.9 1.6zM534.6 0c21 0 36.3 19.8 31 40.1L490.5 327.9c13 8.6 21.5 23.3 21.5 40.1l0 96c0 26.5-21.5 48-48 48l-224 0c-26.5 0-48-21.5-48-48l0-96c0-19.4 11.6-36.2 28.2-43.7L195 34.8C193.4 16.1 208.1 0 226.9 0L534.6 0zM268 320l174.9 0 16.7-64-51.6 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l64.1 0 16.7-64-80.8 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l93.4 0 12.5-48-269.5 0 23.7 272zm-28 48l0 96 224 0 0-96-224 0zm88 48a24 24 0 1 1 48 0 24 24 0 1 1 -48 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlenderPhone = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;