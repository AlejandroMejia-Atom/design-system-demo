'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'alien';
var width = 448;
var height = 512;
var aliases = [128125];
var unicode = 'f8f5';
var svgPathData = 'M224 512C213.5 512 203.3 509.1 194.7 503.2 148.8 471.7 0 359.3 0 224 0 100.3 100.3 0 224 0S448 100.3 448 224c0 135.3-148.8 247.7-194.7 279.2-8.6 5.9-18.9 8.8-29.3 8.8zM48 224c0 50.4 28.2 101.3 68.2 146.9 39.2 44.7 84.2 78.1 105.6 92.7 1.3 .7 3.1 .7 4.4 0 21.4-14.6 66.4-48 105.6-92.7 40-45.6 68.2-96.5 68.2-146.9 0-97.2-78.8-176-176-176S48 126.8 48 224zm160 82.3c0 7.6-6.1 13.7-13.7 13.7l-32 0c-45.4 0-82.3-36.8-82.3-82.3 0-7.6 6.1-13.7 13.7-13.7l32 0c45.4 0 82.3 36.8 82.3 82.3zm32 0c0-45.4 36.8-82.3 82.3-82.3l32 0c7.6 0 13.7 6.1 13.7 13.7 0 45.4-36.8 82.3-82.3 82.3l-32 0c-7.6 0-13.7-6.1-13.7-13.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlien = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;