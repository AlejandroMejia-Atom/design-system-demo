'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-tanakh';
var width = 448;
var height = 512;
var aliases = ["tanakh"];
var unicode = 'f827';
var svgPathData = 'M448 88c0-48.6-39.4-88-88-88L72 0C32.2 0 0 32.2 0 72L0 328c0 25 12.7 47 32 59.9l0 76.1-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l344 0c44.2 0 80-35.8 80-80l0-344zM400 432c0 17.7-14.3 32-32 32l-288 0 0-64 288 0c17.7 0 32 14.3 32 32zm0-73.3c-9.8-4.3-20.6-6.7-32-6.7L72 352c-13.3 0-24-10.7-24-24L48 72c0-13.3 10.7-24 24-24l288 0c22.1 0 40 17.9 40 40l0 270.7zM113.9 245c-1.2 2-1.9 4.2-1.9 6.6 0 6.9 5.6 12.5 12.5 12.5l56.9 0 30.5 49.2c2.6 4.2 7.2 6.8 12.2 6.8s9.6-2.6 12.2-6.8l30.5-49.2 56.9 0c6.9 0 12.5-5.6 12.5-12.5 0-2.3-.6-4.6-1.9-6.6l-27.8-45 27.8-45c1.2-2 1.9-4.2 1.9-6.6 0-6.9-5.6-12.5-12.5-12.5l-56.9 0-30.5-49.2C233.6 82.6 229 80 224 80s-9.6 2.6-12.2 6.8l-30.5 49.2-56.9 0c-6.9 0-12.5 5.6-12.5 12.5 0 2.3 .6 4.6 1.9 6.6l27.8 45-27.8 45z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookTanakh = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;