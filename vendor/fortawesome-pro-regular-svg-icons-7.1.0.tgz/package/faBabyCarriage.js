'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'baby-carriage';
var width = 512;
var height = 512;
var aliases = ["carriage-baby"];
var unicode = 'f77d';
var svgPathData = 'M320 192l-32 0 0-160c0-17.7-14.3-32-32-32L232 0C139.2 0 64 75.2 64 168l0 120c0 53 43 96 96 96l192 0c53 0 96-43 96-96l0-112 40 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-64 0c-13.3 0-24 10.7-24 24l0 40-80 0zm80 48l0 48c0 26.5-21.5 48-48 48l-192 0c-26.5 0-48-21.5-48-48l0-48 288 0zM240 48l0 144-128 0 0-24c0-66.3 53.7-120 120-120l8 0zM112 512a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm288 0a48 48 0 1 0 0-96 48 48 0 1 0 0 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBabyCarriage = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;