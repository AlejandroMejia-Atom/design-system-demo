'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bomb';
var width = 576;
var height = 512;
var aliases = [128163];
var unicode = 'f1e2';
var svgPathData = 'M495.2-5.1l13.5 40.4 40.4 13.5C555.6 51 560 57.1 560 64s-4.4 13-10.9 15.2l-40.4 13.5-13.5 40.4C493 139.6 486.9 144 480 144s-13-4.4-15.2-10.9l-13.5-40.4-40.4-13.5C404.4 77 400 70.9 400 64s4.4-13 10.9-15.2l40.4-13.5 13.5-40.4C467-11.6 473.1-16 480-16s13 4.4 15.2 10.9zM308.8 88.1c15.8-14.1 39.9-13.4 54.9 1.6l90 90c15.6 15.6 15.6 40.9 0 56.6l-13 12.9c4.8 17.5 7.3 35.8 7.3 54.8 0 114.9-93.1 208-208 208S32 418.9 32 304 125.1 96 240 96c18.1 0 35.6 2.3 52.4 6.7l16.4-14.6zM335 129l-20.7 18.4c-6.4 5.7-15.4 7.5-23.6 4.8-15.9-5.3-33-8.2-50.8-8.2-88.4 0-160 71.6-160 160s71.6 160 160 160 160-71.6 160-160c0-18.8-3.2-36.8-9.1-53.5-3.1-8.7-.9-18.4 5.7-25l17.5-17.6-79-79zM176 304c0 13.3-10.7 24-24 24s-24-10.7-24-24c0-61.9 50.1-112 112-112 13.3 0 24 10.7 24 24s-10.7 24-24 24c-35.3 0-64 28.7-64 64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBomb = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;