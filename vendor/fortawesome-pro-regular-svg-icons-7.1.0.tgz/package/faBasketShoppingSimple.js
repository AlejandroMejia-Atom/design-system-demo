'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'basket-shopping-simple';
var width = 576;
var height = 512;
var aliases = ["shopping-basket-alt"];
var unicode = 'e0af';
var svgPathData = 'M162.7 192l-78.3 0 47.9 227.3c1.6 7.4 8.1 12.7 15.7 12.7l280.1 0c7.6 0 14.1-5.3 15.7-12.7l47.9-227.3-328.9 0zM322.8 96l-1.9-2-33-35-33 35-1.9 2-45.2 48 160.1 0-45.2-48zM434 144l102 0c13.3 0 24 10.7 24 24 0 11.6-8.3 21.3-19.3 23.5l-50 237.6c-6.2 29.6-32.4 50.8-62.6 50.8l-280.1 0c-30.3 0-56.4-21.2-62.6-50.8l-50-237.6c-11-2.2-19.3-11.9-19.3-23.5 0-13.3 10.7-24 24-24l102 0c12.5-13.3 49.5-52.6 111.1-117.9L270.5 7.5C275.1 2.7 281.4 0 288 0s12.9 2.7 17.5 7.5c1.2 1.3 33.7 35.8 97.5 103.5L434 144zM144 264a24 24 0 1 1 48 0 24 24 0 1 1 -48 0zm264-24a24 24 0 1 1 0 48 24 24 0 1 1 0-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBasketShoppingSimple = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;