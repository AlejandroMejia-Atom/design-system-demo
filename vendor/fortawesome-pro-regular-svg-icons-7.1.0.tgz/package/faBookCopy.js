'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-copy';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0be';
var svgPathData = 'M224 88c0-48.6 39.4-88 88-88L504 0c39.8 0 72 32.2 72 72l0 128c0 25-12.7 47-32 59.9l0 76.1 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-248 0c-44.2 0-80-35.8-80-80l0-216zm80 184c-17.7 0-32 14.3-32 32s14.3 32 32 32l192 0 0-64-192 0zm-32-41.3c9.8-4.3 20.6-6.7 32-6.7l200 0c13.3 0 24-10.7 24-24l0-128c0-13.3-10.7-24-24-24L312 48c-22.1 0-40 17.9-40 40l0 142.7zM88 128l88 0 0 48-88 0c-22.1 0-40 17.9-40 40l0 142.7c9.8-4.3 20.6-6.7 32-6.7l105.3 0c7.5 18.6 19.3 35 34 48L80 400c-17.7 0-32 14.3-32 32s14.3 32 32 32l192 0 0-36c10.2 2.6 21 4 32 4l16 0 0 32 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L80 512c-44.2 0-80-35.8-80-80L0 216c0-48.6 39.4-88 88-88z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookCopy = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;