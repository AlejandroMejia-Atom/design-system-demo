'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-u-turn-up-right';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e7ee';
var svgPathData = 'M505 145c9.4-9.4 9.4-24.6 0-33.9L385-9c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l79 79-242.1 0C84.2 104 0 188.2 0 292S84.2 480 188 480l236 0 2.5-.1c12.1-1.2 21.5-11.5 21.5-23.9s-9.4-22.6-21.5-23.9l-2.5-.1-236 0c-77.3 0-140-62.7-140-140s62.7-140 140-140l242.1 0-79 79-1.7 1.8c-7.7 9.4-7.1 23.3 1.7 32.1s22.7 9.3 32.1 1.7L385 265 505 145z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnUpRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;