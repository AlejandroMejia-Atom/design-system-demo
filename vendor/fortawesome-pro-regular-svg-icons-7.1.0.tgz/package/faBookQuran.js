'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-quran';
var width = 448;
var height = 512;
var aliases = ["quran"];
var unicode = 'f687';
var svgPathData = 'M360 0c48.6 0 88 39.4 88 88l0 344c0 44.2-35.8 80-80 80L24 512c-13.3 0-24-10.7-24-24s10.7-24 24-24l8 0 0-76.1C12.7 375 0 353 0 328L0 72C0 32.2 32.2 0 72 0L360 0zM80 400l0 64 288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L80 400zm288-48c11.4 0 22.2 2.4 32 6.7L400 88c0-22.1-17.9-40-40-40L72 48C58.7 48 48 58.7 48 72l0 256c0 13.3 10.7 24 24 24l296 0zM266.4 150.5c2.2-5.3 9.7-5.3 11.9 0l9 21.6 23.3 1.9c5.7 .5 8.1 7.6 3.7 11.3l-17.8 15.2 5.4 22.8c1.3 5.6-4.7 10-9.7 7l-20-12.2-20 12.2c-4.9 3-11-1.4-9.7-7l5.4-22.8-17.8-15.2c-4.4-3.7-2-10.9 3.7-11.3l23.3-1.9 9-21.6zM115.6 192c0-59.6 48.4-108 108-108 20.7 0 40.1 5.9 56.6 16 4.2 2.6 6 7.7 4.4 12.3s-6.2 7.5-11 7c-2.7-.3-5.4-.4-8.2-.4-40.4 0-73.2 32.8-73.2 73.2s32.8 73.2 73.2 73.2c2.8 0 5.5-.2 8.2-.4 4.9-.5 9.4 2.4 11 7s-.2 9.7-4.4 12.3c-16.5 10.2-35.9 16-56.6 16-59.6 0-108-48.4-108-108z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookQuran = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;