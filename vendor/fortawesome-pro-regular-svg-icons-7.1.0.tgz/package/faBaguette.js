'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'baguette';
var width = 640;
var height = 512;
var aliases = [129366];
var unicode = 'e3d8';
var svgPathData = 'M578.6 83.6c-24.5-36.8-74.2-46.7-110.9-22.2L397.9 107.9 433 143c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-41.9-41.9-74.5 49.6 38.3 38.3c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-45.1-45.1-74.5 49.6 41.5 41.5c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-48.3-48.3-43.1 28.7c-36.8 24.5-46.7 74.2-22.2 110.9s74.2 46.7 110.9 22.2l384-256c36.8-24.5 46.7-74.2 22.2-110.9zM618.5 57c39.2 58.8 23.3 138.3-35.5 177.5l-384 256C140.2 529.7 60.7 513.8 21.5 455S-1.8 316.7 57 277.5l384-256C499.8-17.7 579.3-1.8 618.5 57z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBaguette = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;