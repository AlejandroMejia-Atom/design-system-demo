'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-left-to-bracket';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e669';
var svgPathData = 'M303 409L167 273c-9.4-9.4-9.4-24.6 0-33.9L303 103c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9l-95 95 246.1 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-246.1 0 95 95c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0zM168 80L96 80c-26.5 0-48 21.5-48 48l0 256c0 26.5 21.5 48 48 48l72 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-72 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l72 0c13.3 0 24 10.7 24 24s-10.7 24-24 24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowLeftToBracket = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;