'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bar-progress-three-quarters';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6a9';
var svgPathData = 'M448 144c8.8 0 16 7.2 16 16l0 192c0 8.8-7.2 16-16 16l-48 0 0-224 48 0zm-190.1 0l94.1 0 0 14.1-209.9 209.9-78.1 0c-8.2 0-15-6.2-15.9-14.2L257.9 144zm-67.9 0L48 286.1 48 160c0-8.8 7.2-16 16-16l126.1 0zm19.9 224L352 225.9 352 368 209.9 368zM64 96C28.7 96 0 124.7 0 160L0 352c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-192c0-35.3-28.7-64-64-64L64 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarProgressThreeQuarters = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;