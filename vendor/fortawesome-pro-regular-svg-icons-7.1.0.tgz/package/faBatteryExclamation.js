'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'battery-exclamation';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e0b0';
var svgPathData = 'M247 64c-4.6 10.6-7.1 22.2-6.6 34.5l0 0 .5 13.4-128.8 0c-17.7 0-32 14.3-32 32l0 224c0 17.7 14.3 32 32 32l129.7 0c-.5 2.6-1 5.2-1.2 7.8L240 416c0 11.4 2.4 22.2 6.7 32L112 448c-44.2 0-80-35.8-80-80l0-224c0-44.2 35.8-80 80-80l135 0zm73 384a32 32 0 1 1 0-64 32 32 0 1 1 0 64zM528 64c44.2 0 80 35.8 80 80l0 48c17.7 0 32 14.3 32 32l0 64c0 17.7-14.3 32-32 32l0 48c0 44.2-35.8 80-80 80l-134.7 0c4.3-9.8 6.7-20.6 6.7-32 0-5.5-.6-10.8-1.6-16L528 400c17.7 0 32-14.3 32-32l0-224c0-17.7-14.3-32-32-32l-128.8 0 .5-13.4 0 0c.4-12.3-2-24-6.6-34.5L528 64zM320 64c18 0 32.3 14.9 31.7 32.8l-7.7 216c-.5 12.9-11.1 23.1-24 23.2-12.9 0-23.5-10.2-24-23.2l-7.7-216C287.7 78.9 302 64 320 64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBatteryExclamation = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;