'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bolt-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0b8';
var svgPathData = 'M41-25C31.6-34.3 16.4-34.3 7-25S-2.3-.4 7 9L535 537c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-164.3-164.3 95.7-85.6c7.4-6.7 11.7-16.2 11.7-26.1 0-19.4-15.7-35.1-35.1-35.1l-121 0 58.8-176.4c3.4-10.3-.5-21.7-9.6-27.6S384.1-17.2 376-10L207.1 141.1 41-25zM241.1 175.1l99.6-89.1-40.8 122.3c-2.4 7.3-1.2 15.4 3.3 21.6s11.8 10 19.5 10l120.4 0-72.4 64.8-129.6-129.6zm-5.7 250.6l30.2-90.5-63.3-63.3-69.2 0 36.5-32.7-34-34-59.8 53.5c-7.4 6.7-11.7 16.2-11.7 26.1 0 19.4 15.7 35.1 35.1 35.1l121 0-58.8 176.4c-3.4 10.3 .5 21.7 9.6 27.6s21.1 5.1 29.2-2.2l133-119-34-34-63.7 57z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;