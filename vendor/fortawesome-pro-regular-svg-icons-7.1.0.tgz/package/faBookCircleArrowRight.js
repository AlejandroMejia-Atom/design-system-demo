'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-circle-arrow-right';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0bc';
var svgPathData = 'M120 0C71.4 0 32 39.4 32 88l0 344c0 44.2 35.8 80 80 80l164 0c-10.5-14.6-19-30.7-25.1-48L112 464c-17.7 0-32-14.3-32-32s14.3-32 32-32l128 0c0-16.6 2.1-32.7 6-48l-134 0c-11.4 0-22.2 2.4-32 6.7L80 88c0-22.1 17.9-40 40-40l288 0c13.3 0 24 10.7 24 24l0 136c16.6 0 32.7 2.1 48 6l0-142c0-39.8-32.2-72-72-72L120 0zM576 400a144 144 0 1 0 -288 0 144 144 0 1 0 288 0zM428.7 332.7c6.2-6.2 16.4-6.2 22.6 0l56 56c6.2 6.2 6.2 16.4 0 22.6l-56 56c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l28.7-28.7-89.4 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l89.4 0-28.7-28.7c-6.2-6.2-6.2-16.4 0-22.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookCircleArrowRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;