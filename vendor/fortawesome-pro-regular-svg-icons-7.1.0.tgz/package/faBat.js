'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bat';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f6b5';
var svgPathData = 'M213 50.7c6.8-3.5 14.9-3.6 21.8-.2l53.3 26.6 53.3-26.6 2.6-1.1c6.2-2.2 13.2-1.8 19.1 1.3 6.8 3.5 11.5 10.1 12.7 17.7l10.2 66.8 35-23.3 5.2-3.1c26.5-14.2 59.8-7.6 78.7 16.5l8.4 11.2C554 192.9 576 260.9 576 330.8l0 25c0 25.7-25.9 42.5-48.8 33.5l-4.5-2.1-36-20-24.3 32.5c-14.6 19.5-43.1 21.5-60.3 4.3l-30.9-30.9-50.5 70.7c-15 20.9-45.1 22.3-61.9 3.9l-3.2-3.9-50.5-70.7-30.9 30.9c-17.2 17.2-45.7 15.2-60.3-4.3l-24.4-32.5-36 20C29.4 400.4 0 383.1 0 355.8l0-25c0-74.5 25-146.9 71.1-205.5l4-4.6c20.7-21.7 54.5-25.8 79.9-8.8l35 23.3 10.3-66.8 .6-2.8c1.8-6.4 6.1-11.8 12.1-14.9zm85.8 74.8c-6.8 3.4-14.7 3.4-21.4 0l-34.6-17.3-11 71.5c-1.2 8.1-6.5 15-14 18.3s-16.2 2.5-23-2l-66.3-44.2c-5.5-3.7-12.8-3.1-17.6 1.1l-1.9 2C69.4 205 48 267 48 330.8l0 4.4 24.2-13.4 3.3-1.6c15.7-6.9 34.2-3 45.8 9.8l2.3 2.8 23 30.7 31.1-31.1 3.4-3c16.5-13.1 40.5-11.2 54.6 4.5l2.8 3.6 49.5 69.3 49.5-69.3 2.8-3.6c14.1-15.7 38.1-17.6 54.6-4.5l3.4 3 31.1 31.1 23.1-30.7 2.3-2.8c11.5-12.8 30-16.7 45.8-9.8l3.3 1.6 24.2 13.4 0-4.4c0-59.8-18.8-118-53.7-166.3l-7.2-9.6c-4.7-6-13.2-7.3-19.6-3.1L381.3 196c-6.8 4.5-15.5 5.3-23 2s-12.8-10.2-14-18.3l-11-71.5-34.6 17.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBat = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;