'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'apple-whole';
var width = 448;
var height = 512;
var aliases = [127822,127823,"apple-alt"];
var unicode = 'f5d1';
var svgPathData = 'M224 112l16 0c44.2 0 80-35.8 80-80l0-16c0-8.8-7.2-16-16-16L288 0c-44.2 0-80 35.8-80 80l0 16c0 8.8 7.2 16 16 16zM48 288c0-31.7 7.6-62.5 20.4-83.7 12.1-19.9 26.2-28.3 43.6-28.3 17.8 0 43.2 7.4 65.3 16 30 11.7 63.5 11.7 93.5 0 22.1-8.6 47.5-16 65.3-16 17.3 0 31.5 8.3 43.6 28.3 12.9 21.2 20.4 52.1 20.4 83.7 0 54.2-17 100-40.4 131.2-24 32-51.2 44.8-71.6 44.8-4.6 0-13.6-1.7-24.9-5.1-25.4-7.6-52.7-7.6-78.1 0-11.3 3.4-20.3 5.1-24.9 5.1-20.4 0-47.6-12.8-71.6-44.8-23.4-31.2-40.4-77-40.4-131.2zm64-160c-76.3 0-112 83.7-112 160 0 128 80 224 160 224 11.9 0 26.5-3.4 38.8-7.1 16.4-4.9 34.1-4.9 50.5 0 12.2 3.7 26.8 7.1 38.8 7.1 80 0 160-96 160-224 0-76.3-35.7-160-112-160-27.3 0-59.7 10.3-82.7 19.3-18.8 7.3-39.9 7.3-58.7 0-22.9-8.9-55.4-19.3-82.7-19.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAppleWhole = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;