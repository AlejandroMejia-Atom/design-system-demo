'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bed-front';
var width = 512;
var height = 512;
var aliases = ["bed-alt"];
var unicode = 'f8f7';
var svgPathData = 'M96 32C60.7 32 32 60.7 32 96l0 148.1C12.5 260.3 0 284.7 0 312L0 456c0 13.3 10.7 24 24 24s24-10.7 24-24l0-40 416 0 0 40c0 13.3 10.7 24 24 24s24-10.7 24-24l0-144c0-27.3-12.5-51.7-32-67.9L480 96c0-35.3-28.7-64-64-64L96 32zM400 224l-96 0c-17.7 0-32-14.3-32-32l0-16c0-17.7 14.3-32 32-32l96 0c17.7 0 32 14.3 32 32l0 16c0 17.7-14.3 32-32 32zm-192 0l-96 0c-17.7 0-32-14.3-32-32l0-16c0-17.7 14.3-32 32-32l96 0c17.7 0 32 14.3 32 32l0 16c0 17.7-14.3 32-32 32zm256 88l0 56-416 0 0-56c0-22.1 17.9-40 40-40l336 0c22.1 0 40 17.9 40 40z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBedFront = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;