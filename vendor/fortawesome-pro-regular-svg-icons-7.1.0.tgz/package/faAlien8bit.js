'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'alien-8bit';
var width = 576;
var height = 512;
var aliases = [128126,"alien-monster"];
var unicode = 'f8f6';
var svgPathData = 'M96 56c0-13.3 10.7-24 24-24s24 10.7 24 24l24 0 2.5 .1C182.6 57.4 192 67.6 192 80l0 48 192 0 0-48 .1-2.5C385.4 65.4 395.6 56 408 56l24 0c0-13.3 10.7-24 24-24s24 10.7 24 24l0 24-.1 2.5C478.6 94.6 468.4 104 456 104l-24 0 0 56 24 0c13.3 0 24 10.7 24 24l0 56 48 0 0-88c0-13.3 10.7-24 24-24s24 10.7 24 24l0 112c0 13.3-10.7 24-24 24l-40 0 0 72c0 13.3-10.7 24-24 24l-40 0 0 72c0 13.3-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l56 0 0-48-224 0 0 48 56 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24l0-72-40 0c-13.3 0-24-10.7-24-24l0-72-40 0c-13.3 0-24-10.7-24-24L0 152c0-13.3 10.7-24 24-24s24 10.7 24 24l0 88 48 0 0-56c0-13.3 10.7-24 24-24l24 0 0-56-24 0c-13.3 0-24-10.7-24-24l0-24zm96 128c0 13.3-10.7 24-24 24l-24 0 0 56c0 13.3-10.7 24-24 24l-8 0 0 48 352 0 0-48-8 0c-13.3 0-24-10.7-24-24l0-56-24 0c-13.3 0-24-10.7-24-24l0-8-192 0 0 8zm0 56c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 48c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-48zm144-16l32 0c8.8 0 16 7.2 16 16l0 48c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-48c0-8.8 7.2-16 16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlien8bit = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;