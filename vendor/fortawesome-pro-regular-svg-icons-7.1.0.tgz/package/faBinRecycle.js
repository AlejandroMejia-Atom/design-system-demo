'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bin-recycle';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e5f7';
var svgPathData = 'M0 88C0 74.7 10.7 64 24 64l528 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-9.5 0-25.3 277.8c-3 33-30.6 58.2-63.7 58.2l-331.1 0c-33.1 0-60.7-25.2-63.7-58.2L33.5 112 24 112C10.7 112 0 101.3 0 88zm81.7 24l24.9 273.4c.7 8.2 7.7 14.6 15.9 14.6l331.1 0c8.3 0 15.2-6.3 15.9-14.6L494.3 112 81.7 112zM288 192c-2.4 0-4.7 1.1-6.1 3.1l-15.7 21.5c-7.4 10.1-21.4 12.8-32.1 6.2-11.8-7.4-14.9-23.3-6.6-34.5l15.7-21.5C253.7 152.4 270.3 144 288 144s34.3 8.4 44.8 22.7l15.7 21.5c8.3 11.3 5.2 27.1-6.6 34.5-10.7 6.7-24.6 4-32.1-6.2l-15.7-21.5c-1.4-1.9-3.7-3.1-6.1-3.1zm-80.7 61.2c11.8 7.4 14.9 23.3 6.6 34.5l-4.8 6.5c-.8 1.1-1.2 2.3-1.2 3.6 0 3.4 2.7 6.1 6.1 6.1l29.9 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-29.9 0c-29.9 0-54.1-24.2-54.1-54.1 0-11.5 3.7-22.7 10.5-32l4.8-6.5c7.4-10.1 21.4-12.8 32.1-6.2zM308 328c0-13.3 10.7-24 24-24l29.9 0c3.4 0 6.1-2.7 6.1-6.1 0-1.3-.4-2.6-1.2-3.6l-4.8-6.5c-8.3-11.3-5.2-27.1 6.6-34.5 10.7-6.7 24.6-4 32.1 6.2l4.8 6.5c6.8 9.3 10.5 20.5 10.5 32 0 29.9-24.2 54.1-54.1 54.1L332 352c-13.3 0-24-10.7-24-24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinRecycle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;