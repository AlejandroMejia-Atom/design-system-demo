'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-open-cover';
var width = 576;
var height = 512;
var aliases = ["book-open-alt"];
var unicode = 'e0c0';
var svgPathData = 'M312 114.4l41.5-14.8C389.8 86.6 428 80 466.5 80l61.5 0 0 288-61.5 0c-49.5 0-98.7 8.5-145.3 25.2l-9.2 3.3 0-282.1zM264 396.5l-9.2-3.3C208.2 376.5 159 368 109.5 368l-61.5 0 0-288 61.5 0c38.5 0 76.7 6.6 113 19.6l41.5 14.8 0 282.1zM288 72L238.6 54.4C197.2 39.6 153.5 32 109.5 32L48 32C21.5 32 0 53.5 0 80L0 368c0 26.5 21.5 48 48 48l61.5 0c44 0 87.7 7.6 129.2 22.4l38.6 13.8c7 2.5 14.6 2.5 21.5 0l38.6-13.8c41.5-14.8 85.1-22.4 129.2-22.4l61.5 0c26.5 0 48-21.5 48-48l0-288c0-26.5-21.5-48-48-48l-61.5 0c-44 0-87.7 7.6-129.2 22.4L288 72zM0 488c0 13.3 10.7 24 24 24l67.7 0c32.6 0 65 4.4 96.4 13.1l83.8 23.3c11.1 3.1 22.9 2.7 33.8-1.2L345.4 533c38.9-13.9 79.8-21 121.1-21l85.5 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-85.5 0c-46.8 0-93.2 8-137.2 23.8L289.5 502c-1.6 .6-3.2 .6-4.8 .2l-83.8-23.3C165.3 469 128.6 464 91.7 464L24 464c-13.3 0-24 10.7-24 24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookOpenCover = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;