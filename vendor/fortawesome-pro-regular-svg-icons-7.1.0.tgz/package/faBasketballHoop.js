'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'basketball-hoop';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f435';
var svgPathData = 'M440 240c13.3 0 24 10.7 24 24 0 9.6-5.6 17.7-13.8 21.6L419.8 498.8c-1.1 7.8-6.7 14.2-14.3 16.4-6.6 1.9-13.7 .2-18.8-4.2l-2.1-2.1-42.4-50.2-38.5 49.5c-3.8 4.9-9.6 7.7-15.8 7.7s-12-2.9-15.8-7.7l-38.5-49.5-42.4 50.2c-5.1 6-13.2 8.5-20.8 6.3-6.6-1.9-11.7-7.1-13.7-13.5l-.6-2.8-30.5-213.3c-8.1-3.9-13.7-12-13.7-21.6 0-13.3 10.7-24 24-24l304 0zM260.1 427.6l27.9 35.8 27.9-35.8-27.9-33-27.9 33zm-70.6 21.5l19.1-22.6-27.3-35.1 8.3 57.7zm177.9-22.6l19.1 22.6 8.3-57.7-27.3 35.1zM201.2 351.8l33.8 43.5 26.8-31.7-36.8-43.6-23.8 31.7zm113 11.8l26.8 31.7 33.8-43.5-23.8-31.7-36.8 43.6zM288 0c179.2 0 263.4 130.7 283.3 166.8 3.3 6 4.7 12.7 4.7 19.6l-.2 128.7c-1.7 23.4-16.1 44.2-37.8 53.8l-54.6 24.2 8-56.1 29.2-13.1c4.6-2.9 7.4-8 7.4-13.5l0-122.6C508.8 153.8 436.9 48 288 48S67.2 153.8 48 187.8l0 122.6c0 6.3 3.7 12.1 9.5 14.6l27.1 12 8 56.1-54.6-24.2C16.3 359.3 1.9 338.5 .2 315.1L0 186.4C0 179.6 1.4 172.8 4.7 166.8 24.6 130.7 108.8 0 288 0zm0 332.7l37.8-44.7-75.6 0 37.8 44.7zm-116.3-8.3l27.3-36.4-32.5 0 5.2 36.4zm232.6 0l5.2-36.4-32.5 0 27.3 36.4zM360 128c30.9 0 56 25.1 56 56l0 8-48 0 0-8c0-4.4-3.6-8-8-8l-144 0c-4.4 0-8 3.6-8 8l0 8-48 0 0-8c0-30.9 25.1-56 56-56l144 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBasketballHoop = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;