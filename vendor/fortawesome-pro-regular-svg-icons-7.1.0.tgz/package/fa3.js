'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = '3';
var width = 320;
var height = 512;
var aliases = [];
var unicode = '33';
var svgPathData = 'M72 280c-13.3 0-24-10.7-24-24s10.7-24 24-24l124 0c42 0 76-34 76-76s-34-76-76-76L24 80C10.7 80 0 69.3 0 56S10.7 32 24 32l172 0c68.5 0 124 55.5 124 124 0 41-19.9 77.4-50.7 100 30.7 22.6 50.7 59 50.7 100 0 68.5-55.5 124-124 124L24 480c-13.3 0-24-10.7-24-24s10.7-24 24-24l172 0c42 0 76-34 76-76s-34-76-76-76L72 280z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.fa3 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;