'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bong';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f55c';
var svgPathData = 'M160.5 48l-8 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l208 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-8 0 0 169.7c14.2 8.2 27.2 18.2 38.8 29.6l39.3-39.3-7-7c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0c16 16 32 32 48 48 9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-7-7-43.3 43.3c17.3 28.8 27.3 62.6 27.3 98.7 0 44.9-15.4 86.2-41.2 118.9-4.6 5.8-11.5 9.1-18.8 9.1l-263.9 0c-7.3 0-14.3-3.4-18.8-9.1-25.8-32.7-41.2-74-41.2-118.9 0-71.1 38.6-133.1 96-166.3l0-169.7zm48 0l0 184.2c0 9.3-5.3 17.7-13.7 21.7-29.2 13.9-53 37.3-67.3 66.2l258.1 0c-14.4-28.9-38.1-52.3-67.3-66.2-8.4-4-13.7-12.4-13.7-21.7l0-184.2-96 0zM399.6 368l-286.2 0c-.6 5.3-.9 10.6-.9 16 0 29.6 8.9 57.1 24.2 80l239.5 0c15.3-22.9 24.2-50.4 24.2-80 0-5.4-.3-10.7-.9-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBong = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;