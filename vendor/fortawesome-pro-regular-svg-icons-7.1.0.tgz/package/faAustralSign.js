'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'austral-sign';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e0a9';
var svgPathData = 'M275.5 240l-103 0 51.5-134.3 51.5 134.3zm51.4 0L255.5 53.6C250.5 40.6 238 32 224 32s-26.5 8.6-31.5 21.6L121.1 240 32 240c-13.3 0-24 10.7-24 24s10.7 24 24 24l70.7 0-18.4 48-52.3 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l33.9 0-24.3 63.4c-4.7 12.4 1.4 26.3 13.8 31s26.3-1.4 31-13.8l30.9-80.6 213.4 0 30.9 80.6c4.7 12.4 18.6 18.6 31 13.8s18.6-18.6 13.8-31L382.1 384 416 384c13.3 0 24-10.7 24-24s-10.7-24-24-24l-52.3 0-18.4-48 70.7 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-89.1 0zm-33 48l18.4 48-176.6 0 18.4-48 139.8 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAustralSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;