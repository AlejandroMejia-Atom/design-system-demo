'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bolt-auto';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e0b6';
var svgPathData = 'M309.6 20.2c9.1 6.3 12.7 17.9 8.9 28.2L264.6 192 349 192c19.3 0 35 15.7 35 35 0 10-4.3 19.6-11.9 26.3L103.9 490c-8.3 7.3-20.4 8-29.5 1.8s-12.7-17.9-8.9-28.2L119.4 320 35 320c-19.3 0-35-15.7-35-35 0-10.1 4.3-19.6 11.9-26.3L280.1 22c8.3-7.3 20.4-8 29.5-1.8zM69.3 272l84.7 0c7.9 0 15.2 3.9 19.7 10.3s5.5 14.7 2.7 22.1L144.2 390.4 314.7 240 230 240c-7.9 0-15.2-3.9-19.7-10.3s-5.5-14.7-2.7-22.1L239.8 121.6 69.3 272zM400 288c9.1 0 17.4 5.1 21.5 13.3l88 176c5.9 11.9 1.1 26.3-10.7 32.2s-26.3 1.1-32.2-10.7l-13.4-26.7-106.3 0-13.4 26.7c-5.9 11.9-20.3 16.7-32.2 10.7s-16.7-20.3-10.7-32.2l88-176c4.1-8.1 12.4-13.3 21.5-13.3zM370.8 424l58.3 0-29.2-58.3-29.2 58.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltAuto = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;