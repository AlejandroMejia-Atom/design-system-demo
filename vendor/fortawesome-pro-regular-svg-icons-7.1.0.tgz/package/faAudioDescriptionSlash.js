'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'audio-description-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0a8';
var svgPathData = 'M41-24.9c-9.4-9.4-24.6-9.4-33.9 0S-2.3-.3 7 9.1l528 528c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-61.4-61.4C529.1 431.4 544 409.5 544 384l0-256c0-35.3-28.7-64-64-64L129.8 64 41-24.9zM177.8 112L480 112c8.8 0 16 7.2 16 16l0 256c0 8.8-7.2 16-16 16l-14.2 0-56.3-56.3C432.4 331.6 448 307.6 448 280l0-48c0-39.8-32.2-72-72-72l-48 0c-13.3 0-24 10.7-24 24l0 54.2-126.2-126.2zm192 192l-17.8-17.8 0-78.2 24 0c13.3 0 24 10.7 24 24l0 48c0 13.3-10.7 24-24 24l-6.2 0zM132 201.8c-2.6 6.9-4 14.4-4 22.2l0 104c0 13.3 10.7 24 24 24s24-10.7 24-24l0-24 48 0 0 24c0 13.3 10.7 24 24 24 9.2 0 17.3-5.2 21.3-12.9L132 201.8zm-52-52l-44-44c-2.6 6.9-4 14.4-4 22.2l0 256c0 35.3 28.7 64 64 64l282.2 0-48-48-234.2 0c-8.8 0-16-7.2-16-16l0-234.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAudioDescriptionSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;