'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-up-z-a';
var width = 512;
var height = 512;
var aliases = ["sort-alpha-up-alt"];
var unicode = 'f882';
var svgPathData = 'M288.5 56c0 13.3 10.7 24 24 24l86.1 0-103 103c-6.9 6.9-8.9 17.2-5.2 26.2S302.8 224 312.5 224l144 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-86.1 0 103-103c6.9-6.9 8.9-17.2 5.2-26.2S466.2 32 456.5 32l-144 0c-13.3 0-24 10.7-24 24zM406 285.3c-4.1-8.1-12.4-13.3-21.5-13.3s-17.4 5.1-21.5 13.3l-80 160c-5.9 11.9-1.1 26.3 10.7 32.2s26.3 1.1 32.2-10.7l13.4-26.7 85.2 0c1.7 0 3.3-.2 4.9-.5L443 466.7c5.9 11.9 20.3 16.7 32.2 10.7s16.7-20.3 10.7-32.2l-80-160zm-21.5 64.4l21.2 42.3-42.3 0 21.2-42.3zM145.5 39c-9.4-9.4-24.6-9.4-33.9 0l-88 88c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 0 342.1c0 13.3 10.7 24 24 24s24-10.7 24-24l0-342.1 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-88-88z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpZA = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;