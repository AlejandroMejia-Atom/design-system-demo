'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-up-from-ground-water';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4b5';
var svgPathData = 'M303 7c9.4-9.4 24.6-9.4 33.9 0l88 88c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-47-47 0 278.1c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-278.1-47 47c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9L303 7zM240 192l0 48-128 0 0 146.1c-7.1 5.1-13.1 8.6-18 10.8l-.8 .4c-3.7 1.7-6.4 2.9-9.8 .3-6-4.5-12.6-8-19.3-10.4L64 240c0-26.5 21.5-48 48-48l128 0zm336 48l0 155.2c-1.1 .8-2.2 1.5-3.3 2.4-4.1 3.1-8.3 .8-12.6-1.5-.6-.3-1.2-.6-1.8-1-5.2-2.7-11.1-6.6-18-11.7-4-3-8.1-5.8-12.4-8.4l0-135-128 0 0-48 128 0c26.5 0 48 21.5 48 48zM403.4 476.1C379.1 494.3 351.1 512 320 512s-59.1-17.7-83.4-35.9c-21.3-16.1-49.9-16.1-71.2 0-23.8 17.9-54.1 35.5-88.1 35.3-20.4-.1-40.7-6.7-59.8-21.1-10.6-8-12.7-23-4.7-33.6s23-12.7 33.6-4.7c11.3 8.5 21.6 11.4 31.2 11.5 17.6 .1 37.3-9.4 58.9-25.7 38.4-29 90.5-29 129 0 24 18.1 40.7 26.3 54.5 26.3s30.5-8.2 54.5-26.3c38.4-29 90.5-29 129 0 16.9 12.7 32.9 21.5 47.8 24.6 13.7 2.8 27.4 .9 42.3-10.3 10.6-8 25.6-5.9 33.6 4.7s5.9 25.6-4.7 33.6c-26.4 19.9-54.2 24.4-80.7 19.1-25.3-5.1-48.1-18.9-67.2-33.3-21.3-16.1-49.9-16.1-71.2 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpFromGroundWater = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;