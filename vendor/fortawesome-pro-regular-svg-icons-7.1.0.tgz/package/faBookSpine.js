'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-spine';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e754';
var svgPathData = 'M0 88C0 39.4 39.4 0 88 0L376 0c39.8 0 72 32.2 72 72l0 256c0 25-12.7 47-32 59.9l0 76.1 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L80 512c-44.2 0-80-35.8-80-80L0 88zM80 400c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0 0-64-288 0zM48 358.7c9.8-4.3 20.6-6.7 32-6.7l48 0 0-304-40 0C65.9 48 48 65.9 48 88l0 270.7zM176 48l0 304 200 0c13.3 0 24-10.7 24-24l0-256c0-13.3-10.7-24-24-24L176 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookSpine = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;