'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'angle';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e08c';
var svgPathData = 'M253.3 67.1c6.1-11.8 1.5-26.3-10.2-32.4s-26.2-1.5-32.4 10.2l-208 400c-3.9 7.4-3.6 16.4 .8 23.5S15.6 480 24 480l400 0c13.3 0 24-10.7 24-24s-10.7-24-24-24L63.5 432 253.3 67.1zm94.2 243.6c-5.6-12.8-21.3-17-33.2-9.7-10.7 6.6-14.4 20.3-9.5 31.9 6.9 16.3 12.4 33.4 16.3 51.1l49 0c-4.8-25.5-12.4-50.1-22.6-73.3zm-91.4-56c8.2 9.5 22.1 12.3 32.8 5.6 11.9-7.4 15.1-23.4 6.1-34.1-14.1-16.6-29.7-31.9-46.6-45.7l-22.7 43.6c10.9 9.4 21 19.6 30.4 30.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAngle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;