'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'beer-mug';
var width = 576;
var height = 512;
var aliases = ["beer-foam"];
var unicode = 'e0b3';
var svgPathData = 'M353.5 103c12.5 10.6 28.8 17 46.5 17 39.8 0 72-32.2 72-72s-32.2-72-72-72c-17.7 0-33.9 6.4-46.5 17-9.3 7.9-32.1 7.4-40.7-1.3-14.5-14.6-34.6-23.7-56.8-23.7s-42.3 9.1-56.8 23.7C190.6 .4 167.8 .9 158.5-7 145.9-17.6 129.7-24 112-24 72.2-24 40 8.2 40 48s32.2 72 72 72c17.7 0 33.9-6.4 46.5-17 9.3-7.9 32.1-7.4 40.7 1.3 14.5 14.6 34.6 23.7 56.8 23.7s42.3-9.1 56.8-23.7c8.6-8.7 31.4-9.2 40.7-1.3zM64 158l0 258c0 53 43 96 96 96l192 0c53 0 96-43 96-96l0-17.2 97-48.5c19-9.5 31-28.9 31-50.1L576 184c0-30.9-25.1-56-56-56l-30.6 0c-22 24.6-53.9 40-89.4 40l0 215.5c0 .3 0 .7 0 1l0 31.5c0 26.5-21.5 48-48 48l-192 0c-26.5 0-48-21.5-48-48l0-248c-17.1 0-33.3-3.6-48-10zM523.6 307.4l-75.6 37.8 0-169.2 72 0c4.4 0 8 3.6 8 8l0 116.2c0 3-1.7 5.8-4.4 7.2zM180 192c-11 0-20 9-20 20l0 184c0 11 9 20 20 20s20-9 20-20l0-184c0-11-9-20-20-20zm76 0c-11 0-20 9-20 20l0 184c0 11 9 20 20 20s20-9 20-20l0-184c0-11-9-20-20-20zm96 20c0-11-9-20-20-20s-20 9-20 20l0 184c0 11 9 20 20 20s20-9 20-20l0-184z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBeerMug = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;